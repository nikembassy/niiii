﻿# tema.ps1 -- Mappa colori del tema di ZAP (funzioni PURE, testabili senza Windows).
# Il disegno del fumetto (fondo crema, giallo, Comic Sans) viene convertito nella nuova
# grafica scura con accenti oro, ripresa dalla foto di riferimento:
#   fondo  #0E1116 / #12161C / #141821   |   accento  #D4AF37 / #C8A158 / #EFDC8F
#   testo  #F0E9D8 / #C9C2B2             |   superfici  #1C222C / #232A35 / #2A313B
#   verde #3DDC84 (stato attivo)         |   rosso #B5443C (stop)
# La nuova grafica e' l'UNICA: la mappa viene applicata sempre.

function Get-TemaMappa {
    return [ordered]@{
        # --- attributi con valori letterali (i piu' specifici vanno PRIMA) ---
        'Background="White"'       = 'Background="#141922"'
        'Foreground="White"'       = 'Foreground="#F0E9D8"'
        'Value="White"'            = 'Value="#F0E9D8"'
        'Fill="White"'             = 'Fill="#141922"'
        'Stroke="White"'           = 'Stroke="#2A323D"'
        'Stroke="Black"'           = 'Stroke="#2A323D"'
        'BorderBrush="Black"'      = 'BorderBrush="#2A323D"'
        'Background="Black"'       = 'Background="#0E1116"'
        'Foreground="Black"'       = 'Foreground="#1A1408"'
        'Value="Black"'            = 'Value="#1A1408"'
        # --- colori del vecchio fumetto -> nuova grafica ---
        '#FFFDF3D6'                = '#0E1116'
        '#FFFFF1B8'                = '#141821'
        '#FFF3DF7F'                = '#1B2130'
        '#FFFFFBF0'                = '#12161C'
        '#FFFFD54F'                = '#D4AF37'
        '#FFFFB300'                = '#C8A158'
        '#FF81D4FA'                = '#1C222C'
        '#FF4FC3F7'                = '#1C222C'
        '#FFB39DDB'                = '#232A35'
        '#FF7E57C2'                = '#232A35'
        '#FFA5D6A7'                = '#232A35'
        '#FF26A69A'                = '#232A35'
        '#FFFF7043'                = '#C8A158'
        '#FFEF9A9A'                = '#B5443C'
        '#FFE53935'                = '#D4AF37'
        '#FF5D4037'                = '#C9C2B2'
        '#FFB0BEC5'                = '#2A313B'
        '#FFF7F7FF'                = '#141922'
        '#BB000000'                = '#CC06080C'
        # --- tipografia ---
        'Comic Sans MS'            = 'Segoe UI'
    }
}

function Get-TemaColoriChiari {
    # Colori chiari del vecchio fumetto: dopo il cambio NON devono restare nel file.
    return @('#FFFDF3D6', '#FFFFF1B8', '#FFF3DF7F', '#FFFFFBF0', '#FFFFD54F', '#FFFFB300',
             '#FF81D4FA', '#FF4FC3F7', '#FFB39DDB', '#FF7E57C2', '#FFA5D6A7', '#FF26A69A',
             '#FFFF7043', '#FFEF9A9A', '#FFE53935', '#FF5D4037', '#FFB0BEC5', '#FFF7F7FF')
}

function Get-TemaXaml {
    # Applica la mappa. La grafica nuova e' l'unica: si applica sempre.
    param([string]$Xaml, [string]$Tema = 'oro')
    if (-not $Xaml) { return '' }
    $t = $Xaml
    $map = Get-TemaMappa
    foreach ($k in @($map.Keys)) { $t = $t.Replace($k, $map[$k]) }
    return $t
}

# --------------------------------------------------------------------------
# v6.5 -- Palette personalizzabile (sezione "CAMBIA TEMA E COLORI")
# Funzioni PURE: i test le verificano senza Windows.
# --------------------------------------------------------------------------

function Get-PaletteDefault {
    return [ordered]@{
        preset          = 'aura'
        sfondo          = '#0E1116'
        superficie      = '#12161C'
        campo           = '#141922'
        pill            = '#161B22'
        accento         = '#D4AF37'
        accentoChiaro   = '#E8C86A'
        accentoScuro    = '#B8912B'
        argento         = '#C9CFD6'
        argentoScuro    = '#9AA4AE'
        testo           = '#F0E9D8'
        testoSuAccento  = '#1A1408'
        bordo           = '#2A323D'
        font            = 'Segoe UI'
        fontSize        = 13
        sfondoImmagine  = ''
    }
}

function Get-TemaPreset {
    # Temi pronti: si applicano con un clic dal pannello ASPETTO.
    param([string]$Nome)
    $p = Get-PaletteDefault
    switch (([string]$Nome).Trim().ToLower()) {
        'notte' {
            $p.preset='notte'; $p.sfondo='#0B1220'; $p.superficie='#101A2B'; $p.campo='#0E1626'; $p.pill='#152136'
            $p.accento='#4FC3F7'; $p.accentoChiaro='#8FD6FA'; $p.accentoScuro='#2A7EA6'
            $p.argento='#C9CFD6'; $p.argentoScuro='#93A1B0'; $p.testo='#EAF2FB'; $p.testoSuAccento='#06121F'; $p.bordo='#24354D'
            return $p }
        'smeraldo' {
            $p.preset='smeraldo'; $p.sfondo='#0B1512'; $p.superficie='#10201B'; $p.campo='#0E1B17'; $p.pill='#143028'
            $p.accento='#3DDC84'; $p.accentoChiaro='#7EEBAE'; $p.accentoScuro='#1E8A50'
            $p.argento='#CBD6D0'; $p.argentoScuro='#93A69C'; $p.testo='#EAF6F0'; $p.testoSuAccento='#04120B'; $p.bordo='#1F3A31'
            return $p }
        'viola' {
            $p.preset='viola'; $p.sfondo='#100B18'; $p.superficie='#181026'; $p.campo='#150E20'; $p.pill='#221636'
            $p.accento='#B388FF'; $p.accentoChiaro='#D3BDFF'; $p.accentoScuro='#7A55C7'
            $p.argento='#D2CCE0'; $p.argentoScuro='#9E96B3'; $p.testo='#F2EDFB'; $p.testoSuAccento='#120823'; $p.bordo='#2E2342'
            return $p }
        'chiaro' {
            $p.preset='chiaro'; $p.sfondo='#F4F1E8'; $p.superficie='#FFFFFF'; $p.campo='#FFFFFF'; $p.pill='#F0EBDF'
            $p.accento='#B8912B'; $p.accentoChiaro='#D9B44A'; $p.accentoScuro='#8A6B15'
            $p.argento='#4A5560'; $p.argentoScuro='#5B6672'; $p.testo='#1A1A1A'; $p.testoSuAccento='#FFFFFF'; $p.bordo='#C9C2B2'
            return $p }
        default { return (Get-PaletteDefault) }
    }
}

function Merge-Palette {
    # Unisce la palette salvata (parziale) con quella di default.
    param($Attesa)
    $p = Get-PaletteDefault
    if ($null -eq $Attesa) { return $p }
    foreach ($k in @($p.Keys)) {
        $v = $null
        if ($Attesa -is [System.Collections.IDictionary]) {
            if ($Attesa.Contains($k)) { $v = $Attesa[$k] }
        } else {
            try { $v = $Attesa.$k } catch { }
        }
        if ($null -ne $v -and ([string]$v).Trim()) { $p[$k] = $v }
    }
    return $p
}
