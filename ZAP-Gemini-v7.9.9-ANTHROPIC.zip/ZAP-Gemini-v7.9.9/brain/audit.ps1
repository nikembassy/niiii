# audit.ps1 -- GOVERNANCE di ZAP: registro strutturato (audit trail) + anteprima comandi.
#   1) Add-AuditEvent      : scrive una riga JSON per ogni azione (chi/quando/cosa/esito/durata)
#                            in logs\audit_AAAA-MM.jsonl. Passa da Protect-LogText (niente segreti).
#   2) Get-AnteprimaPowerShell : analizza un comando SENZA eseguirlo (AST di PowerShell) e
#                            elenca cosa verrebbe usato. E' la base della modalita' simulazione.
#
# v7.9.7 HARDENING (da review di sicurezza) -- la catena di integrita' diventa AUTENTICATA:
#   1) HMAC-SHA256 con CHIAVE PRIVATA (logs\.zap_audit_key) al posto del MD5 in chiaro: prima
#      chi poteva modificare il log poteva anche RICALCOLARE l'intera catena (nessun segreto).
#   2) La catena ora copre anche AZIONE e DETTAGLI (prima no): modificare il testo di un comando
#      rompe la catena.
#   3) Campo 'seq' monotono: un riordino/rimozione di righe si nota.
#   4) Scrittura protetta da Mutex (Local\ZapAuditLog): niente righe interlacciate.
#   5) Verifica retro-compatibile: le righe vecchie (md5-legacy) restano verificabili.
#   LIMITE onesto: chi ha esecuzione di codice come te puo' comunque leggere la chiave. Per una
#   garanzia forte il registro va SPEDITO fuori macchina (sink remoto append-only) in tempo reale.

function Get-AuditPath {
    param($sync)
    $d = ''
    try { $d = Join-Path ([string]$sync.Base) 'logs' } catch { }
    if (-not $d) { $d = Join-Path (Get-Location).Path 'logs' }
    if (-not (Test-Path $d)) { try { New-Item -ItemType Directory -Path $d | Out-Null } catch { } }
    return (Join-Path $d ('audit_' + (Get-Date -Format 'yyyy-MM') + '.jsonl'))
}

# --- v7.9.7: chiave privata + HMAC per la catena di integrita' ---------------

function Get-AuditKeyPath {
    param($sync)
    $d = ''
    try { $d = Join-Path ([string]$sync.Base) 'logs' } catch { }
    if (-not $d) { $d = Join-Path (Get-Location).Path 'logs' }
    return (Join-Path $d '.zap_audit_key')
}

function New-AuditKey {
    # Crea (una sola volta) una chiave casuale a 256 bit per firmare il registro.
    param($sync)
    try {
        $kp = Get-AuditKeyPath $sync
        if (Test-Path $kp) { return $true }
        $dir = Split-Path -Parent $kp
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
        $b = New-Object byte[] 32
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        $rng.GetBytes($b); $rng.Dispose()
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($kp, [System.Convert]::ToBase64String($b), $enc)
        try { $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name; icacls $kp /inheritance:r /grant:r ("$me" + ':F') | Out-Null } catch { }
        return $true
    } catch { return $false }
}

function Get-AuditKey {
    param($sync)
    try {
        $kp = Get-AuditKeyPath $sync
        if (-not (Test-Path $kp)) { if (-not (New-AuditKey $sync)) { return $null } }
        $txt = ([System.IO.File]::ReadAllText($kp)).Trim()
        if (-not $txt) { return $null }
        return [System.Convert]::FromBase64String($txt)
    } catch { return $null }
}

function Get-AuditHmac {
    param($sync, [string]$Testo)
    try {
        $k = Get-AuditKey $sync
        if ($null -eq $k) { return '' }
        $h = New-Object System.Security.Cryptography.HMACSHA256(,$k)
        $b = $h.ComputeHash([System.Text.Encoding]::UTF8.GetBytes([string]$Testo))
        $h.Dispose()
        return ([System.BitConverter]::ToString($b)).Replace('-','').ToLower()
    } catch { return '' }
}

function Add-AuditEvent {
    # Registra una voce nella "scatola nera". Non deve MAI bloccare o far fallire nulla.
    param($sync, [string]$Tipo = 'azione', [string]$Azione = '', [string]$Esito = 'ok',
          [int]$DurataMs = 0, [string]$Dettagli = '', [switch]$Simulato)
    try {
        if ($null -ne $sync) {
            try { if ($sync.Config.ContainsKey('audit') -and (-not [bool]$sync.Config.audit)) { return } } catch { }
        }
    } catch { }
    try {
        $pulisci = { param($t)
            if (-not $t) { return '' }
            $x = [string]$t
            try { if (Get-Command Protect-LogText -ErrorAction SilentlyContinue) { $x = Protect-LogText $x } } catch { }
            return $x
        }
        $az = & $pulisci $Azione
        if ($az.Length -gt 2000) { $az = $az.Substring(0, 2000) + '...[troncato]' }
        $dt = & $pulisci $Dettagli
        if ($dt.Length -gt 1000) { $dt = $dt.Substring(0, 1000) + '...[troncato]' }

        $hash = ''
        try {
            $sha = [System.Security.Cryptography.SHA256]::Create()
            $bytes = [System.Text.Encoding]::UTF8.GetBytes([string]$Azione)
            $hash = ([System.BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLower()
            if ($hash.Length -gt 16) { $hash = $hash.Substring(0, 16) }
            $sha.Dispose()
        } catch { }

        $modo = ''; $admin = $false
        try { $modo = [string]$sync.Config.sicurezza } catch { }
        try { if (Get-Command Test-Admin -ErrorAction SilentlyContinue) { $admin = [bool](Test-Admin) } } catch { }

        # v7.9.7: sezione critica (lettura catena + scrittura) sotto Mutex.
        $mtx = $null
        try { $mtx = New-Object System.Threading.Mutex($false, 'Local\ZapAuditLog'); [void]$mtx.WaitOne(3000) } catch { $mtx = $null }
        try {
            $catPrec = ''; $seqPrec = 0
            try {
                $api0 = Get-AuditPath $sync
                if (Test-Path $api0) {
                    $ult = @(Get-Content -LiteralPath $api0 -Encoding UTF8 | Where-Object { $_.Trim() } | Select-Object -Last 1)
                    if ($ult.Count -gt 0) {
                        try {
                            $o0 = ($ult[0].TrimStart([char]0xFEFF) | ConvertFrom-Json)
                            $catPrec = [string]$o0.catena
                            $seqPrec = [int]$o0.seq
                        } catch { }
                    }
                }
            } catch { }

            $rec = [ordered]@{
                ts       = (Get-Date -Format 'o')
                seq      = ($seqPrec + 1)
                tipo     = [string]$Tipo
                esito    = [string]$Esito
                ms       = [int]$DurataMs
                hash     = $hash
                modo     = $modo
                admin    = $admin
                sim      = [bool]$Simulato
                azione   = $az
                dettagli = $dt
            }

            $cat = ''; $alg = 'none'
            $base = (@($catPrec, [string]$rec.hash, [string]$rec.seq, [string]$rec.ts, [string]$rec.esito, [string]$rec.ms, [string]$rec.tipo, [string]$rec.azione, [string]$rec.dettagli) -join '|')
            $hm = ''
            try { $hm = Get-AuditHmac $sync $base } catch { $hm = '' }
            if ($hm) { $cat = $hm; $alg = 'hmac-sha256' }
            else {
                try {
                    $md5c = [System.Security.Cryptography.MD5]::Create()
                    $b2 = [System.Text.Encoding]::UTF8.GetBytes($catPrec + '|' + $hash + '|' + [string]$rec.ts + '|' + [string]$rec.esito + '|' + [string]$rec.ms)
                    $cat = ([System.BitConverter]::ToString($md5c.ComputeHash($b2))).Replace('-','').ToLower()
                    $md5c.Dispose(); $alg = 'md5-legacy'
                } catch { }
            }
            $rec['catena'] = $cat
            $rec['alg'] = $alg
            $linea = ($rec | ConvertTo-Json -Compress)

            $enc = New-Object System.Text.UTF8Encoding($false)   # SENZA BOM
            [System.IO.File]::AppendAllText((Get-AuditPath $sync), ($linea + "`r`n"), $enc)
        } finally {
            try { if ($mtx) { $mtx.ReleaseMutex() } } catch { }
            try { if ($mtx) { $mtx.Dispose() } } catch { }
        }
    } catch { }
}

function Test-AuditIntegrita {
    # Ricompone la catena di integrita' e verifica che il registro non sia stato toccato.
    # v7.9.7: gestisce sia le righe HMAC-SHA256 sia le vecchie righe md5-legacy.
    param($sync)
    $p = Get-AuditPath $sync
    if (-not (Test-Path $p)) { return 'Nessun registro ancora (scatola nera vuota).' }
    $keyOk = $true
    try { if (-not (Get-AuditKey $sync)) { $keyOk = $false } } catch { $keyOk = $false }
    $prec = ''; $n = 0; $ok = $true; $primacattiva = 0; $legacy = 0; $hmac = 0; $nonVerif = 0
    try {
        foreach ($riga in @(Get-Content -LiteralPath $p -Encoding UTF8 | Where-Object { $_.Trim() })) {
            $n++
            try {
                $o = ($riga.TrimStart([char]0xFEFF) | ConvertFrom-Json)
                $cat = [string]$o.catena
                $alg = ''; try { $alg = [string]$o.alg } catch { }
                $calc = ''
                if ($alg -eq 'hmac-sha256') {
                    $hmac++
                    $base = (@($prec, [string]$o.hash, [string]$o.seq, [string]$o.ts, [string]$o.esito, [string]$o.ms, [string]$o.tipo, [string]$o.azione, [string]$o.dettagli) -join '|')
                    $calc = Get-AuditHmac $sync $base
                    if (-not $calc) { $nonVerif++; $calc = $cat }   # chiave assente: non verificabile (non e' prova di manomissione)
                } else {
                    $legacy++
                    $md5c = [System.Security.Cryptography.MD5]::Create()
                    $b2 = [System.Text.Encoding]::UTF8.GetBytes($prec + '|' + [string]$o.hash + '|' + [string]$o.ts + '|' + [string]$o.esito + '|' + [string]$o.ms)
                    $calc = ([System.BitConverter]::ToString($md5c.ComputeHash($b2))).Replace('-','').ToLower()
                    $md5c.Dispose()
                }
                if ($calc -ne $cat) { $ok = $false; if ($primacattiva -eq 0) { $primacattiva = $n } }
                $prec = $cat
            } catch { }
        }
    } catch { }
    $det = (' (' + $hmac + ' righe HMAC, ' + $legacy + ' righe legacy' + $(if ($nonVerif) { ', ' + $nonVerif + ' non verificabili (chiave assente)' } else { '' }) + ')')
    if ($ok) {
        $extra = ''
        if (-not $keyOk) { $extra = ' ATTENZIONE: chiave assente, le righe HMAC non sono verificabili.' }
        return ('Registro INTEGRO: ' + $n + ' righe, catena di integrita verificata.' + $det + $extra)
    }
    return ('!REGISTRO MANOMESSO: la catena si rompe alla riga ' + $primacattiva + ' di ' + $n + '. Qualcuno ha modificato logs\audit_*.jsonl.' + $det)
}

function Get-AuditUltimi {
    param($sync, [int]$N = 20)
    $p = Get-AuditPath $sync
    if (-not (Test-Path $p)) { return @() }
    try { return @(Get-Content -LiteralPath $p -Encoding UTF8 | Where-Object { $_.Trim() } | Select-Object -Last $N) } catch { return @() }
}

function Format-AuditUltimi {
    param($sync, [int]$N = 20)
    $righe = @(Get-AuditUltimi $sync $N)
    if ($righe.Count -eq 0) { return 'Registro (scatola nera) vuoto: nessuna azione ancora registrata.' }
    $out = @('ULTIME ' + $righe.Count + ' AZIONI  -  file: logs\' + (Split-Path (Get-AuditPath $sync) -Leaf))
    foreach ($r in $righe) {
        try {
            $o = ($r.TrimStart([char]0xFEFF) | ConvertFrom-Json)
            $ora = [string]$o.ts
            try { $ora = ([datetime]$o.ts).ToString('dd/MM HH:mm:ss') } catch { }
            $az = ([string]$o.azione) -replace '\s+', ' '
            if ($az.Length -gt 80) { $az = $az.Substring(0, 80) + '...' }
            $out += ('  ' + $ora + '  [' + [string]$o.esito + ']  ' + [string]$o.tipo + '  ' + $az)
        } catch { }
    }
    return ($out -join "`n")
}

function Get-AnteprimaPowerShell {
    # Analizza un comando SENZA eseguirlo: comandi e percorsi che verrebbero usati.
    param([string]$Code)
    if (-not $Code) { return '' }
    $cmds = @(); $perc = @()
    try {
        $tokens = $null; $errs = $null
        $ast = [System.Management.Automation.Language.Parser]::ParseInput($Code, [ref]$tokens, [ref]$errs)
        $pred = [System.Func[System.Management.Automation.Language.Ast, bool]]{
            param($n) $n -is [System.Management.Automation.Language.CommandAst]
        }
        foreach ($c in $ast.FindAll($pred, $true)) {
            $n = ''
            try { $n = [string]$c.GetCommandName() } catch { }
            if ($n -and ($cmds -notcontains $n)) { $cmds += $n }
        }
        $predS = [System.Func[System.Management.Automation.Language.Ast, bool]]{
            param($n) $n -is [System.Management.Automation.Language.StringConstantExpressionAst]
        }
        foreach ($s in $ast.FindAll($predS, $true)) {
            $v = [string]$s.Value
            if ($v -match '^[A-Za-z]:\\' -or $v -match '\\\\' -or $v -match '^/' -or $v -match '\.(exe|ps1|bat|cmd|txt|log|json|zip|docx|pdf|xlsx)$') {
                if ($perc -notcontains $v) { $perc += $v }
            }
        }
        if ($errs -and $errs.Count -gt 0) { $perr = 'Attenzione: il comando ha errori di sintassi: ' + [string]$errs[0].Message } else { $perr = '' }
    } catch { }
    $out = @()
    if ($cmds.Count -gt 0) { $out += ('Comandi che verrebbero usati: ' + (($cmds | Select-Object -First 15) -join ', ')) }
    if ($perc.Count -gt 0) { $out += ('Percorsi/file citati: ' + (($perc | Select-Object -First 15) -join ', ')) }
    if ($perr) { $out += $perr }
    if ($out.Count -eq 0) { $out += 'Nessun comando riconoscibile (potrebbe essere un espressione o codice offuscato).' }
    return ($out -join "`n")
}
