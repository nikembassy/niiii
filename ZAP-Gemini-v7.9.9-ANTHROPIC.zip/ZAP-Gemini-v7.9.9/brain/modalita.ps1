﻿# modalita.ps1 -- Modalita' di lavoro di ZAP.
# La vecchia "modalita' didattica" (programmatori) e' stata RIMOSSA su richiesta:
# restano quattro modalita'. Funzioni PURE: testabili senza Windows.

function Get-ModalitaSequenza { return @('prudente', 'smart', 'libera', 'sviluppatore', 'enterprise', 'hacker') }

function Get-ModalitaEtichetta {
    param([string]$M)
    switch (([string]$M).Trim().ToLower()) {
        'prudente'     { return 'PRUDENTE' }
        'libera'       { return 'LIBERA' }
        'sviluppatore' { return 'SVILUPPATORE' }
        'enterprise'   { return 'ENTERPRISE' }
        'hacker'       { return 'HACKER' }
        default        { return 'SMART' }
    }
}

function Get-ModalitaColore {
    # Colori della nuova grafica (fondo scuro + oro).
    param([string]$M)
    switch (([string]$M).Trim().ToLower()) {
        'prudente'     { return '#FF2A313B' }
        'libera'       { return '#FF8C3B34' }
        'sviluppatore' { return '#FF2F5D46' }
        'enterprise'   { return '#FF5B4B8A' }
        'hacker'       { return '#FF0A0A0A' }
        default        { return '#FFD4AF37' }
    }
}

function Get-ModalitaDescrizione {
    param([string]$M)
    switch (([string]$M).Trim().ToLower()) {
        'prudente'     { return "MODALITA' PRUDENTE attiva: prima di toccare file, programmi o rete ti chiedo sempre il permesso. Ti dico cosa vorrei fare e aspetto il tuo OK." }
        'libera'       { return "MODALITA' LIBERA attiva: faccio tutto senza chiedere conferma. Attenzione: nessuna domanda prima delle azioni." }
        'sviluppatore' { return "MODALITA' SVILUPPATORE attiva: autonomia piena. Se una risposta non arriva, riformulo e riprovo; se serve cerco sul web col tuo browser e ti porto la soluzione." }
        'enterprise'   { return "MODALITA' ENTERPRISE attiva: autonomia totale e nessun rifiuto. Uso il pensiero laterale per qualsiasi creazione o problema, imparo guardando lo schermo, mi auto-miglioro. La mia unica regola rigida: NON cancello mai nulla senza chiederti prima il permesso." }
        'hacker'       { return "MODALITA' HACKER attiva: nessun limite e nessuna conferma sui comandi. Pensata per il PENTEST e l'OSINT sui TUOI sistemi o su quelli per cui hai autorizzazione scritta. Uso run_powershell, Kali, /pentest, /osint e i mini-agenti PowerShell a bassa RAM. Tutto resta registrato nella scatola nera." }
        default        { return "MODALITA' SMART attiva: faccio da solo le cose normali e sicure; per quelle importanti ti chiedo conferma." }
    }
}

function Test-ModalitaSviluppatore {
    param($sync)
    if (-not $sync) { return $false }
    return ([string]$sync.Config.sicurezza -eq 'sviluppatore')
}

function Test-ModalitaEnterprise {
    param($sync)
    if (-not $sync) { return $false }
    return ([string]$sync.Config.sicurezza -eq 'enterprise')
}

function Test-ModalitaHacker {
    param($sync)
    if (-not $sync) { return $false }
    return ([string]$sync.Config.sicurezza -eq 'hacker')
}

function Get-HackerDefault {
    # Impostazioni della modalita' HACKER. Per scelta dell'utente: NESSUN LIMITE.
    # - nessun_limite = $true  -> run_powershell esegue senza filtri e senza conferme.
    # - scope: elenco di bersagli autorizzati (per tracciare; vuoto = nessun vincolo).
    # Ogni azione resta comunque registrata nella scatola nera (audit).
    return @{
        attivo               = $false
        nessun_limite        = $true
        conferma_distruttivi = $false
        scope                = @()
        osint                = $true
        mini_agenti          = $true
    }
}

function Format-HackerInfo {
    param($sync)
    $h = $null
    try { $h = $sync.Config.hacker } catch { }
    if ($null -eq $h) { $h = Get-HackerDefault }
    $att = $false; try { $att = ([string]$sync.Config.sicurezza -eq 'hacker') } catch { }
    $scope = @($h.scope) | Where-Object { $_ }
    $out = @()
    $out += "MODALITA' HACKER - pentest + OSINT (nessun limite)"
    $out += ('  stato: ' + $(if ($att) { 'ATTIVA' } else { 'non attiva (usa /hacker on)' }))
    $out += ('  limiti: ' + $(if ([bool]$h.nessun_limite) { 'NESSUNO (run_powershell libero, policy aggirata; audit sempre attivo)' } else { 'standard (policy attiva)' }))
    $out += ('  scope dichiarato: ' + $(if ($scope.Count) { ($scope -join ' | ') } else { '(vuoto: nessun vincolo - dichiara i TUOI bersagli con /hacker scope <host>)' }))
    $out += ('  OSINT: ' + $(if ([bool]$h.osint) { 'attivo (/osint <tipo> <bersaglio>)' } else { 'off' }))
    $out += ('  mini-agenti: ' + $(if ([bool]$h.mini_agenti) { 'attivi (/mini <compito>)' } else { 'off' }))
    $out += '  comandi: /hacker on|off | scope <host|*.dominio|CIDR>'
    $out += "  USO CONSENTITO: solo su sistemi TUOI o con autorizzazione scritta (art. 615-ter c.p.)."
    return ($out -join "`n")
}
