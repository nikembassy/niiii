# ui_wait.ps1 -- ATTESE INTELLIGENTI sull'interfaccia. Invece di procedere "a tempo"
# (e sbagliare il clic se il programma e' lento), ZAP aspetta ATTIVAMENTE che compaia:
#   - una finestra (per titolo)            -> Wait-Finestra
#   - un elemento (per nome o automationId)-> Wait-Elemento  (UI Automation)
#   - un colore in un punto (x,y)          -> Wait-Colore    (pixel dello schermo)
# Lo strumento dell'agente e' 'attendi' (vedi brain\tools.ps1).

if (-not ('ZapWaitWin' -as [type])) {
    try {
        Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class ZapWaitWin {
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextLength(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    public static string Titolo(IntPtr h) {
        int n = GetWindowTextLength(h);
        var sb = new StringBuilder(n + 2);
        GetWindowText(h, sb, sb.Capacity);
        return sb.ToString();
    }
    public static List<IntPtr> ConTitolo(string parte) {
        var outl = new List<IntPtr>();
        EnumWindows(delegate(IntPtr h, IntPtr l) {
            if (!IsWindowVisible(h)) return true;
            string t = Titolo(h);
            if (!String.IsNullOrEmpty(t) && t.IndexOf(parte, StringComparison.OrdinalIgnoreCase) >= 0) outl.Add(h);
            return true;
        }, IntPtr.Zero);
        return outl;
    }
}
'@
    } catch { }
}

function Get-FinestraPerTitolo {
    param([string]$Titolo)
    if (-not $Titolo) { return [IntPtr]::Zero }
    try { $hw = @([ZapWaitWin]::ConTitolo($Titolo)); if ($hw.Count -gt 0) { return @($hw)[0] } } catch { }
    return [IntPtr]::Zero
}

function Wait-Finestra {
    param([string]$Titolo, [int]$TimeoutSec = 15)
    $fine = (Get-Date).AddSeconds([Math]::Max(1, [int]$TimeoutSec))
    while ((Get-Date) -lt $fine) {
        $h = Get-FinestraPerTitolo $Titolo
        if ($h -ne [IntPtr]::Zero) { return $h }
        Start-Sleep -Milliseconds 250
    }
    return [IntPtr]::Zero
}

function Wait-Elemento {
    param([IntPtr]$Hwnd = [IntPtr]::Zero, [string]$AutomationId = '', [string]$Testo = '', [int]$TimeoutSec = 15)
    try {
        Add-Type -AssemblyName UIAutomationClient -ErrorAction SilentlyContinue
        Add-Type -AssemblyName UIAutomationTypes  -ErrorAction SilentlyContinue
    } catch { }
    $fine = (Get-Date).AddSeconds([Math]::Max(1, [int]$TimeoutSec))
    while ((Get-Date) -lt $fine) {
        try {
            $AE = [System.Windows.Automation.AutomationElement]
            $radice = $null
            if ($Hwnd -ne [IntPtr]::Zero) { $radice = $AE::FromHandle($Hwnd) } else { $radice = $AE::RootElement }
            if ($radice) {
                $cond = $null
                if ($AutomationId) { $cond = New-Object System.Windows.Automation.PropertyCondition($AE::AutomationIdProperty, $AutomationId) }
                elseif ($Testo)    { $cond = New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, $Testo) }
                if ($cond) {
                    $el = $radice.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $cond)
                    if ($el) { return $el }
                }
            }
        } catch { }
        Start-Sleep -Milliseconds 300
    }
    return $null
}

function Wait-Colore {
    param([int]$X, [int]$Y, [string]$Hex, [int]$TimeoutSec = 15, [int]$Tolleranza = 24)
    try { Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue } catch { }
    $h = ([string]$Hex).Trim().TrimStart('#')
    if ($h.Length -ne 6) { return $false }
    $tr = [Convert]::ToInt32($h.Substring(0,2),16); $tg = [Convert]::ToInt32($h.Substring(2,2),16); $tb = [Convert]::ToInt32($h.Substring(4,2),16)
    $fine = (Get-Date).AddSeconds([Math]::Max(1, [int]$TimeoutSec))
    while ((Get-Date) -lt $fine) {
        try {
            $bmp = New-Object System.Drawing.Bitmap(1,1)
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.CopyFromScreen($X, $Y, 0, 0, (New-Object System.Drawing.Size(1,1)))
            $c = $bmp.GetPixel(0,0)
            $g.Dispose(); $bmp.Dispose()
            if ([Math]::Abs([int]$c.R - $tr) -le $Tolleranza -and [Math]::Abs([int]$c.G - $tg) -le $Tolleranza -and [Math]::Abs([int]$c.B - $tb) -le $Tolleranza) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 200
    }
    return $false
}

function Invoke-Attesa {
    # usato dallo strumento 'attendi'
    param([string]$Tipo, [string]$Valore, [int]$TimeoutSec = 15)
    $t = ([string]$Tipo).Trim().ToLower()
    if ($t -eq 'finestra') {
        $h = Wait-Finestra -Titolo $Valore -TimeoutSec $TimeoutSec
        if ($h -ne [IntPtr]::Zero) { return ('OK: finestra "' + $Valore + '" comparsa (handle ' + $h + ').') }
        return ('!TIMEOUT: finestra "' + $Valore + '" NON comparsa entro ' + $TimeoutSec + ' s. Non cliccare a caso: verifica che il programma si sia aperto.')
    }
    if ($t -eq 'elemento') {
        $el = $null
        if ($Valore -match '(?i)^id:(.+)$') { $el = Wait-Elemento -AutomationId $Matches[1].Trim() -TimeoutSec $TimeoutSec }
        else { $el = Wait-Elemento -Testo $Valore -TimeoutSec $TimeoutSec }
        if ($el) { return ('OK: elemento "' + $Valore + '" trovato. Ora puoi interagirci in sicurezza.') }
        return ('!TIMEOUT: elemento "' + $Valore + '" NON trovato entro ' + $TimeoutSec + ' s. Non cliccare a caso: potrebbe non essere ancora pronto.')
    }
    if ($t -eq 'colore') {
        $p = ([string]$Valore) -split '[,\s]+'
        if (@($p).Count -ge 3) {
            $ok = Wait-Colore -X ([int]$p[0]) -Y ([int]$p[1]) -Hex ([string]$p[2]) -TimeoutSec $TimeoutSec
            if ($ok) { return ('OK: colore ' + $p[2] + ' comparso in ' + $p[0] + ',' + $p[1] + '.') }
            return ('!TIMEOUT: colore ' + $p[2] + ' NON comparso in ' + $p[0] + ',' + $p[1] + ' entro ' + $TimeoutSec + ' s.')
        }
        return '!Uso: attendi colore  x,y,#RRGGBB'
    }
    return '!Tipo non valido (usa: finestra | elemento | colore).'
}
