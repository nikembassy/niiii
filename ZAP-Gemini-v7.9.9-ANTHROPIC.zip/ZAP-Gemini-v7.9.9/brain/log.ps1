﻿# log.ps1 -- Log leggibili e SENZA SEGRETI (richiesta esplicita: "log leggibili senza segreti").
# Ogni riga scritta passa da Protect-LogText; i file gia' scritti possono essere ripuliti
# con Protect-LogFile / Protect-TuttiILog.

function Protect-LogText {
    param([string]$Text)
    if (-not $Text) { return '' }
    $t = $Text
    # chiavi Google AI Studio: formato nuovo "AQ.xxxx" e classico "AIza..."
    $t = [regex]::Replace($t, 'AQ\.[A-Za-z0-9_\-]{10,}', 'AQ.***RIMOSSA***')
    $t = [regex]::Replace($t, 'AIza[0-9A-Za-z_\-]{20,}', 'AIza***RIMOSSA***')
    # v6: prefissi degli altri servizi IA (OpenAI, Groq, xAI, Perplexity, Cerebras, Fireworks, HuggingFace)
    $t = [regex]::Replace($t, 'sk-[A-Za-z0-9_\-]{16,}', 'sk-***RIMOSSA***')
    $t = [regex]::Replace($t, 'gsk_[A-Za-z0-9]{16,}', 'gsk_***RIMOSSA***')
    $t = [regex]::Replace($t, 'xai-[A-Za-z0-9]{16,}', 'xai-***RIMOSSA***')
    $t = [regex]::Replace($t, 'pplx-[A-Za-z0-9]{16,}', 'pplx-***RIMOSSA***')
    $t = [regex]::Replace($t, 'csk-[A-Za-z0-9]{16,}', 'csk-***RIMOSSA***')
    $t = [regex]::Replace($t, 'fw_[A-Za-z0-9]{16,}', 'fw_***RIMOSSA***')
    $t = [regex]::Replace($t, 'hf_[A-Za-z0-9]{16,}', 'hf_***RIMOSSA***')
    # e la parola "chiave = ..." / "chiave: ..." in chiaro
    $t = [regex]::Replace($t, '(?i)\bchiave\s*[:=]\s*([^\s"'',;}{]{6,})', 'chiave=***RIMOSSA***')
    # coppie chiave=valore / "chiave": "valore"
    # NB: la regola del Bearer va PRIMA di quella generica, altrimenti la generica
    # consuma la parola "Bearer" e lascia il token in chiaro.
    $t = [regex]::Replace($t, '(?i)bearer\s+[A-Za-z0-9\._\-]{12,}', 'Bearer ***RIMOSSA***')
    $t = [regex]::Replace($t, '(?i)("?(?:api[_-]?key|apikey|x-goog-api-key|authorization)"?\s*[:=]\s*)(["'']?)([^\s"'',;}{]{6,})', '$1***RIMOSSA***')
    $t = [regex]::Replace($t, '(?i)[?&]key=[A-Za-z0-9\._\-]{12,}', '?key=***RIMOSSA***')
    return $t
}

function Test-ContieneSegreti {
    # Usata dai test: dice se un testo contiene ancora qualcosa che sembra una chiave.
    param([string]$Text)
    if (-not $Text) { return $false }
    return [bool]([regex]::IsMatch($Text, 'AQ\.[A-Za-z0-9_\-]{10,}|AIza[0-9A-Za-z_\-]{20,}|sk-[A-Za-z0-9_\-]{16,}|gsk_[A-Za-z0-9]{16,}|xai-[A-Za-z0-9]{16,}|pplx-[A-Za-z0-9]{16,}|csk-[A-Za-z0-9]{16,}|fw_[A-Za-z0-9]{16,}|hf_[A-Za-z0-9]{16,}'))
}

function Protect-LogFile {
    param([string]$Path)
    if (-not $Path -or -not (Test-Path $Path)) { return $false }
    try {
        $raw = Get-Content -Path $Path -Raw -Encoding UTF8
        if ($null -eq $raw -or $raw -eq '') { return $false }
        $clean = Protect-LogText $raw
        if ($clean -ne $raw) { Set-Content -Path $Path -Value $clean -Encoding UTF8; return $true }
        return $false
    } catch { return $false }
}

function Add-LogLine {
    param([string]$Path, [string]$Text)
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
        Add-Content -Path $Path -Value ((Get-Date -Format 'o') + '  ' + (Protect-LogText $Text)) -Encoding UTF8
    } catch { }
}

function Protect-TuttiILog {
    param([string]$Base)
    $n = 0
    $dir = Join-Path $Base 'logs'
    if (-not (Test-Path $dir)) { return 0 }
    foreach ($f in @(Get-ChildItem -Path $dir -File -ErrorAction SilentlyContinue)) {
        if (Protect-LogFile $f.FullName) { $n++ }
    }
    return $n
}
