﻿# ============================================================================
#  computer_use.ps1  --  ZAP 7.0 : Computer Use (ciclo azione: click/scrive/trascina)
# ----------------------------------------------------------------------------
#  Oggi ZAP "guarda" lo schermo. Questo modulo gli fa fare il passo successivo:
#  AGIRE su qualunque programma Windows come farebbe una persona alla tastiera.
#  Flusso consigliato:  guarda_schermo (visione)  ->  azione_schermo (azione)  ->  guarda_schermo (verifica).
#  Ogni azione e' registrata in logs\computer_use.log. Guardrail attivi (vedi Tool-AzioneSchermo).
# ============================================================================

function Initialize-ComputerUse {
    if ('ZapInput' -as [type]) { return $true }
    $code = @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public class ZapInput {
    [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public InputUnion U; }
    [StructLayout(LayoutKind.Explicit)] public struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
    [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
    [DllImport("user32.dll")] public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    const uint INPUT_MOUSE=0, INPUT_KEYBOARD=1;
    const uint MDOWN=0x0002, MUP=0x0004, RDOWN=0x0008, RUP=0x0010, WHEEL=0x0800;
    const uint KEYUP=0x0002, UNICODE=0x0004;
    static int SZ = Marshal.SizeOf(typeof(INPUT));
    public static void Move(int x,int y){ SetCursorPos(x,y); }
    static void Mouse(uint f,int data=0){ INPUT[] a=new INPUT[1]; a[0].type=INPUT_MOUSE; a[0].U.mi.dwFlags=f; a[0].U.mi.mouseData=(uint)data; SendInput(1,a,SZ); }
    public static void Click(int x,int y){ Move(x,y); System.Threading.Thread.Sleep(60); Mouse(MDOWN); Mouse(MUP); }
    public static void DoubleClick(int x,int y){ Click(x,y); System.Threading.Thread.Sleep(90); Click(x,y); }
    public static void RightClick(int x,int y){ Move(x,y); System.Threading.Thread.Sleep(60); Mouse(RDOWN); Mouse(RUP); }
    public static void Scroll(int delta){ Mouse(WHEEL, delta); }
    public static void TypeChar(ushort c){ INPUT[] a=new INPUT[2]; a[0].type=INPUT_KEYBOARD; a[0].U.ki.wScan=c; a[0].U.ki.dwFlags=UNICODE; a[1].type=INPUT_KEYBOARD; a[1].U.ki.wScan=c; a[1].U.ki.dwFlags=UNICODE|KEYUP; SendInput(2,a,SZ); }
    public static void TypeText(string s){ foreach(char c in s){ TypeChar((ushort)c); System.Threading.Thread.Sleep(15); } }
    public static void KeyVk(ushort vk){ INPUT[] a=new INPUT[2]; a[0].type=INPUT_KEYBOARD; a[0].U.ki.wVk=vk; a[1].type=INPUT_KEYBOARD; a[1].U.ki.wVk=vk; a[1].U.ki.dwFlags=KEYUP; SendInput(2,a,SZ); }
    public static void Drag(int x1,int y1,int x2,int y2){ Move(x1,y1); System.Threading.Thread.Sleep(100); Mouse(MDOWN); System.Threading.Thread.Sleep(120); Move(x2,y2); System.Threading.Thread.Sleep(150); Mouse(MUP); }
    public static string ForegroundTitle(){ StringBuilder sb=new StringBuilder(512); GetWindowText(GetForegroundWindow(), sb, 512); return sb.ToString(); }
}
'@
    try { Add-Type -TypeDefinition $code -ErrorAction Stop; return $true } catch { return $false }
}

function Get-TastoSpeciale {
    param([string]$nome)
    switch (([string]$nome).Trim().ToLower()) {
        'invio'      { return 0x0D } 'enter'  { return 0x0D }
        'tab'        { return 0x09 }
        'esc'        { return 0x1B } 'escape' { return 0x1B }
        'spazio'     { return 0x20 }
        'backspace'  { return 0x08 }
        'canc'       { return 0x2E } 'delete' { return 0x2E }
        'su'         { return 0x26 } 'giu'    { return 0x28 } 'sinistra' { return 0x25 } 'destra' { return 0x27 }
        'f5'         { return 0x74 }
        default      { return 0x0D }
    }
}

function Write-CuLog {
    param([string]$base, [string]$msg)
    try {
        $dir = Join-Path $base 'logs'; if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        Add-Content -LiteralPath (Join-Path $dir 'computer_use.log') -Value ("[{0}] {1}" -f (Get-Date).ToString('s'), $msg)
    } catch { }
}

# ------------------------------- TOOL --------------------------------------

function Tool-AzioneSchermo {
    param([string]$base, $sync, [string]$azione, [int]$x = -1, [int]$y = -1, [int]$x2 = -1, [int]$y2 = -1, [string]$testo, [string]$tasto, [int]$delta = -120, [bool]$forza = $false)

    if (-not (Initialize-ComputerUse)) { return "Computer Use non disponibile su questo sistema." }

    # --- Guardrail -----------------------------------------------------------
    $modalita = 'smart'
    try { $modalita = [string]$sync.Config.modalita_ai } catch { }
    try { if ($sync -and $sync.Modalita) { $modalita = [string]$sync.Modalita } } catch { }

    if ($modalita -eq 'prudente' -and (-not $forza)) {
        return "Sono in modalita' PRUDENTE. Per eseguire l'azione '$azione' richiama azione_schermo con forza=true."
    }
    # app consentite (se configurate): agisci solo sulla finestra in primo piano elencata
    $consentite = @()
    try { $consentite = @($sync.Config.computer_use.app_consentite) } catch { }
    $attiva = [ZapInput]::ForegroundTitle()
    if ($consentite.Count -gt 0) {
        $ok = $false
        foreach ($pat in $consentite) { if ($attiva -like "*$pat*") { $ok = $true; break } }
        if (-not $ok) { return "Azione bloccata: la finestra attiva '$attiva' non e' tra quelle consentite." }
    }

    # --- Esecuzione ----------------------------------------------------------
    $az = ([string]$azione).Trim().ToLower()
    switch ($az) {
        'click'        { [ZapInput]::Click($x, $y) }
        'doppio_click' { [ZapInput]::DoubleClick($x, $y) }
        'click_destro' { [ZapInput]::RightClick($x, $y) }
        'muovi'        { [ZapInput]::Move($x, $y) }
        'scroll'       { [ZapInput]::Scroll($delta) }
        'trascina'     { [ZapInput]::Drag($x, $y, $x2, $y2) }
        'digita'       { [ZapInput]::TypeText([string]$testo) }
        'tasto'        { [ZapInput]::KeyVk((Get-TastoSpeciale $tasto)) }
        default        { return "Azione sconosciuta: $azione. Usa click, doppio_click, click_destro, muovi, scroll, trascina, digita, tasto." }
    }
    Write-CuLog $base "azione=$az x=$x y=$y x2=$x2 y2=$y2 testo='$testo' tasto='$tasto' finestra='$attiva' modalita=$modalita"
    Start-Sleep -Milliseconds 120
    return "Fatto: $az sulla finestra '$attiva'. Verifica con guarda_schermo."
}
