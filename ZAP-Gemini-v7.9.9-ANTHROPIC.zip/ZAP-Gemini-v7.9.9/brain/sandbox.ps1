# sandbox.ps1 -- MODALITA' ISOLATA (containment a livello di SISTEMA).
# Esegue i comandi in un processo PowerShell SEPARATO, dentro un "Job Object" di Windows con
# LIMITI reali: memoria massima, tempo CPU, numero di processi, e CHIUSURA GARANTITA allo
# scadere del timeout (chiude anche i processi figli). E' il contenimento di sistema che si
# aggiunge al filtro permessi di policy.ps1 (che invece e' "nel codice").
# Si attiva con /sandbox on. Default: spento. Onesta': contiene RISORSE e TEMPI, ma gira con
# i TUOI privilegi (non li riduce): per quello serve un utente Windows limitato.
#
# v7.9.7 HARDENING (da review di sicurezza):
#   1) FIX LIMITE MEMORIA: i LimitFlags usavano 0x400 (= DIE_ON_UNHANDLED_EXCEPTION) al posto
#      di 0x200 (= JOB_OBJECT_LIMIT_JOB_MEMORY): il JobMemoryLimit NON veniva applicato.
#      Ora: PROCESS_TIME(0x2) | JOB_TIME(0x4) | ACTIVE_PROCESS(0x8) | JOB_MEMORY(0x200) | KILL_ON_JOB_CLOSE(0x2000).
#   2) TIME-OF-CHECK/TOCTOU ridotta: il Job Object viene creato/impostato PRIMA di avviare il
#      processo (prima avveniva dopo), cosi' la finestra in cui il figlio gira senza limiti e'
#      minima. (Resto del rischio documentato nel rapporto: per azzerarlo serve CreateProcess
#      con CREATE_SUSPENDED + AssignProcessToJobObject + ResumeThread.)
#   3) FLUSH output: dopo WaitForExit(timeout) viene chiamato WaitForExit() senza argomenti per
#      svuotare i buffer asincroni (prima si poteva leggere output incompleto su uscita rapida).
#   4) JOB_TIME totale: oltre al tempo CPU per-processo, viene posto un tetto al tempo CPU
#      dell'intero job (PerJobUserTimeLimit).


if (-not ('ZapJob' -as [type])) {
    try {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct ZapIo {
    public ulong ReadOperationCount; public ulong WriteOperationCount; public ulong OtherOperationCount;
    public ulong ReadTransferCount;  public ulong WriteTransferCount;  public ulong OtherTransferCount;
}
[StructLayout(LayoutKind.Sequential)]
public struct ZapBasic {
    public long PerProcessUserTimeLimit;
    public long PerJobUserTimeLimit;
    public uint LimitFlags;
    public UIntPtr MinimumWorkingSetSize;
    public UIntPtr MaximumWorkingSetSize;
    public uint ActiveProcessLimit;
    public UIntPtr Affinity;
    public uint PriorityClass;
    public uint SchedulingClass;
}
[StructLayout(LayoutKind.Sequential)]
public struct ZapExt {
    public ZapBasic BasicLimitInformation;
    public ZapIo IoInfo;
    public UIntPtr ProcessMemoryLimit;
    public UIntPtr JobMemoryLimit;
    public UIntPtr PeakProcessMemoryUsed;
    public UIntPtr PeakJobMemoryUsed;
}
public static class ZapJob {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr CreateJobObject(IntPtr a, string name);
    [DllImport("kernel32.dll")] public static extern bool SetInformationJobObject(IntPtr hJob, int infoClass, IntPtr lpInfo, uint cbInfo);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool TerminateJobObject(IntPtr hJob, uint code);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool CloseHandle(IntPtr h);
}
'@
    } catch { }
}

function Get-SandboxDefault {
    return @{ attivo = $false; memoria_mb = 512; cpu_sec = 60; max_processi = 4 }
}

function New-ZapJobLimits {
    # Costruisce la struct dei limiti e la applica al Job Object. Ritorna $true se impostata.
    param([IntPtr]$Job, [int]$MemoryMb, [int]$CpuSec, [int]$MaxProc)
    if ($Job -eq [IntPtr]::Zero) { return $false }
    try {
        $info = New-Object ZapExt
        # v7.9.7: flag CORRETTI (vedi header). 0x200 = JOB_OBJECT_LIMIT_JOB_MEMORY.
        $info.BasicLimitInformation.LimitFlags = ([uint32]0x2) -bor ([uint32]0x4) -bor ([uint32]0x8) -bor ([uint32]0x200) -bor ([uint32]0x2000)
        $info.BasicLimitInformation.ActiveProcessLimit = [uint32]$MaxProc
        $info.BasicLimitInformation.PerProcessUserTimeLimit = [long]([TimeSpan]::FromSeconds($CpuSec).Ticks)
        $info.BasicLimitInformation.PerJobUserTimeLimit     = [long]([TimeSpan]::FromSeconds($CpuSec).Ticks)
        $info.JobMemoryLimit = [UIntPtr][uint64]($MemoryMb * 1MB)
        $sz = [System.Runtime.InteropServices.Marshal]::SizeOf($info)
        $ptr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal([int]$sz)
        try {
            [System.Runtime.InteropServices.Marshal]::StructureToPtr($info, $ptr, $false)
            return [ZapJob]::SetInformationJobObject($Job, 9, $ptr, [uint32]$sz)   # 9 = JobObjectExtendedLimitInformation
        } finally { [System.Runtime.InteropServices.Marshal]::FreeHGlobal($ptr) }
    } catch { return $false }
}

function Invoke-InSandbox {
    param($sync, [string]$Code, [int]$TimeoutSec = 0)
    if (-not $Code) { return '(nessun comando)' }
    $sb = $null
    try { $sb = $sync.Config.sandbox } catch { }
    if ($null -eq $sb) { $sb = Get-SandboxDefault }
    $memMb = 512; $cpuSec = 60; $maxProc = 4
    try { if ($sb.memoria_mb)   { $memMb  = [int]$sb.memoria_mb } } catch { }
    try { if ($sb.cpu_sec)      { $cpuSec = [int]$sb.cpu_sec } } catch { }
    try { if ($sb.max_processi) { $maxProc = [int]$sb.max_processi } } catch { }
    if ($TimeoutSec -le 0) { try { $TimeoutSec = [int]$sync.Config.timeout_powershell_sec } catch { } }
    if ($TimeoutSec -le 0) { $TimeoutSec = 120 }

    # Directory temporanea PRIVATA per la sessione (evita che altri leggano/scrivano il .ps1).
    $base = $env:TEMP; if (-not $base) { $base = (Get-Location).Path }
    $g = [guid]::NewGuid().ToString('N')
    $dir = Join-Path $base ('zap_sb_' + $g)
    $scriptF = Join-Path $dir 'run.ps1'
    try { [void](New-Item -ItemType Directory -Path $dir -Force) } catch { $dir = $base; $scriptF = Join-Path $dir ('zap_sb_' + $g + '.ps1') }
    try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($scriptF, ("`$ErrorActionPreference='Continue'`r`n" + $Code + "`r`n"), $enc)
    } catch { return '!Non riesco a preparare il comando nella modalita isolata.' }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'powershell.exe'
    $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $scriptF + '"'
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.WorkingDirectory = $dir

    $proc = $null; $job = [IntPtr]::Zero; $inJob = $false
    try {
        # v7.9.7: (1) crea e configura il Job Object PRIMA di avviare il processo.
        try { $job = [ZapJob]::CreateJobObject([IntPtr]::Zero, $null) } catch { $job = [IntPtr]::Zero }
        $haveLimits = $false
        if ($job -ne [IntPtr]::Zero) { $haveLimits = New-ZapJobLimits -Job $job -MemoryMb $memMb -CpuSec $cpuSec -MaxProc $maxProc }
        if (-not $haveLimits) {
            # Se non riesco a imporre i limiti, NON eseguo "liscio": lo dichiaro.
            try { if ($job -ne [IntPtr]::Zero) { [void][ZapJob]::CloseHandle($job) } } catch { }
            return '!Modalita isolata non disponibile: impossibile impostare i limiti del Job Object. Comando NON eseguito per sicurezza.'
        }

        # v7.9.7: (2) avvia il processo, (3) assegnalo SUBITO al job (finestra TOCTOU minima).
        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        [void]$proc.Start()
        try { $inJob = [ZapJob]::AssignProcessToJobObject($job, $proc.Handle) } catch { $inJob = $false }

        $outTask = $proc.StandardOutput.ReadToEndAsync()
        $errTask = $proc.StandardError.ReadToEndAsync()
        $ok = $proc.WaitForExit($TimeoutSec * 1000)
        if ($ok) { try { $proc.WaitForExit() } catch { } }   # v7.9.7: flush dei buffer asincroni
        if (-not $ok) {
            try { if ($inJob -and $job -ne [IntPtr]::Zero) { [void][ZapJob]::TerminateJobObject($job, 1) } } catch { }
            try { if (-not $proc.HasExited) { $proc.Kill() } } catch { }
            try { & taskkill.exe /T /F /PID $proc.Id 2>&1 | Out-Null } catch { }
            return ('!TIMEOUT (modalita isolata) dopo ' + $TimeoutSec + ' s: processo e figli terminati.')
        }
        $out = ''; try { $out = [string]$outTask.Result } catch { }
        $err = ''; try { $err = [string]$errTask.Result } catch { }
        $r = ''
        if ($out.Trim()) { $r += $out.Trim() }
        if ($err.Trim()) { if ($r) { $r += "`n" }; $r += '!ERRORI:' + "`n" + $err.Trim() }
        if (-not $r) { $r = '(eseguito in modalita isolata, senza output)' }
        if ($r.Length -gt 8000) { $r = $r.Substring(0,7800) + "`n...[output troncato]" }
        return $r
    } catch {
        return '!Errore nella modalita isolata: ' + $_.Exception.Message
    } finally {
        try { if (-not $proc.HasExited) { $proc.Kill() } } catch { }
        try { if ($job -ne [IntPtr]::Zero) { [void][ZapJob]::CloseHandle($job) } } catch { }
        try { Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
        try { Remove-Item $scriptF -Force -ErrorAction SilentlyContinue } catch { }
    }
}

function Get-SandboxInfo {
    param($sync)
    $sb = $null
    try { $sb = $sync.Config.sandbox } catch { }
    if ($null -eq $sb) { $sb = Get-SandboxDefault }
    $attivo = $false; try { $attivo = [bool]$sb.attivo } catch { }
    $mem = 512; try { if ($sb.memoria_mb) { $mem = [int]$sb.memoria_mb } } catch { }
    $cpu = 60;  try { if ($sb.cpu_sec) { $cpu = [int]$sb.cpu_sec } } catch { }
    $mp  = 4;   try { if ($sb.max_processi) { $mp = [int]$sb.max_processi } } catch { }
    $ok = $false; try { $ok = [bool]('ZapJob' -as [type]) } catch { }
    $out = @()
    $out += 'MODALITA ISOLATA (sandbox di sistema tramite Job Object)'
    $out += ('  stato: ' + $(if ($attivo) { 'ATTIVA' } else { 'spenta' }))
    $out += ('  limiti: memoria ' + $mem + ' MB, tempo CPU ' + $cpu + ' s (job), processi ' + $mp + ', chiusura garantita dei figli')
    $out += ('  motore Job Object disponibile: ' + $(if ($ok) { 'si' } else { 'no' }))
    $out += '  comandi: /sandbox on | off'
    $out += '  Nota onesta: contiene risorse e tempi, ma NON riduce i privilegi (gira come te). Per quello serve un utente Windows limitato.'
    return ($out -join "`n")
}
