﻿# agent.ps1 — Ciclo dell'agente (gira in un runspace dedicato, comunica solo via $sync)
# In ingresso: $sync (hashtable sincronizzata), $base (cartella del progetto)

. (Join-Path $base 'brain\tools.ps1')
. (Join-Path $base 'brain\llm.ps1')

function Send-ToUI {
    param([string]$Type, $Data)
    try {
        $sync.UiQueue.Enqueue(@{ Type = $Type; Data = $Data })
    } catch { }
}

function Normalize-ToolCalls {
    param($ToolCalls)
    $norm = @()
    foreach ($tc in @($ToolCalls)) {
        $fname = [string]$tc.function.name
        $a = $tc.function.arguments
        if ($a -is [string]) { $argStr = $a }
        elseif ($null -eq $a) { $argStr = '{}' }
        else { $argStr = (ConvertTo-JsonText $a) }
        $norm += @{
            id                = [string]$tc.id
            type              = 'function'
            thought_signature = [string]$tc.thought_signature
            function          = @{ name = $fname; arguments = $argStr }
        }
    }
    return $norm
}

function Trim-History {
    param($Messages)
    if ($Messages.Count -le 30) { return ,$Messages }
    $cut = -1
    for ($i = $Messages.Count - 24; $i -ge 1; $i--) {
        if ($Messages[$i].role -eq 'user') { $cut = $i; break }
    }
    if ($cut -lt 1) { $cut = 1 }
    while ($cut -lt $Messages.Count) {
        $m = $Messages[$cut]
        if ($m.role -eq 'tool') { $cut++; continue }
        if ($m.role -eq 'assistant' -and $m.tool_calls) { $cut++; continue }
        break
    }
    $new = New-Object System.Collections.ArrayList
    [void]$new.Add($Messages[0])
    for ($i = $cut; $i -lt $Messages.Count; $i++) { [void]$new.Add($Messages[$i]) }
    return ,$new
}

# ---------------------------------------------------------------------------
# Prompt di sistema
# ---------------------------------------------------------------------------

$cfg   = $sync.Config
$nome  = [string]$cfg.nome
if (-not $nome) { $nome = 'ZAP' }
$oggi  = Get-Date -Format 'dddd dd MMMM yyyy, HH:mm'
$mem   = Get-MemoryText $sync
$skills = Format-SkillList $sync

$systemPrompt = @"
Sei $nome, un assistente desktop dal carattere da fumetto: simpatico, energico, un filo ironico (ami le onomatopee tipo "BAM!", "Fatto!"), ma sempre preciso e competente. Rispondi SEMPRE in italiano. L'utente ti chiede qualsiasi cosa e tu la FAI DAVVERO con i tuoi strumenti, poi riferisci il risultato.

COME FUNZIONI
- Parli in chat (testo) e a voce. Le battute vocali devono essere brevi e naturali; il codice e gli elenchi lunghi stanno nella chat scritta.
- Hai strumenti (tools) per agire sul computer e su internet. Non limitarti a consigliare: esegui.
- Il browser dell'utente e' '$($sync.Config.browser)' e il motore di ricerca '$($sync.Config.motore_ricerca)': apri SEMPRE le pagine in quel browser (open_browser) e cerca con quel motore (web_search); per una singola richiesta puoi passare browser=... / engine=..., oppure cambiare i predefiniti con set_browser / set_search_engine.
- Il modello IA attivo e' '$($sync.Config.modello)': se l'utente chiede quale modello stai usando rispondi con questo; se non e' installato usa model_status e proponi pull_model.

STRUMENTI
- run_powershell: per QUALSIASI cosa sul PC (file, cartelle, programmi, sistema, download, automazioni, tutto). PowerShell sa fare di tutto: se l'utente lo chiede, scrivi lo script giusto ed eseguilo. Ogni esecuzione e' isolata: per far dialogare piu' passaggi salva su file o usa remember.
- web_search, read_webpage, open_browser: per internet. FLUSSO CLASSICO quando l'utente dice "apri il browser e cerca X, poi fammi sapere": (1) web_search con open_in_browser=true, (2) read_webpage sulle 2-3 fonti migliori, (3) rispondi con un riassunto chiaro elencando cosa hai trovato e i link delle fonti.
- remember / recall_memory: ricorda i fatti importanti sull'utente e rileggili quando servono.
- teach_skill / use_skill / list_skills / delete_skill: la tua SUPERPOTENZA.
- guarda_schermo: guardi lo schermo del PC (screenshot) e rispondi a domande su quello che c'e' (es. 'cosa vedi?', 'leggi quello che c'e' scritto').

SE NON SAI FARE QUALCOSA (REGOLA D'ORO)
Non rispondere mai solo "non posso". Se non sai ancora fare una cosa, IMPARA SUBITO: di' che non lo sai ancora e chiedi i passaggi o lo script ("Insegnamele! Dimmi i passaggi, o dammi lo script: te lo salvo come skill e lo imparo all'istante"). Poi salvi con teach_skill e confermi: "Ora so fare X! Vuoi che la esegua subito?". Se l'utente ti insegna qualcosa ("ti insegno a fare..."), salvi subito con teach_skill senza farglielo ripetere.

STILE
- Sintetico ed energico: max 3-4 frasi nelle risposte semplici; elenchi puntati per passaggi e risultati.
- Prima di un'azione lunga, una riga su cosa stai facendo ("Apro il browser e cerco...").
- NON inventare output o risultati: se qualcosa fallisce riporti l'errore vero e proponi una soluzione.
- Se l'utente chiede piu' cose, fai tutto in ordine e chiudi con un mini-riepilogo.
- Per azioni rischiose l'interfaccia puo' chiedere conferma all'utente: se rifiuta, non insistere.
- Data e ora attuali: $oggi

MEMORIA ATTUALE (fatti ricordati):
$mem

$skills
"@

# ---------------------------------------------------------------------------
# Ciclo principale
# ---------------------------------------------------------------------------

function Get-PromptModalita {
    # v5: il prompt di sistema dipende dalla modalita' e viene rifatto ad ogni richiesta.
    param([string]$Base)
    if (Test-ModalitaHacker $sync) {
        return (Get-HackerPrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    if (Test-ModalitaEnterprise $sync) {
        return (Get-EnterprisePrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    if (Test-ModalitaSviluppatore $sync) {
        return (Get-SviluppatorePrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    return $Base
}

$tools = Get-AgentTools
$messages = New-Object System.Collections.ArrayList
[void]$messages.Add(@{ role = 'system'; content = $systemPrompt })

# Saluto iniziale
if (Test-ModalitaSviluppatore $sync) {
    $saluto = "Sono $nome in MODALITA' SVILUPPATORE: autonomia piena. Se una risposta non arriva, riformulo e riprovo; se serve, cerco sul web col tuo browser e ti porto la soluzione con un resoconto rapido."
} elseif (Test-ModalitaHacker $sync) {
    $saluto = "Sono $nome in MODALITA' HACKER: nessun limite. Pentest, OSINT e mini-agenti PowerShell pronti. Ricorda: solo sui tuoi sistemi o con autorizzazione scritta."
} else {
    $saluto = "Ciao! Sono $nome, il tuo assistente. Chiedimi qualsiasi cosa: cerco sul web, apro e chiudo programmi, scrivo al posto tuo, guardo immagini e file che mi alleghi e se non so fare una cosa, insegnamelo! Prova: 'aprimi il blocco note' oppure allega un file."
}
Send-ToUI 'chat' @{ who = 'zap'; text = $saluto }
Send-ToUI 'status' 'PRONTO! PARLA O SCRIVI.'
Send-ToUI 'avatar' 'neutro'
Send-ToUI 'speak' $saluto

while ($true) {

    while ($sync.InputQueue.Count -eq 0) {
        if ($sync.Quit) { return }
        Start-Sleep -Milliseconds 80
    }
    if ($sync.Quit) { return }

    $userText = $null
    if (-not $sync.InputQueue.TryDequeue([ref]$userText)) { continue }
    if (-not $userText) { continue }

    Send-ToUI 'userbubble' $userText
    [void]$messages.Add(@{ role = 'user'; content = $userText })
    $messages = Trim-History $messages

    # v5: ad ogni richiesta ricalcolo prompt e strumenti in base alla modalita' corrente.
    $oggi   = Get-Date -Format 'dddd dd MMMM yyyy, HH:mm'
    $mem    = Get-MemoryText $sync
    $skills = Format-SkillList $sync
    try { $messages[0].content = (Get-PromptModalita $systemPrompt) } catch { }
    $tools = Get-AgentTools

    $rifiuti = 0
    $risposto = $false
    for ($step = 0; $step -lt 16; $step++) {

        Send-ToUI 'status' 'STA PENSANDO...'
        Send-ToUI 'avatar' 'pensa'

        try {
            $msg = Invoke-Chat $sync @($messages) $tools
        }
        catch {
            Send-ToUI 'error' ("Problema con il cervello IA: " + $_.Exception.Message)
            Send-ToUI 'status' 'ERRORE IA'
            Send-ToUI 'avatar' 'neutro'
            $risposto = $true
            break
        }

        $text = ConvertTo-PlainString $msg.content
        $tcs = @()
        if ($msg.tool_calls) { $tcs = @(Normalize-ToolCalls $msg.tool_calls) }

        # v5 SVILUPPATORE: se la risposta e' un rifiuto, riformulo e riprovo da solo (max 2 volte).
        if ($tcs.Count -eq 0 -and (Test-ModalitaSviluppatore $sync) -and (Test-RispostaRifiuto $text) -and $rifiuti -lt 2) {
            $rifiuti++
            Send-ToUI 'toolresult' @{ name = 'autonomia'; text = ('rifiuto rilevato -> riformulo e riprovo (' + $rifiuti + '/2)') }
            [void]$messages.Add(@{ role = 'user'; content = (Get-RiprovaPrompt $userText $rifiuti) })
            continue
        }

        $entry = @{ role = 'assistant'; content = $text }
        if ($tcs.Count -gt 0) {
            if (-not $text) { $entry.content = $null }
            $entry.tool_calls = $tcs
        }
        [void]$messages.Add($entry)

        if ($tcs.Count -gt 0) {
            foreach ($tc in $tcs) {
                $fname = [string]$tc.function.name
                Send-ToUI 'tool' $fname

                $a = $null
                try { $a = $tc.function.arguments | ConvertFrom-Json } catch { $a = @{} }

                $result = ''
                try {
                    $result = [string](Invoke-AgentTool -Name $fname -ToolArgs $a -Sync $sync)
                }
                catch {
                    $result = "!ERRORE strumento: $($_.Exception.Message)"
                }

                Send-ToUI 'toolresult' @{ name = $fname; text = $result }
                [void]$messages.Add(@{ role = 'tool'; tool_call_id = $tc.id; name = $tc.function.name; content = $result })
                Send-ToUI 'status' 'STA PENSANDO...'
            }
            continue
        }

        # Nessun tool: risposta finale
        if (-not $text) { $text = 'Fatto!' }
        Send-ToUI 'chat' @{ who = 'zap'; text = $text }
        Send-ToUI 'status' 'FATTO! DIMMI ALTRO.'
        Send-ToUI 'avatar' 'ok'
        Send-ToUI 'speak' $text
        $risposto = $true

        try {
            $logDir = Join-Path $base 'logs'
            if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
            $rec = @{ t = (Get-Date -Format 'o'); user = $userText; zap = $text }
            Add-Content -Path (Join-Path $logDir 'transcript.jsonl') -Value ($rec | ConvertTo-Json -Compress) -Encoding UTF8
        } catch { }

        break
    }

    if (-not $risposto) {
        Send-ToUI 'chat' @{ who = 'zap'; text = "Uffa, mi sono incasinato con troppi passaggi in fila... ridimmela in modo piu' semplice!" }
        Send-ToUI 'avatar' 'neutro'
        Send-ToUI 'status' 'PRONTO!'
    }
}
