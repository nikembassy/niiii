# errori.ps1 -- AUTODIAGNOSI: legge l'errore di un comando e suggerisce la causa e la mossa
# giusta, cosi' ZAP si corregge invece di riprovare a caso. Funzione PURA (nessun effetto).

function Get-DiagnosiErrore {
    param([string]$Testo)
    if (-not $Testo) { return '' }
    $t = [string]$Testo
    if ($t -match '(?i)accesso negato|access is denied|permesso negato|non autorizzato|requires elevation|richiede privilegi|requested registry access') {
        return 'Permessi insufficienti: serve l amministratore. Riapri ZAP con AVVIA_ADMIN.bat, oppure scrivi in una cartella consentita.'
    }
    if ($t -match '(?i)non riconosciuto|not recognized|commandnotfound|is not recognized|termine .* non') {
        return 'Comando/programma non trovato: controlla il nome (battitura) oppure installalo / aggiungilo al PATH.'
    }
    if ($t -match '(?i)impossibile trovare il percorso|cannot find path|does not exist|non esiste') {
        return 'Percorso inesistente: verifica il percorso; se devi crearlo, usa prima New-Item -ItemType Directory.'
    }
    if ($t -match '(?i)import-module|modulo.*non trovato|module.*not found|get-command.*non') {
        return 'Modulo PowerShell mancante: installalo con Install-Module (o verifica di usare Windows PowerShell 5.1).'
    }
    if ($t -match '(?i)utilizzato da un altro processo|being used by another process|in uso') {
        return 'File in uso da un altro programma: chiudilo e riprova (o usa un nome diverso).'
    }
    if ($t -match '(?i)impossibile connettersi|unable to connect|no such host|timed out|non risponde|connessione') {
        return 'Problema di rete/connessione: controlla connessione, sito o proxy e riprova.'
    }
    if ($t -match '(?i)parameterbinding|parametro.*non|parameter cannot|cannot bind|ambig') {
        return 'Parametri errati: controlla la sintassi del comando (nomi e valori dei parametri).'
    }
    if ($t -match '(?i)unexpected token|sintassi|terminator|manca.*parentesi|parse error') {
        return 'Errore di sintassi PowerShell: controlla parentesi, virgolette e apici (e i blocchi { }).'
    }
    if ($t -match '(?i)g[ia]+ esiste|already exists') {
        return 'Il file/la cartella esiste gia: aggiungi -Force oppure usa un altro nome.'
    }
    return 'Errore non classificato: leggi il messaggio per intero e prova un approccio piu semplice, un passo per volta.'
}
