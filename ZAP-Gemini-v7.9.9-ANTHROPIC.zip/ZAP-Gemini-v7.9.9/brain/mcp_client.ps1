﻿# ============================================================================
#  mcp_client.ps1  --  ZAP 7.0 : client MCP (Model Context Protocol, stdio)
# ----------------------------------------------------------------------------
#  Collega ZAP a server MCP esterni (Gmail, Drive, Slack, GitHub, Notion, DB...).
#  Il protocollo e' JSON-RPC 2.0, un messaggio per riga (newline-delimited)
#  su stdin/stdout del processo del server. Flusso: initialize -> initialized
#  -> tools/list | tools/call.  Riferimento: spec MCP, trasporto "stdio".
# ============================================================================

function Get-McpConfigPath { param([string]$base) return (Join-Path $base 'mcp.json') }

function Get-McpServers {
    param([string]$base)
    $p = Get-McpConfigPath $base
    if (-not (Test-Path -LiteralPath $p)) { return @() }
    try { return @((Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json)) } catch { return @() }
}

function Save-McpServers {
    param([string]$base, $servers)
    (ConvertTo-Json -InputObject @($servers) -Depth 8) | Set-Content -LiteralPath (Get-McpConfigPath $base) -Encoding UTF8
}

function Read-McpLine {
    # Legge una riga con TIMEOUT reale, cosi' ZAP non resta bloccato se il server non risponde.
    param($proc, [int]$milliseconds)
    if ($milliseconds -le 0) { return '__TIMEOUT__' }
    $t = $proc.StandardOutput.ReadLineAsync()
    if ($t.Wait($milliseconds)) { return $t.Result }
    return '__TIMEOUT__'
}

function Invoke-McpStdio {
    # Avvia un server MCP, esegue l'handshake e invia UNA richiesta; ritorna l'oggetto risposta.
    param([string]$comando, [string]$metodo, $params = @{}, [int]$timeoutSec = 30)

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = "$env:ComSpec"            # cmd.exe /c <comando>
    $psi.Arguments              = "/c $comando"
    $psi.RedirectStandardInput  = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    try { $proc = [System.Diagnostics.Process]::Start($psi) }
    catch { return @{ error = "Avvio del server MCP fallito: $($_.Exception.Message)" } }

    try {
        $deadline = (Get-Date).AddSeconds($timeoutSec)
        function Rm { param($max); Read-McpLine -proc $proc -milliseconds ([int][math]::Max(0, ($max - (Get-Date)).TotalMilliseconds)) }

        # 1) handshake 'initialize'
        $init = @{ jsonrpc='2.0'; id=1; method='initialize'; params=@{
                    protocolVersion = '2026-07-28'
                    capabilities    = @{}
                    clientInfo      = @{ name='ZAP'; version='7.0' } } }
        $proc.StandardInput.WriteLine((ConvertTo-Json -InputObject $init -Depth 8 -Compress))
        $proc.StandardInput.Flush()

        $initOk = $false
        while ((Get-Date) -lt $deadline) {
            $line = Rm $deadline
            if ($line -eq '__TIMEOUT__') { break }
            if ($null -eq $line) { break }
            if (-not $line.Trim()) { continue }
            try { $obj = $line | ConvertFrom-Json } catch { continue }
            if ($obj.id -eq 1) { $initOk = $true; break }
        }
        if (-not $initOk) { return @{ error = "Handshake MCP fallito (server: $comando)" } }

        # 2) notifica 'initialized'
        $notif = @{ jsonrpc='2.0'; method='notifications/initialized'; params=@{} }
        $proc.StandardInput.WriteLine((ConvertTo-Json -InputObject $notif -Depth 4 -Compress))
        $proc.StandardInput.Flush()

        # 3) richiesta vera
        $req = @{ jsonrpc='2.0'; id=2; method=$metodo; params=$params }
        $proc.StandardInput.WriteLine((ConvertTo-Json -InputObject $req -Depth 12 -Compress))
        $proc.StandardInput.Flush()

        while ((Get-Date) -lt $deadline) {
            $line = Rm $deadline
            if ($line -eq '__TIMEOUT__') { break }
            if ($null -eq $line) { break }
            if (-not $line.Trim()) { continue }
            try { $obj = $line | ConvertFrom-Json } catch { continue }
            if ($obj.id -eq 2) { return $obj }
        }
        return @{ error = "Nessuna risposta per '$metodo' entro $timeoutSec s." }
    }
    finally {
        try { if (-not $proc.HasExited) { $proc.Kill() } } catch { }
    }
}

# ------------------------------- TOOLS -------------------------------------

function Tool-McpAggiungi {
    param([string]$base, [string]$id, [string]$comando)
    if (-not $id -or -not $comando) { return "Servono l'id e il comando del server MCP. Es: id='fs', comando='npx -y @modelcontextprotocol/server-filesystem C:\documenti'." }
    $srv = @(Get-McpServers $base | Where-Object { $_.id -ne $id })
    $srv += [pscustomobject]@{ id = $id; comando = $comando }
    Save-McpServers $base $srv
    $r = Invoke-McpStdio -comando $comando -metodo 'tools/list'
    if ($r.error) { return "Server '$id' salvato, ma la connessione e' fallita: $($r.error)" }
    $n = @($r.result.tools).Count
    return "Server MCP '$id' collegato. Strumenti esposti: $n. Usa mcp_strumenti '$id' per l'elenco."
}

function Tool-McpLista {
    param([string]$base)
    $srv = @(Get-McpServers $base)
    if ($srv.Count -eq 0) { return "Nessun server MCP configurato. Usa mcp_aggiungi per collegarne uno." }
    return "Server MCP configurati ($($srv.Count)):`n" + (($srv | ForEach-Object { "  - $($_.id): $($_.comando)" }) -join "`n")
}

function Tool-McpStrumenti {
    param([string]$base, [string]$id)
    $s = @(Get-McpServers $base | Where-Object { $_.id -eq $id })[0]
    if (-not $s) { return "Server MCP '$id' non trovato." }
    $r = Invoke-McpStdio -comando $s.comando -metodo 'tools/list'
    if ($r.error) { return "Errore: $($r.error)" }
    $out = foreach ($t in @($r.result.tools)) { "  - $($t.name): $($t.description)" }
    return "Strumenti di '$id':`n" + ($out -join "`n")
}

function Tool-McpChiama {
    param([string]$base, [string]$id, [string]$strumento, [string]$argomenti_json)
    $s = @(Get-McpServers $base | Where-Object { $_.id -eq $id })[0]
    if (-not $s) { return "Server MCP '$id' non trovato." }
    $argomenti = $null
    if ($argomenti_json) { try { $argomenti = $argomenti_json | ConvertFrom-Json } catch { $argomenti = $null } }
    if ($null -eq $argomenti) { $argomenti = @{} }
    $params = @{ name = $strumento; arguments = $argomenti }
    $r = Invoke-McpStdio -comando $s.comando -metodo 'tools/call' -params $params -timeoutSec 60
    if ($r.error) { return "Errore MCP: $($r.error)" }
    return (ConvertTo-Json -InputObject $r.result -Depth 12)
}

function Tool-McpRimuovi {
    param([string]$base, [string]$id)
    $srv = @(Get-McpServers $base | Where-Object { $_.id -ne $id })
    Save-McpServers $base $srv
    return "Server MCP '$id' rimosso."
}
