﻿# mini_agenti.ps1 -- MINI-AGENTI PowerShell a BASSO CONSUMO DI RAM (ZAP v7.9.8).
# ---------------------------------------------------------------------------
#  Ogni mini-agente e' un compito PowerShell eseguito in un RUNAPSPACE
#  IN-PROCESS, preso da un RunspacePool con tetto di concorrenza.
#  Perche' occupa poca RAM:
#    - NESSUN nuovo processo: i runspace condividono il processo e il CLR di ZAP
#      (un processo powershell.exe separato costa ~30-50 MB ciascuno);
#    - la memoria e' limitata dal tetto del pool (max_pool), non dal numero di compiti.
#  La modalita' 'processo' (isolamento forte) e' disponibile quando serve davvero.
#  Le funzioni [PURA] sono testabili senza rete.
# ---------------------------------------------------------------------------

function Get-MiniAgentiDefault {
    return @{
        max_pool          = 3            # quanti mini-agenti in parallelo (tetto di RAM)
        max_agenti_totali = 12           # oltre, i nuovi compiti girano in coda
        timeout_sec       = 120
        modalita          = 'runspace'   # runspace (leggero, in-process) | processo (isolato)
        min_ram_mb        = 8            # stima informativa per agente
    }
}

function Get-MiniAgentiPool {
    param($sync)
    if ($script:ZapMiniPool) { return $script:ZapMiniPool }
    $max = 3
    try { if ($sync.Config.miniagenti.max_pool) { $max = [int]$sync.Config.miniagenti.max_pool } } catch { }
    if ($max -lt 1) { $max = 1 }
    if ($max -gt 8) { $max = 8 }
    $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    $iss.ApartmentState = 'MTA'
    $script:ZapMiniPool = [runspacefactory]::CreateRunspacePool(1, $max, $iss, $Host)
    $script:ZapMiniPool.Open()
    return $script:ZapMiniPool
}

function Get-MiniAgentiRegistro {
    if (-not $script:ZapMiniAgenti) { $script:ZapMiniAgenti = New-Object System.Collections.ArrayList }
    return $script:ZapMiniAgenti
}

function New-MiniAgente {
    param($sync, [string]$Nome, [string]$Compito, [switch]$Attendi, [int]$TimeoutSec = 0)
    if (-not $Compito) { return '!Compito mancante.' }
    if (-not $Nome) { $Nome = 'mini-' + ([guid]::NewGuid().ToString('N').Substring(0, 6)) }
    if ($TimeoutSec -le 0) { try { $TimeoutSec = [int]$sync.Config.miniagenti.timeout_sec } catch { $TimeoutSec = 120 } }
    $ram = 8; try { if ($sync.Config.miniagenti.min_ram_mb) { $ram = [int]$sync.Config.miniagenti.min_ram_mb } } catch { }
    $prelude = "`$ErrorActionPreference='Stop'; try { " + $Compito + " | Out-String } catch { '!ERRORE: ' + `$_.Exception.Message }"
    try {
        $pool = Get-MiniAgentiPool $sync
        $ps = [powershell]::Create()
        $ps.RunspacePool = $pool
        [void]$ps.AddScript($prelude)
        $handle = $ps.BeginInvoke()
        $rec = [pscustomobject]@{ nome = $Nome; compito = $Compito; ps = $ps; handle = $handle; avvio = (Get-Date); fine = $null; stato = 'in corso'; risultato = $null }
        [void](Get-MiniAgentiRegistro).Add($rec)
        if ($Attendi) { return (Receive-MiniAgente $sync $Nome $TimeoutSec) }
        return ("Mini-agente '" + $Nome + "' avviato (runspace in-process, ~" + $ram + " MB stimati). Usa mini_agenti_raccogli per il risultato.")
    } catch {
        return ('!Impossibile avviare il mini-agente: ' + $_.Exception.Message)
    }
}

function Receive-MiniAgente {
    param($sync, [string]$Nome, [int]$TimeoutSec = 0)
    $reg = Get-MiniAgentiRegistro
    $r = @($reg | Where-Object { $_.nome -eq $Nome })[0]
    if (-not $r) { return ("Mini-agente '" + $Nome + "' non trovato.") }
    if ($r.stato -eq 'terminato') { return [string]$r.risultato }
    if ($TimeoutSec -le 0) { try { $TimeoutSec = [int]$sync.Config.miniagenti.timeout_sec } catch { $TimeoutSec = 120 } }
    $waitMs = [int]([math]::Max(1, $TimeoutSec) * 1000)
    if (-not $r.handle.AsyncWaitHandle.WaitOne($waitMs)) {
        $r.stato = 'timeout'
        try { $r.ps.Stop() } catch { }
        return ('!Mini-agente ' + $Nome + ' TIMEOUT dopo ' + $TimeoutSec + ' s. Fermato.')
    }
    $txt = ''
    try { foreach ($o in @($r.ps.EndInvoke($r.handle))) { $txt += ([string]$o) + "`n" } }
    catch { $txt = '!Errore mini-agente: ' + $_.Exception.Message }
    try { $r.ps.Dispose() } catch { }
    $r.stato = 'terminato'; $r.risultato = $txt.Trim(); $r.fine = Get-Date
    return [string]$r.risultato
}

function Format-MiniAgentiStato {
    param($sync)
    $reg = Get-MiniAgentiRegistro
    $max = 3; try { if ($sync.Config.miniagenti.max_pool) { $max = [int]$sync.Config.miniagenti.max_pool } } catch { }
    $ram = 8; try { if ($sync.Config.miniagenti.min_ram_mb) { $ram = [int]$sync.Config.miniagenti.min_ram_mb } } catch { }
    $tot = @($reg).Count
    $att = @($reg | Where-Object { $_.stato -eq 'in corso' }).Count
    $out = @()
    $out += 'MINI-AGENTI (PowerShell, runspace in-process: nessun nuovo processo)'
    $out += ('  pool: ' + $att + '/' + $max + ' attivi   |   registrati: ' + $tot)
    $out += ('  RAM: ~' + $ram + ' MB per agente, tetto ~' + ($max * $ram) + ' MB (condiviso, in-process).')
    foreach ($r in @($reg)) {
        $sec = 0; try { $sec = [int]((Get-Date) - $r.avvio).TotalSeconds } catch { }
        $cmp = [string]$r.compito; if ($cmp.Length -gt 60) { $cmp = $cmp.Substring(0, 60) + '...' }
        $out += ('  - ' + $r.nome + ' [' + $r.stato + '] ' + $sec + 's : ' + $cmp)
    }
    $out += '  comandi: mini_agente (crea) | mini_agenti_raccogli | mini_agente_ferma nome=<n>'
    return ($out -join "`n")
}

function Tool-MiniAgente {
    param($sync, [string]$Nome, [string]$Compito, [bool]$Attendi = $true, [int]$TimeoutSec = 120)
    if ($Attendi) { return (New-MiniAgente -sync $sync -Nome $Nome -Compito $Compito -Attendi -TimeoutSec $TimeoutSec) }
    return (New-MiniAgente -sync $sync -Nome $Nome -Compito $Compito -TimeoutSec $TimeoutSec)
}

function Tool-MiniAgentiRaccogli {
    param($sync)
    $reg = Get-MiniAgentiRegistro
    $out = New-Object System.Collections.ArrayList
    foreach ($r in @($reg)) {
        if ($r.stato -eq 'in corso') {
            if ($r.handle.IsCompleted) { [void]$out.Add('### ' + $r.nome + "`n" + (Receive-MiniAgente $sync $r.nome 5)) }
            else { [void]$out.Add('### ' + $r.nome + ' (ancora in corso)') }
        } else { [void]$out.Add('### ' + $r.nome + ' [' + $r.stato + "]`n" + [string]$r.risultato) }
    }
    if ($out.Count -eq 0) { return 'Nessun mini-agente registrato.' }
    return ($out -join "`n")
}

function Tool-MiniAgenteFerma {
    param($sync, [string]$Nome)
    $reg = Get-MiniAgentiRegistro
    $r = @($reg | Where-Object { $_.nome -eq $Nome })[0]
    if (-not $r) { return ("Mini-agente '" + $Nome + "' non trovato.") }
    try { $r.ps.Stop() } catch { }
    $r.stato = 'fermato'
    return ("Mini-agente '" + $Nome + "' fermato.")
}
