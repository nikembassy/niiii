﻿# programmi.ps1 -- Sezione PROGRAMMI: la cartella con i tuoi programmi, lanciabili.
# Le funzioni di scansione/comando sono PURE: coperte dai test.

function Get-DefaultProgrammiConfig {
    return @{ cartella = 'programmi'; voci = @() }
}

function Get-ProgrammiConfig {
    param($sync)
    $d = Get-DefaultProgrammiConfig
    $c = $null
    try { $c = $sync.Config.programmi } catch { $c = $null }
    if ($c) {
        try { if ($c.cartella) { $d.cartella = [string]$c.cartella } } catch { }
        try { if ($null -ne $c.voci) { $d.voci = @($c.voci) } } catch { }
    }
    if (-not ([string]$d.cartella).Trim()) { $d.cartella = 'programmi' }
    return $d
}

function Get-ProgrammiDir {
    param($sync)
    $c = Get-ProgrammiConfig $sync
    $rel = [string]$c.cartella
    if ([System.IO.Path]::IsPathRooted($rel)) { return $rel }
    $b = ''
    try { $b = [string]$sync.Base } catch { $b = '' }
    if (-not $b) { $b = (Get-Location).Path }
    return (Join-Path $b $rel)
}

function Get-ProgrammiEstensioni { return @('.ps1', '.bat', '.cmd', '.exe', '.lnk', '.py', '.vbs', '.ahk', '.jar', '.msc') }

function Get-ProgrammiScansionati {
    # Legge la cartella e restituisce le voci trovate.
    param([string]$Dir)
    $out = @()
    if (-not $Dir -or -not (Test-Path $Dir)) { return $out }
    $exts = Get-ProgrammiEstensioni
    foreach ($f in @(Get-ChildItem -Path $Dir -File -ErrorAction SilentlyContinue | Sort-Object Name)) {
        if ($exts -contains $f.Extension.ToLower()) {
            $out += @{
                nome       = [System.IO.Path]::GetFileNameWithoutExtension($f.Name)
                file       = $f.Name
                percorso   = $f.FullName
                estensione = $f.Extension.ToLower()
            }
        }
    }
    return $out
}

function Get-ProgrammaComando {
    # PURA: come si lancia questo file, in base all'estensione.
    param([string]$Percorso)
    $ext = ''
    try { $ext = [System.IO.Path]::GetExtension([string]$Percorso).ToLower() } catch { $ext = '' }
    switch ($ext) {
        '.ps1'  { return @{ file = 'powershell.exe'; argomenti = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $Percorso) } }
        '.bat'  { return @{ file = 'cmd.exe'; argomenti = @('/c', $Percorso) } }
        '.cmd'  { return @{ file = 'cmd.exe'; argomenti = @('/c', $Percorso) } }
        '.py'   { return @{ file = 'python.exe'; argomenti = @($Percorso) } }
        '.vbs'  { return @{ file = 'wscript.exe'; argomenti = @($Percorso) } }
        '.ahk'  { return @{ file = 'AutoHotkey.exe'; argomenti = @($Percorso) } }
        default { return @{ file = $Percorso; argomenti = @() } }
    }
}

function Resolve-ProgrammaDaNome {
    # PURA: trova il programma per nome (esatto, poi inizio, poi contenuto).
    param($sync, [string]$Nome)
    $n = ([string]$Nome).Trim().ToLower()
    if (-not $n) { return $null }
    $tutte = @(Get-ProgrammiScansionati (Get-ProgrammiDir $sync))
    foreach ($v in $tutte) { if ($v.nome.ToLower() -eq $n) { return $v } }
    foreach ($v in $tutte) { if ($v.nome.ToLower().StartsWith($n)) { return $v } }
    foreach ($v in $tutte) { if ($v.nome.ToLower().Contains($n)) { return $v } }
    return $null
}

function Format-ProgrammiElenco {
    param($sync)
    $dir = Get-ProgrammiDir $sync
    $voci = @(Get-ProgrammiScansionati $dir)
    $righe = @()
    $righe += "Cartella programmi: $dir"
    if ($voci.Count -eq 0) {
        $righe += 'Nessun programma trovato. Metti i tuoi file (.ps1 .bat .cmd .exe .lnk .py .vbs .ahk .jar) in quella cartella.'
        $righe += 'Poi dimmi: "lancia <nome del programma>".'
        return ($righe -join "`n")
    }
    $righe += "Trovati $($voci.Count) programmi:"
    foreach ($v in $voci) { $righe += ("- " + $v.nome + "  [" + $v.estensione + "]") }
    $righe += 'Per lanciarne uno: "lancia <nome>" oppure aprilo dal pannello PROGRAMMI.'
    return ($righe -join "`n")
}
