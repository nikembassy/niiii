﻿# ============================================================================
#  memoria_dreaming.ps1  --  ZAP 7.0 : memoria consolidata ("dreaming") + revisione
# ----------------------------------------------------------------------------
#  La memoria non e' piu' un file piatto in append: e' un archivio strutturato
#  (memory\memoria.json) con id, categoria e date. ZAP propone una consolidazione
#  (unioni, doppioni, ricordi vecchi) che l'utente puo' rivedere e correggere.
# ============================================================================

function Get-MemoriaPath {
    param([string]$base)
    $d = Join-Path $base 'memory'
    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
    return (Join-Path $d 'memoria.json')
}
function Get-Memoria {
    param([string]$base)
    $p = Get-MemoriaPath $base
    if (-not (Test-Path -LiteralPath $p)) { return @() }
    try { return @((Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json)) } catch { return @() }
}
function Save-Memoria { param([string]$base, $voci) (ConvertTo-Json -InputObject @($voci) -Depth 6) | Set-Content -LiteralPath (Get-MemoriaPath $base) -Encoding UTF8 }

function Add-Ricordo {
    param([string]$base, [string]$testo, [string]$categoria)
    if (-not $categoria) { $categoria = 'generale' }
    $voci = @(Get-Memoria $base)
    $voci += [pscustomobject]@{
        id = ('m' + (Get-Date).ToString('yyyyMMddHHmmss')); testo = $testo; categoria = $categoria
        creato = (Get-Date).ToString('s'); aggiornato = (Get-Date).ToString('s'); fonte = 'chat'
    }
    Save-Memoria $base $voci
    return "Ricordato: $testo"
}

function Clear-Hu {
    param([string]$s)
    if ($null -eq $s) { return '' }
    return (($s.ToLower()) -replace '[^a-z0-9 ]','' -replace '\s+',' ').Trim()
}

# ------------------------------- TOOLS -------------------------------------

function Tool-VediMemoria {
    param([string]$base)
    $voci = @(Get-Memoria $base)
    if ($voci.Count -eq 0) { return "Non ricordo ancora nulla di te." }
    $righe = foreach ($v in $voci) { "  - [$($v.id)] ($($v.categoria)) $($v.testo)" }
    return "Cosa ricordo ($($voci.Count)):`n" + ($righe -join "`n")
}

function Tool-Dimentica {
    param([string]$base, [string]$chiave)
    if (-not $chiave) { return "Dimmi l'id o una parola chiave da dimenticare (vedi vedi_memoria)." }
    $voci = @(Get-Memoria $base)
    $k = Clear-Hu $chiave
    $rimaste = @($voci | Where-Object { $_.id -ne $chiave -and (Clear-Hu $_.testo) -notlike ("*" + $k + "*") })
    $n = $voci.Count - $rimaste.Count
    Save-Memoria $base $rimaste
    return "Dimenticati $n ricordi che contenevano '$chiave'."
}

function Tool-ConsolidaMemoria {
    # Due modi d'uso:
    #  - senza 'nuove_json': ZAP propone la consolidazione (doppioni + ricordi vecchi)
    #    e scrive memory\memoria_revisione.md, che l'utente puo' rivedere.
    #  - con 'nuove_json' (array di {testo,categoria}): applica la versione curata dal modello.
    param([string]$base, [string]$nuove_json)
    $voci = @(Get-Memoria $base)

    if ($nuove_json) {
        try { $curate = @($nuove_json | ConvertFrom-Json) } catch { return "JSON non valido: atteso un array di {testo, categoria}." }
        $nuove = @()
        foreach ($c in $curate) {
            $nuove += [pscustomobject]@{
                id = ('m' + (Get-Date).ToString('yyyyMMddHHmmss') + [int](Get-Random -Maximum 99))
                testo = [string]$c.testo; categoria = $(if ($c.categoria) { [string]$c.categoria } else { 'generale' })
                creato = (Get-Date).ToString('s'); aggiornato = (Get-Date).ToString('s'); fonte = 'dreaming'
            }
        }
        Save-Memoria $base $nuove
        return "Memoria consolidata: da $($voci.Count) a $($nuove.Count) ricordi."
    }

    # proposta euristica
    $gruppi = @{}
    foreach ($v in $voci) { $kk = Clear-Hu $v.testo; if (-not $gruppi.ContainsKey($kk)) { $gruppi[$kk] = @() }; $gruppi[$kk] += $v }
    $doppioni = @($gruppi.Values | Where-Object { $_.Count -gt 1 })
    $soglia = (Get-Date).AddDays(-180)
    $vecchi = @($voci | Where-Object { try { [datetime]$_.creato -lt $soglia } catch { $false } })

    $md = "# Revisione memoria (dreaming) - " + (Get-Date).ToString('s') + "`n`n"
    $md += "Totale ricordi: $($voci.Count)`n`n"
    if ($doppioni.Count -gt 0) {
        $md += "## Possibili doppioni ($($doppioni.Count))`n"
        foreach ($g in $doppioni) { $md += "- " + (($g | ForEach-Object { "[$($_.id)] $($_.testo)" }) -join "  ==  ") + "`n" }
        $md += "`n"
    }
    if ($vecchi.Count -gt 0) {
        $md += "## Ricordi piu' vecchi di 6 mesi ($($vecchi.Count)) - da rivedere`n"
        foreach ($v in $vecchi) { $md += "- [$($v.id)] ($($v.creato)) $($v.testo)`n" }
    }
    Set-Content -LiteralPath (Join-Path $base 'memory\memoria_revisione.md') -Value $md -Encoding UTF8

    $riassunto = "Proposta di consolidazione pronta (memory\memoria_revisione.md): $($doppioni.Count) gruppi di doppioni, $($vecchi.Count) ricordi da rivedere. "
    $riassunto += "Per applicare una versione curata, richiama consolida_memoria con un array JSON di {testo, categoria}."
    return $riassunto
}
