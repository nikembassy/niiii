# ============================================================================
#  tools_v7.ps1  --  ZAP 7.0 : integrazione degli strumenti nuovi
# ----------------------------------------------------------------------------
#  Carica i moduli nuovi e li espone all'agente. NON modifica tools.ps1.
#
#  Per attivare ZAP 7.0 fai 3 modifiche minime a brain\tools.ps1:
#    1) in cima al file, aggiungi:      . (Join-Path $PSScriptRoot 'tools_v7.ps1')
#    2) nella funzione Get-AgentTools, dopo la parentesi tonda finale del return,
#       aggiungi:                       + (Get-AgentToolsV7)
#    3) nella funzione Invoke-AgentTool, subito dopo la riga
#       "if ($null -eq $ToolArgs) { $ToolArgs = @{} }", aggiungi:
#           $v7 = Invoke-AgentToolV7 -Name $Name -ToolArgs $ToolArgs -sync $sync
#           if ($null -ne $v7) { return $v7 }
# ============================================================================

$script:ZapBase = Split-Path -Parent $PSScriptRoot    # cartella radice del progetto (brain\..)

. (Join-Path $PSScriptRoot 'skills_engine.ps1')
. (Join-Path $PSScriptRoot 'mcp_client.ps1')
. (Join-Path $PSScriptRoot 'autonomia_task.ps1')
. (Join-Path $PSScriptRoot 'memoria_dreaming.ps1')
. (Join-Path $PSScriptRoot 'computer_use.ps1')
. (Join-Path $PSScriptRoot 'automazioni.ps1')
. (Join-Path $PSScriptRoot 'kali.ps1')
. (Join-Path $PSScriptRoot 'osint.ps1')
. (Join-Path $PSScriptRoot 'mini_agenti.ps1')

function S {  # helper: schema di un parametro stringa
    param([string]$desc)
    return @{ type = 'string'; description = $desc }
}

function Get-AgentToolsV7 {
    return @(
        @{ type='function'; function=@{ name='osint_ricerca'; description="OSINT passivo: raccoglie informazioni da fonti pubbliche su dominio, IP, email o username (RDAP/WHOIS, DNS, certificati crt.sh, IP-geo, header, metadati)."; parameters=@{ type='object'; properties=@{ tipo=(S 'dominio | ip | email | username | metadati'); target=(S 'bersaglio della ricerca'); extra=(S 'opzionale: percorso file per i metadati') }; required=@('tipo','target') } } },
        @{ type='function'; function=@{ name='osint_catalogo'; description="Elenca le fonti OSINT disponibili e cosa cercano."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='mini_agente'; description="Crea un MINI-AGENTE PowerShell leggero (runspace in-process, RAM contenuta) che esegue un compito e ne restituisce il risultato. Usalo per parallelizzare lavori brevi."; parameters=@{ type='object'; properties=@{ nome=(S 'nome breve del mini-agente'); compito=(S 'codice PowerShell da eseguire'); attendere=(S 'true per attendere il risultato (default true)'); timeout_sec=(S 'secondi massimi (default 120)') }; required=@('compito') } } },
        @{ type='function'; function=@{ name='mini_agenti_lista'; description="Elenca i mini-agenti e il loro stato, con la stima di RAM del pool."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='mini_agenti_raccogli'; description="Raccoglie i risultati dei mini-agenti terminati."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='mini_agente_ferma'; description="Ferma un mini-agente dato il suo nome."; parameters=@{ type='object'; properties=@{ nome=(S 'nome del mini-agente') }; required=@('nome') } } },
        @{ type='function'; function=@{ name='kali_esegui'; description="Esegue un comando nella console (Kali Linux via WSL se disponibile, altrimenti PowerShell)."; parameters=@{ type='object'; properties=@{ comando=(S 'comando da eseguire') }; required=@('comando') } } },
        @{ type='function'; function=@{ name='kali_stato'; description="Mostra quali strumenti di sicurezza sono installati e se Kali/WSL e' pronto."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='kali_installa_tool'; description="Installa uno strumento dal catalogo (id: nmap, metasploit, sqlmap...) dentro Kali."; parameters=@{ type='object'; properties=@{ id=(S 'id dello strumento') }; required=@('id') } } },
        @{ type='function'; function=@{ name='elenco_automazioni'; description="Elenca le automazioni che ZAP puo attivare (backup, pulizia, organizza Download...)."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='attiva_automazione'; description="Attiva un'automazione dal catalogo dato il suo id (vedi elenco_automazioni)."; parameters=@{ type='object'; properties=@{ id=(S 'id dell automazione') }; required=@('id') } } },
        @{ type='function'; function=@{ name='skills_catalogo'; description="Elenca TUTTE le skill installate (solo nome + descrizione). Usalo per sapere cosa ZAP sa fare."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='attendi'; description="Aspetta che compaia qualcosa sullo schermo PRIMA di procedere, invece di cliccare a tempo (evita di sbagliare i clic quando un programma o un sito e' lento). Usalo dopo aver aperto un programma o un sito, prima di cliccare o scrivere. tipo=finestra (valore = parte del titolo), tipo=elemento (valore = nome visibile oppure id:AutomationId), tipo=colore (valore = x,y,#RRGGBB). Ritorna OK oppure !TIMEOUT: in quel caso NON cliccare a caso. Usalo anche per verificare che una finestra sia pronta prima di agire."; parameters=@{ type='object'; properties=@{ tipo=(S 'finestra | elemento | colore'); valore=(S 'titolo della finestra, oppure nome/id di un elemento, oppure x,y,#RRGGBB'); timeout_sec=(S 'secondi di attesa (default 15)') }; required=@('tipo','valore') } } },
        @{ type='function'; function=@{ name='skill_apri'; description="Carica le ISTRUZIONI COMPLETE di una skill (per nome) quando ti serve usarla."; parameters=@{ type='object'; properties=@{ nome=(S 'nome della skill') }; required=@('nome') } } },
        @{ type='function'; function=@{ name='skill_risorsa'; description="Legge una risorsa (file/script/esempio) allegata a una skill."; parameters=@{ type='object'; properties=@{ nome=(S 'nome della skill'); file=(S 'percorso della risorsa, es. script.ps1') }; required=@('nome','file') } } },
        @{ type='function'; function=@{ name='crea_skill'; description="Crea una NUOVA skill in formato standard (cartella con SKILL.md). Usalo quando impari un compito ripetibile."; parameters=@{ type='object'; properties=@{ nome=(S 'nome breve della skill'); descrizione=(S 'cosa fa e quando usarla'); istruzioni=(S 'istruzioni operative passo-passo') }; required=@('nome','descrizione') } } },
        @{ type='function'; function=@{ name='elimina_skill'; description="Elimina una skill per nome."; parameters=@{ type='object'; properties=@{ nome=(S 'nome della skill') }; required=@('nome') } } },

        @{ type='function'; function=@{ name='mcp_aggiungi'; description="Collega un server MCP esterno (es. filesystem, GitHub, Gmail, Slack). Sblocca servizi senza scrivere integrazioni."; parameters=@{ type='object'; properties=@{ id=(S 'id breve, es. fs'); comando=(S "comando che avvia il server, es. npx -y @modelcontextprotocol/server-filesystem C:\\") }; required=@('id','comando') } } },
        @{ type='function'; function=@{ name='mcp_lista'; description="Elenca i server MCP configurati."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='mcp_strumenti'; description="Elenca gli strumenti esposti da un server MCP."; parameters=@{ type='object'; properties=@{ id=(S 'id del server MCP') }; required=@('id') } } },
        @{ type='function'; function=@{ name='mcp_chiama'; description="Chiama uno strumento di un server MCP."; parameters=@{ type='object'; properties=@{ id=(S 'id del server'); strumento=(S 'nome strumento'); argomenti_json=(S 'argomenti in JSON, es. {"path":"C:\\\\"}') }; required=@('id','strumento') } } },
        @{ type='function'; function=@{ name='mcp_rimuovi'; description="Rimuove un server MCP."; parameters=@{ type='object'; properties=@{ id=(S 'id del server MCP') }; required=@('id') } } },

        @{ type='function'; function=@{ name='pianifica_task'; description="Pianifica un compito autonomo: a un orario, a intervalli, una volta, o quando appare un file in una cartella."; parameters=@{ type='object'; properties=@{ nome=(S 'nome del task'); tipo=(S "orario | intervallo | una_volta | cartella"); quando=(S 'orario=>HH:mm, intervallo=>minuti, una_volta=>MM/DD/YYYY, cartella=>percorso'); azione=(S 'cosa deve fare ZAP'); orario=(S 'HH:mm per i task a tempo') }; required=@('azione') } } },
        @{ type='function'; function=@{ name='lista_task'; description="Elenca i task pianificati."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='annulla_task'; description="Annulla un task pianificato dato il suo id."; parameters=@{ type='object'; properties=@{ id=(S 'id del task') }; required=@('id') } } },

        @{ type='function'; function=@{ name='vedi_memoria'; description="Mostra cosa ZAP ricorda dell'utente (con id)."; parameters=@{ type='object'; properties=@{} } } },
        @{ type='function'; function=@{ name='dimentica'; description="Dimentica i ricordi che contengono una parola chiave (o un id)."; parameters=@{ type='object'; properties=@{ chiave=(S 'id o parola chiave') }; required=@('chiave') } } },
        @{ type='function'; function=@{ name='consolida_memoria'; description="Consolida la memoria (dreaming): propone unioni/doppioni da rivedere, oppure applica una versione curata passata in JSON."; parameters=@{ type='object'; properties=@{ nuove_json=(S 'opzionale: array JSON di {testo, categoria}') } } } },

        @{ type='function'; function=@{ name='azione_schermo'; description="Computer Use: AGISCE sullo schermo (click, digita, scroll, trascina) su qualunque programma. Usalo dopo guarda_schermo per capire dove cliccare."; parameters=@{ type='object'; properties=@{ azione=(S 'click | doppio_click | click_destro | muovi | scroll | trascina | digita | tasto'); x=(S 'coordinata X'); y=(S 'coordinata Y'); x2=(S 'X di arrivo (trascina)'); y2=(S 'Y di arrivo (trascina)'); testo=(S 'testo da digitare'); tasto=(S 'invio | tab | esc | spazio | backspace | su | giu | sinistra | destra | f5'); delta=(S 'rotella scroll, es. -120 giu'); forza=(S 'true per confermare in modalita prudente') }; required=@('azione') } } }
    )
}

function Invoke-AgentToolV7 {
    param([string]$Name, $ToolArgs, $sync)
    if ($null -eq $ToolArgs) { $ToolArgs = @{} }
    $b = $script:ZapBase

    switch ($Name) {
        'attendi' { return (Invoke-Attesa -Tipo ([string]$ToolArgs.tipo) -Valore ([string]$ToolArgs.valore) -TimeoutSec ([int]$(if ($ToolArgs.timeout_sec) { $ToolArgs.timeout_sec } else { 15 }))) }
        'kali_esegui'         { return (Tool-KaliEsegui ([string]$ToolArgs.comando)) }
        'kali_stato'          { return (Tool-KaliStato) }
        'kali_installa_tool'  { return (Tool-KaliInstallaTool ([string]$ToolArgs.id)) }
        'elenco_automazioni'  { return (Tool-ElencoAutomazioni $b) }
        'attiva_automazione'  { return (Tool-AttivaAutomazione $sync ([string]$ToolArgs.id)) }
        'skills_catalogo'   { return (Tool-SkillsCatalogo $b) }
        'skill_apri'        { return (Tool-SkillApri $b ([string]$ToolArgs.nome)) }
        'skill_risorsa'     { return (Tool-SkillRisorsa $b ([string]$ToolArgs.nome) ([string]$ToolArgs.file)) }
        'crea_skill'        { return (Tool-CreaSkill $b ([string]$ToolArgs.nome) ([string]$ToolArgs.descrizione) ([string]$ToolArgs.istruzioni)) }
        'elimina_skill'     { return (Tool-EliminaSkill $b ([string]$ToolArgs.nome)) }

        'mcp_aggiungi'      { return (Tool-McpAggiungi $b ([string]$ToolArgs.id) ([string]$ToolArgs.comando)) }
        'mcp_lista'         { return (Tool-McpLista $b) }
        'mcp_strumenti'     { return (Tool-McpStrumenti $b ([string]$ToolArgs.id)) }
        'mcp_chiama'        { return (Tool-McpChiama $b ([string]$ToolArgs.id) ([string]$ToolArgs.strumento) ([string]$ToolArgs.argomenti_json)) }
        'mcp_rimuovi'       { return (Tool-McpRimuovi $b ([string]$ToolArgs.id)) }

        'pianifica_task'    { return (Tool-PianificaTask $b ([string]$ToolArgs.nome) ([string]$ToolArgs.tipo) ([string]$ToolArgs.quando) ([string]$ToolArgs.azione) ([string]$ToolArgs.orario)) }
        'lista_task'        { return (Tool-ListaTask $b) }
        'annulla_task'      { return (Tool-AnnullaTask $b ([string]$ToolArgs.id)) }

        'vedi_memoria'      { return (Tool-VediMemoria $b) }
        'dimentica'         { return (Tool-Dimentica $b ([string]$ToolArgs.chiave)) }
        'consolida_memoria' { return (Tool-ConsolidaMemoria $b ([string]$ToolArgs.nuove_json)) }

        'azione_schermo' {
            $fz = $false; try { $fz = [bool]$ToolArgs.forza } catch { $fz = $false }
            return (Tool-AzioneSchermo -base $b -sync $sync -azione ([string]$ToolArgs.azione) `
                    -x ([int]$ToolArgs.x) -y ([int]$ToolArgs.y) -x2 ([int]$ToolArgs.x2) -y2 ([int]$ToolArgs.y2) `
                    -testo ([string]$ToolArgs.testo) -tasto ([string]$ToolArgs.tasto) -delta ([int]$ToolArgs.delta) -forza $fz)
        }

        'osint_ricerca'        { return (Tool-OsintRicerca $b $sync ([string]$ToolArgs.tipo) ([string]$ToolArgs.target) ([string]$ToolArgs.extra)) }
        'osint_catalogo'       { return (Tool-OsintCatalogo) }
        'mini_agente'          { $att = $true; try { if ($null -ne $ToolArgs.attendere) { $att = [bool]$ToolArgs.attendere } } catch { }; $to = 120; try { if ($ToolArgs.timeout_sec) { $to = [int]$ToolArgs.timeout_sec } } catch { }; return (Tool-MiniAgente $sync ([string]$ToolArgs.nome) ([string]$ToolArgs.compito) $att $to) }
        'mini_agenti_lista'    { return (Format-MiniAgentiStato $sync) }
        'mini_agenti_raccogli' { return (Tool-MiniAgentiRaccogli $sync) }
        'mini_agente_ferma'    { return (Tool-MiniAgenteFerma $sync ([string]$ToolArgs.nome)) }

        default { return $null }   # non gestito qui: passa agli strumenti v6
    }
}
