﻿# llm.ps1 — Client per il "cervello" (registro multi-servizio in brain\provider_ai.ps1).

# Se provider_ai.ps1 non e' ancora caricato (es. uso standalone), lo carica adesso.
if (-not (Get-Command Get-ProviderRegistry -ErrorAction SilentlyContinue)) {
    $__prov = Join-Path (Split-Path -Parent $PSCommandPath) 'provider_ai.ps1'
    if (Test-Path $__prov) { . $__prov }
}

function Invoke-Chat {
    param(
        $sync,
        [array]$Messages,
        [array]$Tools
    )

    # v6: sceglie il servizio in base al tipo di lavoro (o a quello fissato con /ai).
    $taskType = 'veloce'
    try { $taskType = Get-AiTaskType (Get-UltimoTestoUtente $Messages) } catch { }
    $prov = $null
    try { $prov = Resolve-AiProvider -sync $sync -TaskType $taskType } catch { $prov = $null }
    try { $sync.AiActive = $prov } catch { }

    if ($prov -and ([string]$prov.tipo -eq 'gemini')) {
        try { return (Invoke-ChatGemini $sync $Messages $Tools) }
        catch {
            # Gemini a quota (429) o sovraccarico (503): se c'e' un altro servizio pronto lo uso subito.
            $alt = Get-ProviderAlternativo $sync 'gemini'
            if (-not $alt) { throw }
            $prov = $alt
        }
    }
    if ($prov -and ([string]$prov.tipo -eq 'anthropic')) {
        try { return (Invoke-ChatAnthropic $sync $Messages $Tools $taskType) }
        catch {
            # Claude unavailable (401 bad key, 429 quota, 503 overload):
            # do not block the chat, move to the next ready provider (e.g. Gemini).
            $alt = Get-ProviderAlternativo $sync 'anthropic'
            if (-not $alt) { throw }
            $prov = $alt
            if ([string]$prov.tipo -eq 'gemini') { return (Invoke-ChatGemini $sync $Messages $Tools) }
        }
    }

    $cfg = $sync.Config
    $usaLegacy = $false
    if ($prov) {
        $uri   = [string]$prov.endpoint
        $model = [string]$prov.modello
        $key   = [string]$prov.chiave
        $nome  = [string]$prov.nome
    } else {
        if ([string]$cfg.provider -eq 'gemini') { return (Invoke-ChatGemini $sync $Messages $Tools) }
        if (-not (([string]$cfg.api_base).Trim())) {
            throw 'Nessun servizio IA pronto: apri INTELLIGENZE AI e inserisci una chiave + un modello, oppure imposta api_base per un servizio compatibile con OpenAI.'
        }
        $uri   = ($cfg.api_base.TrimEnd('/')) + '/chat/completions'
        $model = [string]$cfg.modello
        $key   = [string]$cfg.api_key
        $nome  = 'Ollama/OpenAI-compatibile'
        $usaLegacy = $true
    }

    $body = @{
        model       = $model
        messages    = $Messages
        temperature = 0.4
        max_tokens  = 2048
    }
    if ($Tools -and $Tools.Count -gt 0) {
        $body.tools       = $Tools
        $body.tool_choice = 'auto'
    }

    $json = ConvertTo-JsonText $body

    $headers = @{}
    if ($key) { $headers.Authorization = "Bearer $key" }

    $timeoutSec = 90
    try {
        $resp = Invoke-RestMethod `
            -Uri $uri `
            -Method Post `
            -Headers $headers `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) `
            -ContentType 'application/json; charset=utf-8' `
            -TimeoutSec $timeoutSec
    }
    catch {
        $msg = $_.Exception.Message
        if ($_.Exception.Response) {
            try {
                $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $detail = $sr.ReadToEnd()
                $sr.Close()
                if ($detail) { $msg = $msg + ' — ' + $detail }
            } catch { }
        }
        $extra = ''
        if ($usaLegacy) { $extra = ' Controlla che Ollama sia avviato (ollama serve) e che il modello sia installato (ollama pull ' + $model + ').' }
        throw ("Errore API ($nome, modello '$model'): $msg." + $extra)
    }

    if (-not $resp.choices -or $resp.choices.Count -eq 0) {
        throw "Risposta API vuota. Modello: $model."
    }

    return $resp.choices[0].message
}

function Invoke-ChatAnthropic {
    # Anthropic (Claude) usa un formato diverso: POST /v1/messages, system separato,
    # header x-api-key + anthropic-version. Qui NON si passano gli strumenti ("le mani"
    # di ZAP): Claude risponde a parole. Per i lavori che richiedono azioni, meglio
    # Gemini o un servizio compatibile OpenAI.
    param($sync, [array]$Messages, [array]$Tools, [string]$TaskType = 'veloce')

    $prov = $null
    try { $prov = $sync.AiActive } catch { }
    if (-not $prov -or ([string]$prov.tipo -ne 'anthropic')) { $prov = Get-ProviderConfig $sync 'anthropic' }
    $key = [string]$prov.chiave
    if (-not $key) { throw 'Manca la chiave di Anthropic (Claude). Inseriscila nel pannello INTELLIGENZE AI.' }

    $system = ''
    $msgs = New-Object System.Collections.ArrayList
    foreach ($m in $Messages) {
        $role = [string]$m.role
        if ($role -eq 'system') { $system = ConvertTo-PlainString $m.content; continue }
        if ($role -eq 'tool') { continue }
        $txt = ConvertTo-PlainString $m.content
        if (-not $txt) { continue }
        if ($role -eq 'assistant' -or $role -eq 'model') { [void]$msgs.Add(@{ role = 'assistant'; content = $txt }) }
        else { [void]$msgs.Add(@{ role = 'user'; content = $txt }) }
    }
    if ($msgs.Count -eq 0) { [void]$msgs.Add(@{ role = 'user'; content = '(vuoto)' }) }

    $modello = [string]$prov.modello
    try { $m = Get-AnthropicModello $sync $TaskType $Messages; if ($m) { $modello = $m } } catch { }
    $body = @{ model = $modello; max_tokens = 2048; messages = @($msgs.ToArray()) }
    if ($system.Trim()) { $body.system = $system }

    $headers = @{ 'x-api-key' = $key; 'anthropic-version' = '2023-06-01' }
    $json = ConvertTo-JsonText $body
    try {
        $resp = Invoke-RestMethod -Uri ([string]$prov.endpoint) -Method Post -Headers $headers `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) `
            -ContentType 'application/json; charset=utf-8' -TimeoutSec 90
    }
    catch {
        $msg = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $msg = $msg + ' | ' + $_.ErrorDetails.Message }
        throw ("Errore Anthropic (modello '" + $modello + "'): $msg")
    }

    $testi = @()
    foreach ($blk in @($resp.content)) { if ($blk.type -eq 'text' -and $blk.text) { $testi += [string]$blk.text } }
    return @{ role = 'assistant'; content = ($testi -join "`n"); tool_calls = @() }
}

function ConvertTo-PlainString {
    # Alcuni modelli restituiscono content come array di parti: normalizza a stringa
    param($Content)
    if ($null -eq $Content) { return '' }
    if ($Content -is [string]) { return $Content }
    try {
        $parts = @()
        foreach ($p in $Content) {
            if ($p.text) { $parts += [string]$p.text }
            elseif ($p -is [string]) { $parts += $p }
        }
        return ($parts -join "`n")
    } catch {
        return [string]$Content
    }
}


# ---------------------------------------------------------------------------
# Cervello cloud: Google Gemini (nessun modello locale -> RAM libera)
# ---------------------------------------------------------------------------

function Get-GeminiModelliRapidi {
    # v6.6: per la chat NORMALE si usano al massimo DUE modelli (quello scelto + un ripiego).
    # Non si gira piu' su tutta la catena ad ogni messaggio (era la causa della lentezza/errore).
    param($sync)
    $out = @()
    $ok = ''
    try { if ($sync.ModelloOk) { $ok = [string]$sync.ModelloOk } } catch { }
    if (-not $ok) { try { if ($sync.Config.gemini_model_scelto) { $ok = [string]$sync.Config.gemini_model_scelto } } catch { } }
    if (-not $ok) { try { $ok = [string]$sync.Config.modello } catch { } }
    if ($ok) { $out += $ok }
    foreach ($d in @('gemini-3.1-flash-lite', 'gemini-3.6-flash')) {
        if ($out -notcontains $d) { $out += $d }
    }
    return @($out | Select-Object -First 2)
}

function Get-GeminiModelChain {
    param($sync)
    $chain = @()
    # v6.5 VELOCITA': il modello che ha funzionato l'ultima volta si prova per PRIMO,
    # cosi' non si perde tempo ogni volta a ritentare i modelli a quota esaurita.
    $ok = ''
    try { if ($sync.ModelloOk) { $ok = [string]$sync.ModelloOk } } catch { }
    if ($ok -and ($chain -notcontains $ok)) { $chain += $ok }
    $m = ''
    try { if ($sync.AiActive -and ([string]$sync.AiActive.tipo -eq 'gemini')) { $m = [string]$sync.AiActive.modello } } catch { }
    if (-not $m) { $m = [string]$sync.Config.modello }
    if ($m -and $m -like 'gemini*' -and ($chain -notcontains $m)) { $chain += $m }
    if ($sync.Config.gemini_model_fallbacks) {
        foreach ($f in @($sync.Config.gemini_model_fallbacks)) {
            if ([string]$f -and ($chain -notcontains [string]$f)) { $chain += [string]$f }
        }
    }
    # Rete di sicurezza: molti modelli, cosi' se uno e' occupato (503) o a quota (429)
    # si passa subito al successivo. Solo modelli che esistono davvero su questa API.
    foreach ($d in @('gemini-3.1-flash-lite', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.7-flash',
                     'gemini-3.8-flash', 'gemini-flash-lite-latest', 'gemini-flash-latest',
                     'gemini-3-flash-preview', 'gemini-pro-latest')) {
        if ($chain -notcontains $d) { $chain += $d }
    }
    return $chain
}

function Get-PropPairs {
    param($Obj)
    if ($null -eq $Obj) { return @() }
    if ($Obj -is [System.Collections.IDictionary]) {
        return @($Obj.GetEnumerator() | ForEach-Object { @{ Name = [string]$_.Key; Value = $_.Value } })
    }
    return @($Obj.PSObject.Properties | ForEach-Object { @{ Name = $_.Name; Value = $_.Value } })
}

function ConvertTo-GeminiSchema {
    param($Schema)
    if ($null -eq $Schema) { return $null }
    $out = @{}
    $t = [string]$Schema.type
    if ($t) { $out.type = $t.ToUpper() }
    if ($Schema.description) { $out.description = [string]$Schema.description }
    if ($Schema.enum) { $out.enum = @($Schema.enum) }
    if ($Schema.required) { $out.required = @($Schema.required) }
    if ($Schema.items) { $out.items = (ConvertTo-GeminiSchema $Schema.items) }
    if ($Schema.properties) {
        $props = @{}
        foreach ($p in (Get-PropPairs $Schema.properties)) { $props[$p.Name] = (ConvertTo-GeminiSchema $p.Value) }
        $out.properties = $props
    }
    return $out
}

function ConvertTo-GeminiTools {
    param([array]$Tools)
    if (-not $Tools -or $Tools.Count -eq 0) { return $null }
    $decls = New-Object System.Collections.ArrayList
    foreach ($t in $Tools) {
        $f = $t.function
        if (-not $f) { $f = $t }
        if (-not $f.name) { continue }
        $decl = @{ name = [string]$f.name; description = [string]$f.description }
        if ($f.parameters) { $decl.parameters = (ConvertTo-GeminiSchema $f.parameters) }
        [void]$decls.Add($decl)
    }
    if ($decls.Count -eq 0) { return $null }
    return @( @{ functionDeclarations = @($decls.ToArray()) } )
}

function ConvertTo-GeminiContents {
    param([array]$Messages)
    $contents = New-Object System.Collections.ArrayList
    $pending  = New-Object System.Collections.ArrayList

    foreach ($m in $Messages) {
        $role = [string]$m.role
        if ($role -eq 'system') { continue }

        if ($role -eq 'tool') {
            $nm = [string]$m.name
            if (-not $nm) { $nm = 'tool' }
            [void]$pending.Add(@{ functionResponse = @{ name = $nm; response = @{ result = (ConvertTo-PlainString $m.content) } } })
            continue
        }

        if ($pending.Count -gt 0) {
            [void]$contents.Add(@{ role = 'user'; parts = @($pending.ToArray()) })
            $pending.Clear()
        }

        if ($role -eq 'user') {
            $txt = ConvertTo-PlainString $m.content
            if (-not $txt.Trim()) { $txt = '(vuoto)' }
            [void]$contents.Add(@{ role = 'user'; parts = @( @{ text = $txt } ) })
        }
        elseif ($role -eq 'assistant' -or $role -eq 'model') {
            $parts = New-Object System.Collections.ArrayList
            $txt = ConvertTo-PlainString $m.content
            if ($txt -and $txt.Trim()) { [void]$parts.Add(@{ text = $txt }) }
            if ($m.tool_calls) {
                foreach ($tc in @($m.tool_calls)) {
                    $fn = $tc.function
                    $argsObj = @{}
                    try {
                        if ($fn.arguments -is [string]) { $argsObj = ($fn.arguments | ConvertFrom-Json) }
                        elseif ($fn.arguments) { $argsObj = $fn.arguments }
                    } catch { $argsObj = @{} }
                    $callPart = @{ functionCall = @{ name = [string]$fn.name; args = $argsObj } }
                    if ($tc.thought_signature) { $callPart['thoughtSignature'] = [string]$tc.thought_signature }
                    [void]$parts.Add($callPart)
                }
            }
            if ($parts.Count -eq 0) { [void]$parts.Add(@{ text = '(nessun testo)' }) }
            [void]$contents.Add(@{ role = 'model'; parts = @($parts.ToArray()) })
        }
    }

    if ($pending.Count -gt 0) {
        [void]$contents.Add(@{ role = 'user'; parts = @($pending.ToArray()) })
        $pending.Clear()
    }
    return @($contents.ToArray())
}

function ConvertFrom-GeminiReply {
    param($Resp)
    if (-not $Resp.candidates -or $Resp.candidates.Count -eq 0) {
        $why = ''
        if ($Resp.promptFeedback -and $Resp.promptFeedback.blockReason) { $why = ' bloccato: ' + $Resp.promptFeedback.blockReason }
        throw ("Nessuna risposta da Gemini.$why")
    }
    $texts = @()
    $calls = @()
    $i = 0
    foreach ($part in @($Resp.candidates[0].content.parts)) {
        if ($part.text) { $texts += [string]$part.text }
        elseif ($part.functionCall) {
            $i++
            $argsJson = '{}'
            if ($part.functionCall.args) { $argsJson = (ConvertTo-JsonText $part.functionCall.args) }
            $cid = [string]$part.functionCall.id
            if (-not $cid) { $cid = "gemini_$i" }
            $calls += @{
                id                = $cid
                type              = 'function'
                thought_signature = [string]$part.thoughtSignature
                function          = @{ name = [string]$part.functionCall.name; arguments = $argsJson }
            }
        }
    }
    return @{ role = 'assistant'; content = ($texts -join "`n"); tool_calls = $calls }
}

function ConvertFrom-GeminiSseChunk {
    # Interpreta UNA riga SSE di Gemini. Restituisce il testo del pezzo e le
    # eventuali parti speciali (functionCall / immagine). Funzione pura: testabile.
    param([string]$Line)
    $out = @{ Testo = ''; Parti = @() }
    if (-not $Line) { return $out }
    if (-not $Line.StartsWith('data:')) { return $out }
    $payload = $Line.Substring(5).Trim()
    if (-not $payload -or $payload -eq '[DONE]') { return $out }
    $chunk = $null
    try { $chunk = $payload | ConvertFrom-Json } catch { return $out }
    $parts = @()
    try { $parts = @($chunk.candidates[0].content.parts) } catch { }
    $testo = ''
    $spec = @()
    foreach ($p in $parts) {
        if ($p.text) { $testo += [string]$p.text }
        elseif ($p.functionCall) { $spec += $p }
        elseif ($p.inlineData) { $spec += $p }
    }
    return @{ Testo = $testo; Parti = $spec }
}

function Invoke-GeminiStream {
    # Legge la risposta SSE di :streamGenerateContent?alt=sse e la restituisce
    # mentre arriva (il testo compare subito in chat invece di aspettare la fine).
    param($sync, [hashtable]$Body, [string]$Model, [string]$Key, [string]$Endpoint, [bool]$Mostra = $false)
    if ($Endpoint -notlike '*:generateContent*') { throw 'Endpoint senza :generateContent: uso la chiamata classica.' }
    $uri = ($Endpoint.Replace(':generateContent', ':streamGenerateContent') + '?alt=sse').Replace('{model}', $Model)
    $req = [System.Net.HttpWebRequest]::Create($uri)
    $req.Method = 'POST'
    $req.ContentType = 'application/json; charset=utf-8'
    $req.Headers.Add('x-goog-api-key', $Key)
    $req.Timeout = 60000
    $req.ReadWriteTimeout = 60000
    $bytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-JsonText $Body))
    $req.ContentLength = $bytes.Length
    $s = $req.GetRequestStream()
    $s.Write($bytes, 0, $bytes.Length)
    $s.Close()
    $risp = $req.GetResponse()
    $reader = New-Object System.IO.StreamReader($risp.GetResponseStream())
    $testo = ''
    $parti = New-Object System.Collections.ArrayList
    $ultimoInvio = Get-Date
    try {
        while ($true) {
            $line = $reader.ReadLine()
            if ($null -eq $line) { break }
            $pezzo = ConvertFrom-GeminiSseChunk $line
            if ($pezzo.Testo) { $testo += [string]$pezzo.Testo }
            foreach ($p in @($pezzo.Parti)) { [void]$parti.Add($p) }
            if ($Mostra -and $testo -and (((Get-Date) - $ultimoInvio).TotalMilliseconds -gt 120)) {
                try { $sync.UiQueue.Enqueue(@{ Type = 'chatpartial'; Data = $testo }) } catch { }
                $ultimoInvio = Get-Date
            }
        }
    } finally {
        try { $reader.Close() } catch { }
        try { $risp.Close() } catch { }
    }
    $outParts = @()
    if ($testo) { $outParts += @{ text = $testo } }
    foreach ($p in $parti) { $outParts += $p }
    if ($outParts.Count -eq 0) { $outParts += @{ text = '' } }
    if ($Mostra) { try { $sync.UiQueue.Enqueue(@{ Type = 'chatpartial'; Data = $testo }) } catch { } }
    return @{ resp = @{ candidates = @( @{ content = @{ parts = $outParts }; finishReason = 'STOP' } ) }; model = $Model }
}

function Invoke-GeminiModelCall {
    # Prova in streaming; se lo streaming non riesce, ricade sulla chiamata classica.
    # Cosi' la velocita' percepita migliora ma la robustezza non peggiora.
    param($sync, [hashtable]$Body, [string]$Model, [string]$Key, [string]$Endpoint, $Headers, [string]$Json, [bool]$Mostra = $false)
    try {
        return (Invoke-GeminiStream $sync $Body $Model $Key $Endpoint $Mostra)
    } catch {
        # Se lo streaming e' fallito con un errore HTTP (quota/overload/chiave), anche la
        # chiamata classica fallirebbe: passo al modello successivo invece di ripetere.
        if ([string]$_.Exception.Message -match '\(\d{3}\)') { throw }
    }
    $uri = $Endpoint.Replace('{model}', $Model)
    $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $Headers `
        -ContentType 'application/json; charset=utf-8' `
        -Body ([System.Text.Encoding]::UTF8.GetBytes($Json)) -TimeoutSec 90
    return @{ resp = $resp; model = $Model }
}

function Invoke-GeminiRaw {
    param($sync, [hashtable]$Body, [string]$Model = '', [bool]$Mostra = $false)
    $key = ''
    $endpoint = ''
    try {
        if ($sync.AiActive -and ([string]$sync.AiActive.tipo -eq 'gemini')) {
            $key = [string]$sync.AiActive.chiave
            $endpoint = [string]$sync.AiActive.endpoint
        }
    } catch { }
    if (-not $key) { try { $key = [string](Get-ProviderConfig $sync 'gemini').chiave } catch { } }
    if (-not $key) { $key = [string]$sync.Config.api_key }
    if (-not $key) { $key = $env:GEMINI_API_KEY }
    if (-not $key) { throw 'Manca la chiave Gemini: inseriscila nel pannello INTELLIGENZE AI oppure imposta la variabile GEMINI_API_KEY.' }
    if (-not $endpoint) { $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent' }
    $headers = @{ 'x-goog-api-key' = $key; 'Content-Type' = 'application/json' }
    $json = ConvertTo-JsonText $Body

    if ($Model) { $models = @($Model) } else { $models = Get-GeminiModelliRapidi $sync }

    $lastErr = ''
    $ultimoCodice = 0
    # v6.6: prima il modello scelto, poi UN solo ripiego. Niente piu' caccia a tutti i modelli.
    foreach ($model in $models) {
        try {
            try { $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = ('SCRIVO CON ' + $model + '...') }) } catch { }
            $resp = Invoke-GeminiModelCall $sync $Body $model $key $endpoint $headers $json $Mostra
            Set-ModelloOk $sync $model
            return $resp
        } catch {
            $lastErr = [string]$_.Exception.Message
            if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $lastErr = $lastErr + ' | ' + $_.ErrorDetails.Message }
            $code = 0
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            if ($code -gt 0) { $ultimoCodice = $code }
        }
    }

    # Nessuno dei due ha risposto: cerco UN modello disponibile (una volta sola) e lo ricordo.
    $trovato = Find-ModelloGemini $sync $Body $headers $endpoint
    if ($trovato) { return $trovato }

    $spiega = 'Google non ha risposto in tempo.'
    if ($ultimoCodice -eq 400 -or $ultimoCodice -eq 401 -or $ultimoCodice -eq 403) {
        $spiega = 'Chiave Gemini non valida o senza permessi (codice ' + $ultimoCodice + '). Controlla provider_ai.gemini.chiave in config.local.json.'
    }
    elseif ($ultimoCodice -eq 404) {
        $spiega = 'Modello non disponibile (404). Controlla i nomi dei modelli in config.json (gemini_model_fallbacks).'
    }
    elseif ($ultimoCodice -eq 429) { $spiega = 'La quota di Google per questo momento e esaurita (429). Aspetta circa un minuto e riprova.' }
    elseif ($ultimoCodice -eq 503) { $spiega = 'I server di Google sono momentaneamente sovraccarichi (503). Aspetta qualche secondo e riprova.' }
    throw ("Nessun modello Gemini ha risposto (provati i preferiti e poi l'intera lista). " + $spiega + " Dettaglio: " + $lastErr)
}

function Find-ModelloGemini {
    # Prova i modelli della catena completa finche' uno risponde, poi lo memorizza.
    # Serve SOLO quando i modelli preferiti non rispondono (quindi raramente).
    param($sync, [hashtable]$Body, $Headers, [string]$Endpoint)
    try { $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = 'CERCO UN MODELLO DISPONIBILE...' }) } catch { }
    $payload = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-JsonText $Body))
    foreach ($model in (Get-GeminiModelChain $sync)) {
        try {
            $uri = $Endpoint.Replace('{model}', $model)
            $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $Headers `
                -ContentType 'application/json; charset=utf-8' -Body $payload -TimeoutSec 120
            Set-ModelloOk $sync $model
            return @{ resp = $resp; model = $model }
        } catch { }
    }
    return $null
}

function Invoke-ChatGemini {
    param($sync, [array]$Messages, [array]$Tools)
    $system = ''
    foreach ($m in $Messages) { if ($m.role -eq 'system') { $system = (ConvertTo-PlainString $m.content); break } }

    $body = @{
        contents         = (ConvertTo-GeminiContents $Messages)
        generationConfig = @{ temperature = 0.4; maxOutputTokens = 4096 }
    }
    if ($system.Trim()) { $body.systemInstruction = @{ parts = @( @{ text = $system } ) } }
    $gt = ConvertTo-GeminiTools $Tools
    if ($gt) { $body.tools = $gt }

    $r = Invoke-GeminiRaw $sync $body -Mostra $true
    return (ConvertFrom-GeminiReply $r.resp)
}

function Invoke-GeminiVision {
    param($sync, [string]$Question, [string]$Base64, [string]$Mime = 'image/png')
    $body = @{
        contents = @( @{ role = 'user'; parts = @(
            @{ text = $Question }
            @{ inlineData = @{ mimeType = $Mime; data = $Base64 } } ) } )
        generationConfig = @{ temperature = 0.2; maxOutputTokens = 1024 }
    }
    $r = Invoke-GeminiRaw $sync $body
    $texts = @()
    foreach ($part in @($r.resp.candidates[0].content.parts)) { if ($part.text) { $texts += [string]$part.text } }
    return (($texts -join "`n").Trim())
}


# ---------------------------------------------------------------------------
# Serializzatore JSON "sicuro": Windows PowerShell 5.1, con ConvertTo-Json,
# trasforma le liste di UN SOLO elemento in un valore singolo
# (parts:[{...}] diventa parts:{...}) e Gemini risponde 400. Questo invece
# emette SEMPRE gli array, su 5.1 e su 7.
# ---------------------------------------------------------------------------

function ConvertTo-JsonString {
    param([string]$s)
    if ($null -eq $s) { return '""' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    foreach ($ch in $s.ToCharArray()) {
        $code = [int]$ch
        if     ($code -eq 34) { [void]$sb.Append('\"') }
        elseif ($code -eq 92) { [void]$sb.Append('\\') }
        elseif ($code -eq 8)  { [void]$sb.Append('\b') }
        elseif ($code -eq 12) { [void]$sb.Append('\f') }
        elseif ($code -eq 10) { [void]$sb.Append('\n') }
        elseif ($code -eq 13) { [void]$sb.Append('\r') }
        elseif ($code -eq 9)  { [void]$sb.Append('\t') }
        elseif ($code -lt 32) { [void]$sb.Append('\u' + $code.ToString('x4')) }
        else                  { [void]$sb.Append($ch) }
    }
    [void]$sb.Append('"')
    return $sb.ToString()
}

function ConvertTo-JsonText {
    param($Value)

    if ($null -eq $Value) { return 'null' }
    if ($Value -is [bool]) { if ($Value) { return 'true' } else { return 'false' } }
    if ($Value -is [string]) { return (ConvertTo-JsonString $Value) }
    if ($Value -is [int] -or $Value -is [long] -or $Value -is [double] -or
        $Value -is [decimal] -or $Value -is [float] -or $Value -is [int16] -or $Value -is [int32]) {
        return [string]([Convert]::ToDouble($Value)).ToString([System.Globalization.NumberFormatInfo]::InvariantInfo)
    }

    if ($Value -is [System.Collections.IDictionary]) {
        $items = @()
        foreach ($key in $Value.Keys) {
            $items += (ConvertTo-JsonString ([string]$key)) + ':' + (ConvertTo-JsonText $Value[$key])
        }
        return '{' + ($items -join ',') + '}'
    }

    if ($Value -is [System.Collections.IEnumerable]) {
        $items = @()
        foreach ($element in $Value) { $items += (ConvertTo-JsonText $element) }
        return '[' + ($items -join ',') + ']'
    }

    $props = @($Value.PSObject.Properties)
    if ($props.Count -gt 0) {
        $items = @()
        foreach ($p in $props) { $items += (ConvertTo-JsonString $p.Name) + ':' + (ConvertTo-JsonText $p.Value) }
        return '{' + ($items -join ',') + '}'
    }
    return (ConvertTo-JsonString ([string]$Value))
}

function Get-AnthropicModello {
    # Picks the Claude model from the task type AND the "weight" of the prompt:
    #   task testo/codice  -> Sonnet (balanced default)
    #   short, light prompt -> Haiku  (cheapest / fastest)
    #   long or complex     -> Opus   (strongest reasoning)
    #   explicit TaskType   -> the matching entry of the map
    # Names can be overridden in config.json: provider_ai.anthropic.modelli.
    param($sync, [string]$TaskType, [array]$Messages)

    $def = @{
        veloce  = 'claude-haiku-4-5'
        testo   = 'claude-sonnet-5-5'
        codice  = 'claude-sonnet-5-5'
        ricerca = 'claude-sonnet-5-5'
        pesante = 'claude-opus-5-5'
    }

    $testo = ''
    try { $testo = [string](Get-UltimoTestoUtente $Messages) } catch { }

    # Escalate to Opus for genuinely heavy work (long prompt or complex keywords).
    $pesante = $false
    if ($testo.Length -gt 1800) { $pesante = $true }
    if ($testo -match 'approfondi|a fondo|architett|progett|refactor|riscrivi tutto|analizza tutto|ragiona|passo passo|da zero|ottimizz') { $pesante = $true }

    $chiave = [string]$TaskType
    if ($pesante) { $chiave = 'pesante' }
    $scelto = [string]$def[$chiave]
    if (-not $scelto) { $scelto = [string]$def['testo'] }

    # Short, light request that still lands on Claude -> cheapest tier (Haiku).
    if (-not $pesante -and $testo.Length -lt 240) { $scelto = [string]$def['veloce'] }

    # Optional user override written in config.json.
    try {
        $stored = Get-CfgValue $sync.Config.provider_ai 'anthropic'
        $mappa  = Get-CfgValue $stored 'modelli'
        if ($mappa) {
            $mx = [string](Get-CfgValue $mappa $chiave)
            if (-not $mx) { $mx = [string](Get-CfgValue $mappa 'testo') }
            if ($mx) { $scelto = $mx }
        }
    } catch { }

    return $scelto
}
