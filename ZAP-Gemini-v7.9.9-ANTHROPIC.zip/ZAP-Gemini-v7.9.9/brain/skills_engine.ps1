﻿# ============================================================================
#  skills_engine.ps1  --  ZAP 7.0 : motore "Agent Skills" (standard aperto)
# ----------------------------------------------------------------------------
#  Ogni skill e' una CARTELLA con dentro un file SKILL.md (+ opzionale references/).
#  Divulgazione progressiva (come lo standard Agent Skills di Anthropic):
#     Livello 1 -> solo name + description        (catalogo, costo ~0 token)
#     Livello 2 -> istruzioni complete             (skill_apri)
#     Livello 3 -> risorse/script su richiesta     (skill_risorsa)
#  Nessun modulo esterno: puro PowerShell.
#  Sostituisce il vecchio registro piatto skills\registry.json.
# ============================================================================

function Remove-Quotes {
    param([string]$s)
    if ($null -eq $s) { return '' }
    return ($s.Trim() -replace '^["'']+','' -replace '["'']+$','')
}

function Get-SkillsRoot {
    param([string]$base)
    $roots = @()
    if ($base) { $roots += (Join-Path $base 'skills') }
    if ($env:USERPROFILE) { $roots += (Join-Path $env:USERPROFILE '.claude\skills') }  # compatibilita' standard
    return @($roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
}

function Read-SkillFrontmatter {
    # Ritorna @{ name; description; corpo } leggendo l'header YAML del SKILL.md.
    param([string]$Path)
    $txt = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $meta = @{ name = ''; description = ''; corpo = $txt }
    if ($txt -match '(?s)^\s*---\s*\r?\n(.*?)\r?\n---\s*\r?\n?(.*)$') {
        $yaml = $Matches[1]
        $meta.corpo = $Matches[2]
        if ($yaml -match '(?m)^\s*name\s*:\s*(.+?)\s*$')        { $meta.name        = Remove-Quotes $Matches[1] }
        if ($yaml -match '(?m)^\s*description\s*:\s*(.+?)\s*$') { $meta.description = Remove-Quotes $Matches[1] }
    }
    return $meta
}

function Get-SkillCatalogo {
    # Livello 1: metadati di TUTTE le skill. Economico da iniettare nel prompt.
    param([string]$base)
    $out = New-Object System.Collections.ArrayList
    foreach ($root in (Get-SkillsRoot $base)) {
        foreach ($d in (Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
            $skillMd = Join-Path $d.FullName 'SKILL.md'
            if (Test-Path -LiteralPath $skillMd) {
                $m = Read-SkillFrontmatter $skillMd
                [void]$out.Add([pscustomobject]@{
                    name        = $(if ($m.name) { $m.name } else { $d.Name })
                    description = $m.description
                    dir         = $d.FullName
                    path        = $skillMd
                })
            }
        }
    }
    return $out
}

function Resolve-Skill {
    param([string]$base, [string]$nome)
    $cat = @(Get-SkillCatalogo $base)
    $hit = $cat | Where-Object { $_.name -eq $nome }
    if (-not $hit) { $hit = $cat | Where-Object { $_.name -like "*$nome*" } }
    return @($hit)[0]
}

function Get-SkillRisorse {
    param($skill)
    return @(Get-ChildItem -LiteralPath $skill.dir -Recurse -File -ErrorAction SilentlyContinue |
             Where-Object { $_.Name -ne 'SKILL.md' } |
             ForEach-Object { $_.FullName.Substring($skill.dir.Length).TrimStart('\','/') })
}

# ------------------------------- TOOLS -------------------------------------

function Tool-SkillsCatalogo {
    param([string]$base)
    $cat = @(Get-SkillCatalogo $base)
    if ($cat.Count -eq 0) { return "Nessuna skill installata. Usa crea_skill per crearne una." }
    $righe = foreach ($s in $cat) { "  - $($s.name): $($s.description)" }
    return "Skill disponibili ($($cat.Count)):`n" + ($righe -join "`n")
}

function Tool-SkillApri {
    param([string]$base, [string]$nome)
    $s = Resolve-Skill $base $nome
    if (-not $s) { return "Skill '$nome' non trovata. Guarda skills_catalogo." }
    $m = Read-SkillFrontmatter $s.path
    $extra = @(Get-SkillRisorse $s)
    $txt = "SKILL: $($s.name)`n" + ("-" * 40) + "`n" + $m.corpo
    if ($extra.Count -gt 0) {
        $txt += "`n`nRisorse disponibili (usa skill_risorsa '$($s.name)' <file>):`n" + (($extra | ForEach-Object { "  - $_" }) -join "`n")
    }
    return $txt
}

function Tool-SkillRisorsa {
    param([string]$base, [string]$nome, [string]$file)
    $s = Resolve-Skill $base $nome
    if (-not $s) { return "Skill '$nome' non trovata." }
    $target = Join-Path $s.dir $file
    if (-not (Test-Path -LiteralPath $target)) { return "Risorsa '$file' non trovata nella skill '$nome'." }
    if ((Get-Item -LiteralPath $target).Length -gt 200000) { return "Risorsa troppo grande per il contesto; percorso: $target" }
    return (Get-Content -LiteralPath $target -Raw -Encoding UTF8)
}

function Tool-CreaSkill {
    # Skill-creator: genera una skill in formato standard a partire da nome+descrizione+istruzioni.
    param([string]$base, [string]$nome, [string]$descrizione, [string]$istruzioni)
    if (-not $nome) { return "Serve un nome per la skill." }
    $slug = ($nome.ToLower() -replace '[^a-z0-9]+','-').Trim('-')
    if (-not $slug) { $slug = 'skill-senza-nome' }
    $dir = Join-Path (Join-Path $base 'skills') $slug
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    if (-not $descrizione) { $descrizione = "Skill '$slug' creata da ZAP. Descrivi qui cosa fa e quando usarla." }
    if (-not $istruzioni) { $istruzioni = "## Cosa fa`n(scrivere qui le istruzioni operative)`n`n## Passi`n1. ...`n2. ..." }
    $md = "---`nname: $slug`ndescription: $descrizione`n---`n`n# $nome`n`n$istruzioni`n"
    Set-Content -LiteralPath (Join-Path $dir 'SKILL.md') -Value $md -Encoding UTF8
    return "Skill standard creata: skills\$slug\SKILL.md (nome='$slug'). La carichero' automaticamente quando serve."
}

function Tool-EliminaSkill {
    param([string]$base, [string]$nome)
    $s = Resolve-Skill $base $nome
    if (-not $s) { return "Skill '$nome' non trovata." }
    if ($s.dir -notlike "*\skills\*") { return "Per sicurezza elimino solo skill dentro la cartella 'skills'." }
    Remove-Item -LiteralPath $s.dir -Recurse -Force -ErrorAction SilentlyContinue
    return "Skill '$($s.name)' eliminata."
}
