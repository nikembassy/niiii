# tema_foto.ps1 -- Crea un TEMA (palette di colori) dai colori di una FOTO.
# Nessuna IA: legge i pixel dell'immagine, trova il colore piu' vivo, e costruisce una
# palette scura ma coerente con la foto (sfondo, superfici, accento, testi, bordi).
# Usa System.Drawing (solo Windows). Formati: PNG, JPG, BMP, GIF, WEBP, TIF.

function Get-ImgHue { param([double]$p, [double]$q, [double]$t)
    if ($t -lt 0.0) { $t += 1.0 }
    if ($t -gt 1.0) { $t -= 1.0 }
    if ($t -lt (1.0/6.0)) { return $p + ($q - $p) * 6.0 * $t }
    if ($t -lt 0.5)       { return $q }
    if ($t -lt (2.0/3.0)) { return $p + ($q - $p) * ((2.0/3.0) - $t) * 6.0 }
    return $p
}

function Get-ImgHsl { param([double]$H, [double]$S, [double]$L)
    # HSL (0..1) -> stringa esadecimale '#RRGGBB'
    if ($S -lt 0.0) { $S = 0.0 }; if ($S -gt 1.0) { $S = 1.0 }
    if ($L -lt 0.0) { $L = 0.0 }; if ($L -gt 1.0) { $L = 1.0 }
    $r = $L; $g = $L; $b = $L
    if ($S -gt 0.0001) {
        $q = if ($L -lt 0.5) { $L * (1.0 + $S) } else { ($L + $S) - ($L * $S) }
        $p = 2.0 * $L - $q
        $H = $H - [Math]::Floor($H)
        $r = Get-ImgHue $p $q ($H + 1.0/3.0)
        $g = Get-ImgHue $p $q $H
        $b = Get-ImgHue $p $q ($H - 1.0/3.0)
    }
    $ri = [int][Math]::Round($r * 255.0); if ($ri -lt 0) { $ri = 0 }; if ($ri -gt 255) { $ri = 255 }
    $gi = [int][Math]::Round($g * 255.0); if ($gi -lt 0) { $gi = 0 }; if ($gi -gt 255) { $gi = 255 }
    $bi = [int][Math]::Round($b * 255.0); if ($bi -lt 0) { $bi = 0 }; if ($bi -gt 255) { $bi = 255 }
    return ('#{0:X2}{1:X2}{2:X2}' -f $ri, $gi, $bi)
}

function Get-ImgHslDaRgb { param([int]$R, [int]$G, [int]$B)
    # RGB -> @(h, s, l) con h, s, l in 0..1
    $r = $R / 255.0; $g = $G / 255.0; $b = $B / 255.0
    $mx = [Math]::Max($r, [Math]::Max($g, $b))
    $mn = [Math]::Min($r, [Math]::Min($g, $b))
    $l = ($mx + $mn) / 2.0
    $h = 0.0; $s = 0.0
    if ($mx -ne $mn) {
        $d = $mx - $mn
        if ($l -gt 0.5) { $s = $d / (2.0 - $mx - $mn) } else { $s = $d / ($mx + $mn) }
        if ($mx -eq $r) { $h = (($g - $b) / $d) + $(if ($g -lt $b) { 6.0 } else { 0.0 }) }
        elseif ($mx -eq $g) { $h = (($b - $r) / $d) + 2.0 }
        else { $h = (($r - $g) / $d) + 4.0 }
        $h = $h / 6.0
    }
    return @($h, $s, $l)
}

function Get-PaletteDaImmagine {
    # Legge una foto e restituisce una palette pronta per Applica-Palette.
    param([string]$Percorso)
    if (-not $Percorso -or -not (Test-Path $Percorso)) { return $null }
    try { Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue } catch { }
    $bmp = $null; $small = $null; $ms = $null
    try {
        $ms = New-Object System.IO.MemoryStream(,[System.IO.File]::ReadAllBytes($Percorso))
        $bmp = [System.Drawing.Bitmap]::FromStream($ms)
        $small = New-Object System.Drawing.Bitmap($bmp, 48, 48)   # riduco: basta per i colori
    } catch { return $null }

    $buckets = @{}
    $totL = 0.0; $totN = 0
    for ($y = 0; $y -lt 48; $y++) {
        for ($x = 0; $x -lt 48; $x++) {
            $c = $small.GetPixel($x, $y)
            $hsl = Get-ImgHslDaRgb $c.R $c.G $c.B
            $hh = $hsl[0]; $ss = $hsl[1]; $ll = $hsl[2]
            $totL += $ll; $totN++
            if ($ll -lt 0.05 -or $ll -gt 0.97) { continue }        # salto nero/bianco puri
            $bk = [int][Math]::Floor($hh * 12.0)
            if ($bk -gt 11) { $bk = 11 }
            if (-not $buckets.ContainsKey($bk)) { $buckets[$bk] = @{ n = 0; r = 0.0; g = 0.0; b = 0.0; w = 0.0 } }
            $e = $buckets[$bk]
            $e.n = $e.n + 1
            $e.r = $e.r + $c.R; $e.g = $e.g + $c.G; $e.b = $e.b + $c.B
            $e.w = $e.w + ($ss * (1.0 - [Math]::Abs($ll - 0.55)))  # premia i colori vivi e medi
        }
    }
    try { $small.Dispose(); $bmp.Dispose(); $ms.Dispose() } catch { }

    # accento = "famiglia" di colore piu' viva della foto
    $best = $null
    foreach ($k in @($buckets.Keys)) {
        $e = $buckets[$k]
        if ($e.n -lt 6) { continue }
        if (($null -eq $best) -or ($e.w -gt $best.w)) { $best = $e }
    }
    $ah = 0.58; $as = 0.35; $al = 0.55
    if ($best) {
        $ar = [int]($best.r / $best.n); $ag = [int]($best.g / $best.n); $ab = [int]($best.b / $best.n)
        $ahsl = Get-ImgHslDaRgb $ar $ag $ab
        $ah = $ahsl[0]; $as = $ahsl[1]; $al = $ahsl[2]
    }
    if ($as -lt 0.20) { $as = 0.20 }    # almeno un po' di colore, altrimenti viene slavato
    if ($al -lt 0.45) { $al = 0.45 }
    if ($al -gt 0.70) { $al = 0.70 }

    $p = [ordered]@{}
    $p.preset         = 'foto'
    $p.sfondo         = Get-ImgHsl $ah 0.32 0.055
    $p.superficie     = Get-ImgHsl $ah 0.30 0.085
    $p.campo          = Get-ImgHsl $ah 0.28 0.110
    $p.pill           = Get-ImgHsl $ah 0.28 0.130
    $p.accento        = Get-ImgHsl $ah $as $al
    $p.accentoChiaro  = Get-ImgHsl $ah ([Math]::Min(1.0, $as * 0.85)) ([Math]::Min(0.86, $al + 0.18))
    $p.accentoScuro   = Get-ImgHsl $ah $as ([Math]::Max(0.24, $al - 0.18))
    $p.argento        = Get-ImgHsl $ah 0.06 0.82
    $p.argentoScuro   = Get-ImgHsl $ah 0.06 0.62
    $p.testo          = Get-ImgHsl $ah 0.05 0.94
    $p.testoSuAccento = Get-ImgHsl $ah 0.30 0.08
    $p.bordo          = Get-ImgHsl $ah 0.24 0.24
    $p.font           = 'Segoe UI'
    $p.fontSize       = 13
    $p.sfondoImmagine = $Percorso
    return $p
}
