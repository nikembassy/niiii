﻿# osint.ps1 -- OSINT PASSIVO (Open Source INTelligence) per ZAP v7.9.8.
# ---------------------------------------------------------------------------
#  Raccolta di informazioni da FONTI PUBBLICHE, senza contattare in modo
#  aggressivo il bersaglio: RDAP/WHOIS, DNS, certificati (crt.sh),
#  geolocalizzazione IP, reverse DNS, porte esposte (InternetDB), header e
#  metadati dei file (EXIF/GPS). Serve per inventario della superficie d'attacco,
#  verifica della propria esposizione online e ricerca lecita su persone/aziende.
#
#  USO CONSENTITO: solo su te stesso / sui TUOI sistemi o per finalita' lecite
#  (due diligence, giornalismo, sicurezza autorizzata). Rispetta i termini di
#  servizio delle fonti e la normativa sulla privacy (GDPR).
#
#  Le funzioni marcate [PURA] non dipendono dalla rete e sono testabili a parte.
# ---------------------------------------------------------------------------

function Get-OsintDefault {
    return @{
        attivo          = $true
        user_agent      = 'ZAP-OSINT/1.0'
        timeout_sec     = 20
        fonti           = @('rdap','dns','crtsh','ipgeo','internetdb','headers','metadati')
        consenti_breach = $false
        scope           = @()
    }
}

function Get-OsintFonti {
    # [PURA] Catalogo delle ricerche disponibili.
    return @(
        @{ id='dominio';  nome='Dominio';   cerca='Registrante (RDAP), record DNS, sottodomini (crt.sh).' }
        @{ id='ip';       nome='IP';        cerca='Geolocalizzazione, provider/ASN, reverse DNS, porte esposte (InternetDB).' }
        @{ id='email';    nome='Email';     cerca='MX del dominio, SPF/DMARC, postura email.' }
        @{ id='username'; nome='Username';  cerca='Presenza dello pseudonimo su siti pubblici (profilazione).' }
        @{ id='metadati'; nome='Metadati';  cerca='EXIF/GPS/autore dentro una foto o un documento.' }
        @{ id='azienda';  nome='Azienda';   cerca='Dominio, sottodomini e impronte pubbliche.' }
    )
}

function Get-OsintUA {
    param($sync)
    $ua = 'ZAP-OSINT/1.0'
    try { if ($sync.Config.osint.user_agent) { $ua = [string]$sync.Config.osint.user_agent } } catch { }
    return $ua
}

function Invoke-OsintJson {
    param([string]$Url, [int]$TimeoutSec = 20, [string]$Ua = 'ZAP-OSINT/1.0')
    try { return (Invoke-RestMethod -Uri $Url -TimeoutSec $TimeoutSec -Headers @{ 'User-Agent' = $Ua } -ErrorAction Stop) }
    catch { return $null }
}

function Invoke-OsintDominio {
    param($sync, [string]$Target)
    $ua = Get-OsintUA $sync
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("OSINT DOMINIO: $Target")
    $rdap = Invoke-OsintJson -Url ("https://rdap.org/domain/" + $Target) -Ua $ua
    if ($rdap) {
        [void]$out.Add('-- RDAP (WHOIS moderno) --')
        if ($rdap.ldhName) { [void]$out.Add('  dominio    : ' + [string]$rdap.ldhName) }
        foreach ($ev in @($rdap.events)) { [void]$out.Add('  ' + [string]$ev.eventAction + ' : ' + [string]$ev.eventDate) }
        $ns = @(); foreach ($n in @($rdap.nameservers)) { if ($n.ldhName) { $ns += [string]$n.ldhName } }
        if ($ns.Count) { [void]$out.Add('  nameserver : ' + ($ns -join ', ')) }
        $reg = ''
        foreach ($e in @($rdap.entities)) {
            $roles = @(); try { $roles = @($e.roles) } catch { }
            if ($roles -contains 'registrant') { try { foreach ($v in @($e.vcardArray[1])) { if ($v[0] -eq 'fn') { $reg = [string]$v[3] } } } catch { } }
        }
        if ($reg) { [void]$out.Add('  registrant : ' + $reg) }
    } else { [void]$out.Add('-- RDAP: nessuna risposta --') }
    foreach ($t in @('A','MX','TXT','NS')) {
        try {
            $rr = Resolve-DnsName -Name $Target -Type $t -ErrorAction Stop
            $vals = @($rr | ForEach-Object { $_.NameHost; $_.IPAddress; $_.Strings } | Where-Object { $_ })
            if ($vals.Count) { [void]$out.Add('  DNS ' + $t.PadRight(3) + ': ' + (($vals | Select-Object -First 8) -join '; ')) }
        } catch { }
    }
    try {
        $crt = Invoke-RestMethod -Uri ("https://crt.sh/?q=%25." + $Target + "&output=json") -TimeoutSec 25 -Headers @{ 'User-Agent' = $ua } -ErrorAction Stop
        $subs = @($crt | ForEach-Object { $_.name_value } | ForEach-Object { $_ -split "`n" } | Where-Object { $_ -and ($_ -notmatch '^\*') } | Sort-Object -Unique)
        if ($subs.Count) {
            [void]$out.Add('  sottodomini (crt.sh): ' + (($subs | Select-Object -First 20) -join ', '))
            [void]$out.Add('  (totale sottodomini trovati: ' + $subs.Count + ')')
        }
    } catch { }
    [void]$out.Add('  NOTA: dati da fonti pubbliche; non contattare il bersaglio in modo aggressivo.')
    return ($out -join "`n")
}

function Invoke-OsintIp {
    param($sync, [string]$Target)
    $ua = Get-OsintUA $sync
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("OSINT IP: $Target")
    $geo = Invoke-OsintJson -Url ("http://ip-api.com/json/" + $Target) -Ua $ua
    if ($geo -and ([string]$geo.status -eq 'success')) {
        [void]$out.Add('  posizione  : ' + [string]$geo.country + ' / ' + [string]$geo.regionName + ' / ' + [string]$geo.city)
        [void]$out.Add('  provider   : ' + [string]$geo.isp + ' (' + [string]$geo.org + ') AS ' + [string]$geo.as)
        [void]$out.Add('  coordinate : ' + [string]$geo.lat + ', ' + [string]$geo.lon + '  fuso: ' + [string]$geo.timezone)
    } else { [void]$out.Add('  (geolocalizzazione non disponibile)') }
    try { $rev = [System.Net.Dns]::GetHostEntry($Target); if ($rev.HostName) { [void]$out.Add('  reverse DNS: ' + $rev.HostName) } } catch { }
    $idb = Invoke-OsintJson -Url ("https://internetdb.shodan.io/" + $Target) -Ua $ua
    if ($idb) {
        if (@($idb.ports).Count) { [void]$out.Add('  porte esposte : ' + ((@($idb.ports) | Sort-Object) -join ', ')) }
        if (@($idb.hostnames).Count) { [void]$out.Add('  hostname      : ' + (@($idb.hostnames) -join ', ')) }
        if (@($idb.vulns).Count) { [void]$out.Add('  CVE note      : ' + (@($idb.vulns) -join ', ')) }
    }
    return ($out -join "`n")
}

function Invoke-OsintEmail {
    param($sync, [string]$Target)
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("OSINT EMAIL: $Target")
    $dom = ''
    if ($Target -match '@(.+)$') { $dom = $Matches[1] }
    if ($dom) {
        try { $mx = Resolve-DnsName -Name $dom -Type MX -ErrorAction Stop; $m = @($mx | ForEach-Object { $_.NameExchange } | Where-Object { $_ }); if ($m.Count) { [void]$out.Add('  provider email (MX): ' + ($m -join ', ')) } } catch { }
        try { $tx = Resolve-DnsName -Name $dom -Type TXT -ErrorAction Stop; $spf = (@($tx | ForEach-Object { $_.Strings } | Where-Object { $_ -match 'v=spf1' }) -join ' '); if ($spf) { [void]$out.Add('  SPF   : ' + $spf) } } catch { }
        try { $dt = Resolve-DnsName -Name ('_dmarc.' + $dom) -Type TXT -ErrorAction Stop; $dm = (@($dt | ForEach-Object { $_.Strings } | Where-Object { $_ -match 'v=DMARC1' }) -join ' '); [void]$out.Add('  DMARC : ' + $(if ($dm) { $dm } else { 'assente (postura email debole)' })) } catch { [void]$out.Add('  DMARC : assente (postura email debole)') }
    }
    [void]$out.Add("  NOTA: la verifica di esposizione in data breach (HaveIBeenPwned) richiede una API key; abilitala in config se la possiedi.")
    return ($out -join "`n")
}

function Invoke-OsintUsername {
    param($sync, [string]$Target)
    $ua = Get-OsintUA $sync
    $u = [string]$Target
    $siti = @(
        @{ nome='GitHub';    url=('https://github.com/' + $u) },
        @{ nome='GitLab';    url=('https://gitlab.com/' + $u) },
        @{ nome='Reddit';    url=('https://www.reddit.com/user/' + $u) },
        @{ nome='Telegram';  url=('https://t.me/' + $u) },
        @{ nome='Twitter/X'; url=('https://x.com/' + $u) },
        @{ nome='TikTok';    url=('https://www.tiktok.com/@' + $u) },
        @{ nome='HackerNews';url=('https://news.ycombinator.com/user?id=' + $u) }
    )
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("OSINT USERNAME: $u  (profilazione passiva su siti pubblici)")
    foreach ($s in $siti) {
        $stato = 'assente / errore'
        try {
            $r = Invoke-WebRequest -Uri $s.url -Method Head -TimeoutSec 12 -UseBasicParsing -Headers @{ 'User-Agent' = $ua } -ErrorAction Stop
            $cd = [int]$r.StatusCode
            if ($cd -ge 200 -and $cd -lt 300) { $stato = 'PRESENTE' }
            elseif ($cd -eq 403 -or $cd -eq 429) { $stato = 'bloccato (anti-bot)' }
        } catch {
            $cd = 0; try { $cd = [int]$_.Exception.Response.StatusCode } catch { }
            if ($cd -eq 200) { $stato = 'PRESENTE' }
        }
        [void]$out.Add('  ' + $s.nome.PadRight(11) + ': ' + $stato + '   ' + $s.url)
    }
    [void]$out.Add('  NOTA: la rilevazione via HEAD e best-effort (anti-bot/redirect possono falsare l esito).')
    return ($out -join "`n")
}

function Invoke-OsintMetadati {
    param([string]$Percorso)
    if (-not $Percorso) { return '!Serve il percorso di una foto o di un documento.' }
    if (-not (Test-Path -LiteralPath $Percorso)) { return ('!File non trovato: ' + $Percorso) }
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("OSINT METADATI: $Percorso")
    $tags = @{ 0x010F='Produttore'; 0x0110='Modello'; 0x0131='Software'; 0x0132='Data/Ora'; 0x013B='Autore'; 0x8298='Copyright'; 0x9003='Data scatto'; 0x8827='ISO' }
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        $img = [System.Drawing.Image]::FromFile($Percorso)
        foreach ($pi in $img.PropertyItems) {
            $nome = 'Tag 0x' + ('{0:X4}' -f $pi.Id)
            if ($tags.ContainsKey($pi.Id)) { $nome = [string]$tags[$pi.Id] }
            $val = ''
            if ($pi.Type -eq 2) { $val = [System.Text.Encoding]::ASCII.GetString($pi.Value).Trim([char]0).Trim() }
            else { $val = (([System.BitConverter]::ToString($pi.Value)) -replace '-', ' ') }
            if ($val) { [void]$out.Add('  ' + $nome + ': ' + $val) }
        }
        $gps = @($img.PropertyItems | Where-Object { $_.Id -eq 0x8825 })
        if ($gps.Count) { [void]$out.Add('  GPS: PRESENTE (tag 0x8825) - il file contiene coordinate geografiche') }
        $img.Dispose()
    } catch { [void]$out.Add('  (metadati non leggibili: ' + $_.Exception.Message + ')') }
    return ($out -join "`n")
}

function Invoke-Osint {
    param($sync, [string]$Tipo, [string]$Target, [string]$Extra = '')
    $t = ([string]$Tipo).Trim().ToLower()
    switch ($t) {
        'dominio'  { return (Invoke-OsintDominio $sync $Target) }
        'azienda'  { return (Invoke-OsintDominio $sync $Target) }
        'ip'       { return (Invoke-OsintIp $sync $Target) }
        'email'    { return (Invoke-OsintEmail $sync $Target) }
        'username' { return (Invoke-OsintUsername $sync $Target) }
        'metadati' { return (Invoke-OsintMetadati $(if ($Extra) { $Extra } else { $Target })) }
        default    { return (Tool-OsintCatalogo) }
    }
}

function Format-OsintInfo {
    param($sync)
    $os = $null; try { $os = $sync.Config.osint } catch { }
    if ($null -eq $os) { $os = Get-OsintDefault }
    $att = $true; try { $att = [bool]$os.attivo } catch { }
    $out = @()
    $out += "OSINT PASSIVO - fonti pubbliche (dominio, IP, email, username, metadati)"
    $out += ('  stato: ' + $(if ($att) { 'attivo' } else { 'spento' }))
    foreach ($f in (Get-OsintFonti)) { $out += ('  ' + $f.id.PadRight(9) + ': ' + $f.cerca) }
    $out += '  uso: /osint <tipo> <bersaglio>    oppure il tool osint_ricerca'
    $out += '  NOTA: uso lecito (GDPR, ToS). Nessun contatto aggressivo col bersaglio.'
    return ($out -join "`n")
}

function Tool-OsintCatalogo {
    return (Format-OsintInfo $null)
}

function Tool-OsintRicerca {
    param($base, $sync, [string]$Tipo, [string]$Target, [string]$Extra = '')
    if (-not $Tipo) { return (Tool-OsintCatalogo) }
    return (Invoke-Osint $sync $Tipo $Target $Extra)
}
