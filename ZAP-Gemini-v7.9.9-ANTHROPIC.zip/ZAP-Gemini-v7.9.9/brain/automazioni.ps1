﻿# ============================================================================
#  automazioni.ps1  --  ZAP 7.1 : catalogo automazioni (Pannello AUTOMAZIONE)
# ----------------------------------------------------------------------------
#  Genera l'ELENCO di cose che ZAP puo' fare da solo: voci fisse (pulizia,
#  organizza Download, report...) + voci dinamiche ricavate dal TUO PC (le tue
#  cartelle reali). Ogni voce ha uno script PowerShell eseguito dal Task Scheduler,
#  anche a ZAP chiuso.
# ============================================================================

function Get-CatalogoAutomazioni {
    param([string]$base)
    $out = New-Object System.Collections.ArrayList

    # ---- Backup dinamici: una voce per ogni cartella che ESISTE davvero ----
    $min = 20
    $cartelle = @(
        @{ p = [Environment]::GetFolderPath('Desktop');      n = 'Desktop' },
        @{ p = [Environment]::GetFolderPath('MyDocuments');  n = 'Documenti' },
        @{ p = [Environment]::GetFolderPath('MyPictures');   n = 'Immagini' },
        @{ p = [Environment]::GetFolderPath('MyVideos');     n = 'Video' },
        @{ p = [Environment]::GetFolderPath('MyMusic');      n = 'Musica' },
        @{ p = (Join-Path $env:USERPROFILE 'Downloads');     n = 'Download' }
    )
    foreach ($c in $cartelle) {
        if ($c.p -and (Test-Path -LiteralPath $c.p)) {
            $slug = ([string]$c.n).ToLower()
            $ora = ('{0:00}:00' -f $min); $min = $min + 10; if ($min -gt 23) { $min = 20 }
            [void]$out.Add([pscustomobject]@{
                id = ('backup_' + $slug)
                titolo = ('Backup di ' + $c.n + ' ogni giorno alle ' + $ora)
                desc = ('Copia la cartella ' + $c.n + ' in ZAP_Backup con la data di oggi')
                categoria = 'Backup'; tipo = 'orario'; quando = ''; orario = $ora
                script = ("ZapBackup '" + $c.n + "'")
            })
        }
    }

    # ---- Voci fisse utili a tutti ----
    [void]$out.Add([pscustomobject]@{
        id = 'organizza_download'; titolo = 'Organizza la cartella Download per tipo'
        desc = 'Sposta i file di Download in sottocartelle: Immagini, Documenti, Video, Audio, Archivi'
        categoria = 'File'; tipo = 'orario'; quando = ''; orario = '21:00'
        script = ('$dl=Join-Path $env:USERPROFILE ''Downloads''; if(Test-Path -LiteralPath $dl){ $n=0; Get-ChildItem -LiteralPath $dl -File -ErrorAction SilentlyContinue | ForEach-Object { $e=$_.Extension.ToLower(); $c=''Altro''; if($e -match ''\.(jpg|jpeg|png|gif|bmp|webp)$''){$c=''Immagini''} elseif($e -match ''\.(pdf|docx?|xlsx?|pptx?|txt|csv)$''){$c=''Documenti''} elseif($e -match ''\.(mp4|mkv|avi|mov|wmv)$''){$c=''Video''} elseif($e -match ''\.(mp3|wav|flac|m4a)$''){$c=''Audio''} elseif($e -match ''\.(zip|rar|7z|tar|gz)$''){$c=''Archivi''}; $dst=Join-Path $dl $c; New-Item -ItemType Directory -Force -Path $dst | Out-Null; Move-Item -LiteralPath $_.FullName -Destination $dst -Force -ErrorAction SilentlyContinue; $n++ }; ''Organizzati ''+$n+'' file in Download'' } else { ''Cartella Download non trovata'' }')
    })
    [void]$out.Add([pscustomobject]@{
        id = 'pulizia_temp'; titolo = 'Pulisci i file temporanei (piu vecchi di 7 giorni)'
        desc = 'Libera spazio eliminando la spazzatura nella cartella temporanea di Windows'
        categoria = 'Manutenzione'; tipo = 'settimanale'; quando = 'SUN'; orario = '10:00'
        script = ('$tmp=$env:TEMP; $lim=(Get-Date).AddDays(-7); $n=0; Get-ChildItem -LiteralPath $tmp -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $lim } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue; $n++ }; ''Eliminati ''+$n+'' file temporanei vecchi''')
    })
    [void]$out.Add([pscustomobject]@{
        id = 'elimina_download_vecchi'; titolo = 'Elimina i download piu vecchi di 30 giorni'
        desc = 'Tiene pulita la cartella Download dai file vecchi'
        categoria = 'Pulizia'; tipo = 'settimanale'; quando = 'SUN'; orario = '10:30'
        script = ('$dl=Join-Path $env:USERPROFILE ''Downloads''; $lim=(Get-Date).AddDays(-30); $n=0; if(Test-Path -LiteralPath $dl){ Get-ChildItem -LiteralPath $dl -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $lim } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue; $n++ } }; ''Eliminati ''+$n+'' download vecchi''')
    })
    [void]$out.Add([pscustomobject]@{
        id = 'svuota_cestino'; titolo = 'Svuota il Cestino (una volta a settimana)'
        desc = 'Recupera spazio cancellando definitivamente il Cestino'
        categoria = 'Pulizia'; tipo = 'settimanale'; quando = 'SUN'; orario = '11:00'
        script = ('try { Clear-RecycleBin -Force -ErrorAction Stop; ''Cestino svuotato'' } catch { ''Cestino gia vuoto o non accessibile'' }')
    })
    [void]$out.Add([pscustomobject]@{
        id = 'report_sistema'; titolo = 'Riepilogo dello stato del PC ogni mattina'
        desc = 'Ti dice RAM usata, memoria libera e da quanto tempo e accesso il PC'
        categoria = 'Sistema'; tipo = 'orario'; quando = ''; orario = '09:00'
        script = ('$os=Get-CimInstance Win32_OperatingSystem; $tot=[math]::Round($os.TotalVisibleMemorySize/1MB,1); $free=[math]::Round($os.FreePhysicalMemory/1MB,1); $up=(Get-Date)-$os.LastBootUpTime; ''RAM usata ''+[math]::Round($tot-$free,1)+''/''+$tot+'' GB - acceso da ''+[int]$up.TotalHours+''h''')
    })
    [void]$out.Add([pscustomobject]@{
        id = 'buongiorno'; titolo = 'Buongiorno: notifica con la data di oggi'
        desc = 'Ogni mattina ZAP ti saluta con la data (notifica in basso a destra)'
        categoria = 'Personale'; tipo = 'orario'; quando = ''; orario = '07:30'
        script = ('''Buongiorno! Oggi e '' + (Get-Date -Format ''dddd dd MMMM yyyy'') + '' - buona giornata da ZAP.''')
    })
    return $out
}

function Get-AutomazioneById {
    param([string]$base, [string]$id)
    return @(Get-CatalogoAutomazioni $base | Where-Object { $_.id -eq $id })[0]
}

function New-AutomazioneScelta {
    param($sync, $item)
    if (-not $item) { return "Automazione non trovata." }
    $r = Tool-PianificaTask -base $sync.Base -nome $item.titolo -tipo $item.tipo -quando $item.quando -azione '' -orario $item.orario -script $item.script
    return ("ATTIVATA: " + $item.titolo + ' -> ' + [string]$r)
}

function New-AutomazioneLibera {
    param($sync, [string]$testo)
    if (-not $testo) { return "Scrivi cosa vuoi automatizzare." }
    $nome = $testo
    if ($nome.Length -gt 40) { $nome = $nome.Substring(0,40) }
    $r = Tool-PianificaTask -base $sync.Base -nome ('Automazione: ' + $nome) -tipo 'orario' -quando '' -azione $testo -orario '09:00' -script ''
    return ("ATTIVATA ogni giorno alle 09:00 -> " + [string]$r)
}

function Get-AutomazioniAttive {
    param([string]$base)
    return @(Get-TaskStore $base)
}

# ---------------------------- TOOLS per l'agente ---------------------------

function Tool-ElencoAutomazioni {
    param([string]$base)
    $cat = @(Get-CatalogoAutomazioni $base)
    $righe = foreach ($a in $cat) { "  - $($a.id): $($a.titolo) [$($a.categoria)]" }
    return "Automazioni disponibili ($($cat.Count)):`n" + ($righe -join "`n") + "`n`nUsa attiva_automazione con l'id per attivarne una."
}

function Tool-AttivaAutomazione {
    param($sync, [string]$id)
    $item = Get-AutomazioneById $sync.Base $id
    if (-not $item) { return "Automazione '$id' non trovata. Usa elenco_automazioni." }
    return (New-AutomazioneScelta $sync $item)
}
