﻿# pc_controllo.ps1 -- Controllo del PC in linguaggio naturale.
# Regola d'oro: il comando viene capito in LOCALE (nessun giro sull'IA) => risposta immediata
# e funziona anche se internet/API sono giu'. Le azioni irreversibili chiedono conferma.

function Get-AppNoti {
    # Nomi colloquiali -> comando di avvio. Solo cose reali di Windows.
    return [ordered]@{
        'blocco note'        = 'notepad'
        'notepad'            = 'notepad'
        'calcolatrice'       = 'calc'
        'calculator'         = 'calc'
        'paint'              = 'mspaint'
        'esplora file'       = 'explorer'
        'esplora risorse'    = 'explorer'
        'explorer'           = 'explorer'
        'prompt dei comandi' = 'cmd'
        'cmd'                = 'cmd'
        'powershell'         = 'powershell'
        'terminale'          = 'wt'
        'task manager'       = 'taskmgr'
        'gestione attivita'  = 'taskmgr'
        'pannello di controllo' = 'control'
        'impostazioni'       = 'ms-settings:'
        'word'               = 'winword'
        'excel'              = 'excel'
        'powerpoint'         = 'powerpnt'
        'outlook'            = 'outlook'
        'visual studio code' = 'code'
        'vs code'            = 'code'
        'thorium'            = 'thorium'
        'chrome'             = 'chrome'
        'edge'               = 'msedge'
        'firefox'            = 'firefox'
        'yandex'             = 'browser'
        'whatsapp'           = 'https://web.whatsapp.com'
        'whatsapp web'       = 'https://web.whatsapp.com'
        'youtube'            = 'https://www.youtube.com'
        'gmail'              = 'https://mail.google.com'
    }
}

function Remove-ArticoliIniziali {
    param([string]$Testo)
    $t = ([string]$Testo).Trim()
    $t = [regex]::Replace($t, '(?i)^(il|lo|la|i|gli|le|un|uno|una|un''|del|dello|della|dei|degli|delle|di|da|su|a)\s+', '')
    return $t.Trim()
}

function Test-SembraIndirizzo {
    param([string]$Testo)
    $t = ([string]$Testo).Trim()
    if (-not $t) { return $false }
    if ($t -match '^(?i)https?://') { return $true }
    if ($t -match '^(?i)www\.') { return $true }
    if ($t -match '^[A-Za-z0-9\-\.]+\.[A-Za-z]{2,}(/\S*)?$') { return $true }
    return $false
}

function Resolve-ComandoDiretto {
    # PARSER PURO. Restituisce @{ Azione='' ; ... } ; Azione='' => non e' un comando locale.
    param($sync, [string]$Testo)
    $r = @{ Azione = ''; Nome = ''; Filtro = ''; Url = ''; Query = ''; Testo = '';
            Destinatario = ''; Messaggio = ''; Risposta = '' }
    $t = [string]$Testo
    if (-not $t) { return $r }
    $t = $t.Trim()
    if ($t.Length -gt 400) { $t = $t.Substring(0, 400) }
    $low = ([regex]::Replace($t.ToLower(), '[\.!\?]+$', '')).Trim()

    # --- WhatsApp: apri e scrivi a <nome>[:] <messaggio> ---
    $m = [regex]::Match($t, '(?i)^\s*(?:apri\s+|aprimi\s+)?whatsapp\s*(?:web)?\s*e\s+(?:scrivi|manda|invia|mandami|scrivi un messaggio)\s+a\s+(.+?)(?:\s*[:,]\s*|\s+il messaggio\s*|\s+dicendo\s*)(.*)$')
    if ($m.Success) {
        $r.Azione = 'whatsapp'
        $r.Destinatario = (Remove-ArticoliIniziali $m.Groups[1].Value.Trim())
        $r.Messaggio = $m.Groups[2].Value.Trim()
        $r.Risposta = "Apro WhatsApp per $($r.Destinatario)."
        return $r
    }
    $m = [regex]::Match($t, '(?i)^\s*(?:manda|invia|scrivi)\s+(?:un\s+messaggio\s+)?a\s+(.+?)\s+su\s+whatsapp\s*(?:[:,]\s*|\s+il messaggio\s+)?(.*)$')
    if ($m.Success) {
        $r.Azione = 'whatsapp'
        $r.Destinatario = (Remove-ArticoliIniziali $m.Groups[1].Value.Trim())
        $r.Messaggio = $m.Groups[2].Value.Trim()
        $r.Risposta = "Apro WhatsApp per $($r.Destinatario)."
        return $r
    }

    # --- Chiudi finestra / pagina ---
    if ([regex]::IsMatch($low, '^(chiudi|chiudimi|chiudere|serra|serrami)\b')) {
        $r.Azione = 'chiudi_finestra'
        $m = [regex]::Match($t, '(?i)(?:chiudi|chiudimi|chiudere|serra|serrami)\s+(?:il|la|lo|l''|i|gli|le)?\s*(.+)$')
        if ($m.Success) {
            $cand = (Remove-ArticoliIniziali $m.Groups[1].Value.Trim())
            $cand = [regex]::Replace($cand, '(?i)^(questa|questo|quella|quello)\s+', '')
            $cand = [regex]::Replace($cand, '(?i)^(pagina|finestra|scheda|tab|app|applicazione|programma)\s*', '')
            $cand = (Remove-ArticoliIniziali $cand)
            if ($cand -and -not ($cand -match '(?i)^(tutto|tutte|active|attiva)$')) { $r.Filtro = $cand }
        }
        if ($r.Filtro) { $r.Risposta = "Chiudo: $($r.Filtro)." } else { $r.Risposta = 'Chiudo la finestra attiva.' }
        return $r
    }

    # --- Minimizza / massimizza ---
    if ([regex]::IsMatch($low, '^(minimizza|riduci)\b'))   { $r.Azione = 'minimizza_finestra';  $r.Filtro = (Remove-ArticoliIniziali ([regex]::Replace($t, '(?i)^(minimizza|riduci)\s*', ''))); $r.Risposta = 'Minimizzo.'; return $r }
    if ([regex]::IsMatch($low, '^(massimizza|ingrandisci)\b')) { $r.Azione = 'massimizza_finestra'; $r.Filtro = (Remove-ArticoliIniziali ([regex]::Replace($t, '(?i)^(massimizza|ingrandisci)\s*', ''))); $r.Risposta = 'Massimizzo.'; return $r }

    # --- Elenca finestre / programmi ---
    if ([regex]::IsMatch($low, '(elenca|mostra|quali sono|che)\s+.*(finestre|programmi aperti|cosa (e''|è) (aperto|in esecuzione))')) {
        $r.Azione = 'elenca_finestre'; $r.Risposta = 'Guardo cosa e'' aperto.'; return $r
    }
    if ([regex]::IsMatch($low, '(quali|che)\s+programmi\s+(ho|ci sono|posso lanciare)|elenco dei programmi|i miei programmi|lista programmi')) {
        $r.Azione = 'elenca_programmi'; $r.Risposta = 'Ecco i tuoi programmi.'; return $r
    }

    # --- Cerca sul web ---
    $m = [regex]::Match($t, '(?i)^\s*(cerca|cercami|ricerca|trovami)\s+(?:su\s+\S+\s+)?(.+)$')
    if ($m.Success) {
        $r.Azione = 'cerca'; $r.Query = $m.Groups[2].Value.Trim()
        $r.Risposta = "Cerco: $($r.Query)."
        return $r
    }

    # --- Apri sito ---
    $m = [regex]::Match($t, '(?i)^\s*(apri|aprimi|vai su|naviga su|naviga verso|apri il sito)\s+(.+)$')
    if ($m.Success) {
        $target = (Remove-ArticoliIniziali $m.Groups[2].Value.Trim())
        if (Test-SembraIndirizzo $target) {
            $r.Azione = 'apri_sito'; $r.Url = $target
            $r.Risposta = "Apro $target."
            return $r
        }
    }

    # --- Scrivì / digita testo nella finestra attiva ---
    $m = [regex]::Match($t, '(?i)^\s*(scrivi|digita|batti)\s+(?!a\b|un messaggio)(.+)$')
    if ($m.Success) {
        $r.Azione = 'scrivi_testo'; $r.Testo = $m.Groups[2].Value.Trim()
        $r.Risposta = 'Scrivo quello che mi hai detto.'
        return $r
    }

    # --- Lancia un tuo programma ---
    $m = [regex]::Match($t, '(?i)^\s*(lancia|avvia|esegui|fai partire|apri il mio|apri la mia)\s+(.+)$')
    if ($m.Success) {
        $nome = (Remove-ArticoliIniziali $m.Groups[2].Value.Trim())
        $nome = [regex]::Replace($nome, '(?i)^(mio|mia|miei|mie)\s+', '').Trim()
        $r.Azione = 'lancia_programma'; $r.Nome = $nome
        $r.Risposta = "Lancio $nome."
        return $r
    }

    # --- Apri programma noto ---
    $m = [regex]::Match($t, '(?i)^\s*(apri|aprimi|avvia|fammi vedere|mostrami)\s+(?:al volo\s+|subito\s+|un\s+|una\s+|il\s+|la\s+|lo\s+)*(.+)$')
    if ($m.Success) {
        $nome = (Remove-ArticoliIniziali $m.Groups[2].Value.Trim())
        $nome = [regex]::Replace($nome, '(?i)^(nuovo|nuova|altro|altra)\s+', '').Trim()
        $nome = [regex]::Replace($nome, '(?i)^(mio|mia|miei|mie)\s+', '').Trim()
        $nome = [regex]::Replace($nome, '(?i)^(?:programma|app|applicazione)\s+(?:di\s+|del\s+|della\s+|dei\s+)?', '').Trim()
        $noti = Get-AppNoti
        if ($noti.Contains($nome.ToLower())) {
            $r.Azione = 'apri_programma'; $r.Nome = $nome
            $r.Risposta = "Apro $nome."
            return $r
        }
        $senzaSpazi = $nome.ToLower()
        foreach ($k in @($noti.Keys)) { if ($k -eq $senzaSpazi) { $r.Azione='apri_programma'; $r.Nome=$nome; $r.Risposta="Apro $nome."; return $r } }
        if ($sync) {
            $p = Resolve-ProgrammaDaNome $sync $nome
            if ($p) { $r.Azione = 'lancia_programma'; $r.Nome = $p.nome; $r.Risposta = "Lancio $($p.nome)."; return $r }
        }
        if (Test-SembraIndirizzo $nome) { $r.Azione='apri_sito'; $r.Url=$nome; $r.Risposta="Apro $nome."; return $r }
    }

    return $r
}

# ---------------------------------------------------------------------------
# Azioni reali (solo su Windows)
# ---------------------------------------------------------------------------

function Initialize-PcControllo {
    if ($env:OS -ne 'Windows_NT') { return $false }
    if (([System.Management.Automation.PSTypeName]'ZapWin32').Type) { return $true }
    $code = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class ZapWin32 {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder text, int count);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
}
'@
    try { Add-Type -TypeDefinition $code -ErrorAction Stop; return $true } catch { return $false }
}

function Wait-Umano {
    # Ritmo umano: nessun click istantaneo in raffica.
    param([int]$Min = 250, [int]$Max = 650)
    try { Start-Sleep -Milliseconds (Get-Random -Minimum $Min -Maximum $Max) } catch { Start-Sleep -Milliseconds $Min }
}

function Get-Finestre {
    if (-not (Initialize-PcControllo)) { return @() }
    $out = New-Object System.Collections.ArrayList
    $cb = [ZapWin32+EnumWindowsProc] {
        param($h, $l)
        try {
            if ([ZapWin32]::IsWindowVisible($h)) {
                $sb = New-Object System.Text.StringBuilder 1024
                [void][ZapWin32]::GetWindowTextW($h, $sb, 1024)
                $tit = $sb.ToString()
                if ($tit -and $tit.Trim()) {
                    $pid = [uint32]0
                    [void][ZapWin32]::GetWindowThreadProcessId($h, [ref]$pid)
                    $nome = ''
                    try { $nome = (Get-Process -Id ([int]$pid) -ErrorAction SilentlyContinue).ProcessName } catch { }
                    [void]$out.Add(@{ hwnd = [int64]$h; titolo = $tit; processo = $nome; pid = [int]$pid })
                }
            }
        } catch { }
        return $true
    }
    try { [void][ZapWin32]::EnumWindows($cb, [IntPtr]::Zero) } catch { }
    return @($out)
}

function Get-FinestraAttiva {
    if (-not (Initialize-PcControllo)) { return $null }
    $h = [ZapWin32]::GetForegroundWindow()
    foreach ($f in @(Get-Finestre)) { if ($f.hwnd -eq [int64]$h) { return $f } }
    return $null
}

function Find-Finestra {
    param([string]$Filtro)
    $fin = @(Get-Finestre)
    if (-not $Filtro) { return (Get-FinestraAttiva) }
    $f0 = ([string]$Filtro).ToLower().Trim()
    if (-not $f0) { return (Get-FinestraAttiva) }
    foreach ($f in $fin) { if ($f.titolo.ToLower().Contains($f0)) { return $f } }
    foreach ($f in $fin) { if ($f.processo.ToLower().Contains($f0)) { return $f } }
    return $null
}

function Format-Finestre {
    $fin = @(Get-Finestre)
    if ($fin.Count -eq 0) { return 'Non vedo finestre aperte (o non sono su Windows).' }
    $righe = @("Finestre aperte ($($fin.Count)):")
    foreach ($f in $fin) { $righe += ("- " + $f.titolo + "   [" + $f.processo + "]") }
    return ($righe -join "`n")
}

function Close-Finestra {
    param([string]$Filtro)
    if (-not (Initialize-PcControllo)) { return 'Non sono su Windows: non posso chiudere finestre.' }
    $f = Find-Finestra $Filtro
    if (-not $f) {
        if ($Filtro) { return ("Non trovo nessuna finestra con '" + $Filtro + "'.") }
        return 'Non trovo la finestra attiva.'
    }
    try { [void][ZapWin32]::PostMessageW([IntPtr]$f.hwnd, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) } catch { return 'Non riesco a inviare la chiusura.' }
    Start-Sleep -Milliseconds 450
    $ancora = @(Get-Finestre) | Where-Object { $_.hwnd -eq $f.hwnd }
    if ($ancora) { return ("Ho chiesto la chiusura di '" + $f.titolo + "' ma e' ancora aperta: forse ha un salvataggio in sospeso.") }
    return ('Chiuso: ' + $f.titolo)
}

function Show-FinestraStato {
    param([string]$Filtro, [int]$Comando)
    if (-not (Initialize-PcControllo)) { return 'Non sono su Windows.' }
    $f = Find-Finestra $Filtro
    if (-not $f) { return 'Finestra non trovata.' }
    try { [void][ZapWin32]::ShowWindow([IntPtr]$f.hwnd, $Comando) } catch { return 'Comando non riuscito.' }
    return ('Fatto su: ' + $f.titolo)
}

function Focus-Finestra {
    param([string]$Filtro)
    if (-not (Initialize-PcControllo)) { return $false }
    $f = Find-Finestra $Filtro
    if (-not $f) { return $false }
    try { [void][ZapWin32]::SetForegroundWindow([IntPtr]$f.hwnd); Start-Sleep -Milliseconds 350 } catch { }
    return $true
}

function Resolve-StartAppId {
    param([string]$Nome)
    try {
        $apps = @(Get-StartApps)
        if (-not $apps -or $apps.Count -eq 0) { return $null }
        $n = ([string]$Nome).Trim().ToLower()
        foreach ($a in $apps) { if ([string]$a.Name.ToLower() -eq $n) { return [string]$a.AppID } }
        foreach ($a in $apps) { if ([string]$a.Name.ToLower().StartsWith($n)) { return [string]$a.AppID } }
        foreach ($a in $apps) { if ([string]$a.Name.ToLower().Contains($n)) { return [string]$a.AppID } }
    } catch { }
    return $null
}

function Start-Programma {
    param($sync, [string]$Nome, [string]$Percorso)
    $target = [string]$Percorso
    if (-not $target) {
        if ($sync) {
            $p = Resolve-ProgrammaDaNome $sync $Nome
            if ($p) {
                $cmd = Get-ProgrammaComando $p.percorso
                try {
                    Start-Process -FilePath $cmd.file -ArgumentList $cmd.argomenti -WorkingDirectory (Split-Path -Parent $p.percorso)
                    return ("Avviato: " + $p.nome)
                } catch { return ("Errore nell'avvio di " + $p.nome + ": " + $_.Exception.Message) }
            }
        }
        $noti = Get-AppNoti
        $k = ([string]$Nome).Trim().ToLower()
        if ($noti.Contains($k)) { $target = [string]$noti[$k] }
        else { $target = $Nome }
    }
    if (-not $target) { return 'Non so cosa avviare.' }
    try {
        if ($target -match '^(?i)https?://') { return (Open-UrlInBrowser $sync $target) }
        if ($target -match '^ms-settings:')   { Start-Process $target; return 'Aperto Impostazioni.' }
        if ($target -match '\.exe$' -or $target -match '^(?i)(notepad|calc|mspaint|explorer|cmd|powershell|wt|taskmgr|control|winword|excel|powerpnt|outlook|code|chrome|msedge|firefox|thorium|browser)$') {
            Start-Process $target
            return ("Avviato: " + $target)
        }
        $aumid = Resolve-StartAppId $Nome
        if ($aumid) { Start-Process ('shell:AppsFolder\' + $aumid); return ("Avviato: " + $Nome + " (app di Windows)") }
        Start-Process $target
        return ("Avviato: " + $target)
    } catch { return ("Non riesco ad avviare '" + $target + "': " + $_.Exception.Message) }
}

function Send-TestoAttivo {
    param([string]$Testo)
    if (-not $Testo) { return 'Non c''e'' testo da scrivere.' }
    try { Set-Clipboard -Value $Testo } catch { return 'Non riesco a usare gli appunti.' }
    Wait-Umano 200 400
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        [System.Windows.Forms.SendKeys]::SendWait('^v')
        return ('Scritto: ' + $Testo)
    } catch { return 'Non riesco a inviare la digitazione.' }
}

function Invoke-ComandoDiretto {
    param($sync, [string]$Testo)
    $cmd = Resolve-ComandoDiretto $sync $Testo
    if (-not $cmd.Azione) { return @{ Ok = $false; Gestito = $false; Messaggio = '' } }

    switch ($cmd.Azione) {
        'chiudi_finestra'     { return @{ Ok = $true; Gestito = $true; Messaggio = (Close-Finestra $cmd.Filtro); Azione = $cmd.Azione } }
        'minimizza_finestra'  { return @{ Ok = $true; Gestito = $true; Messaggio = (Show-FinestraStato $cmd.Filtro 6); Azione = $cmd.Azione } }
        'massimizza_finestra' { return @{ Ok = $true; Gestito = $true; Messaggio = (Show-FinestraStato $cmd.Filtro 3); Azione = $cmd.Azione } }
        'elenca_finestre'     { return @{ Ok = $true; Gestito = $true; Messaggio = (Format-Finestre); Azione = $cmd.Azione } }
        'elenca_programmi'    { return @{ Ok = $true; Gestito = $true; Messaggio = (Format-ProgrammiElenco $sync); Azione = $cmd.Azione } }
        'apri_programma'      { Wait-Umano; return @{ Ok = $true; Gestito = $true; Messaggio = (Start-Programma $sync $cmd.Nome ''); Azione = $cmd.Azione } }
        'lancia_programma'    { Wait-Umano; return @{ Ok = $true; Gestito = $true; Messaggio = (Start-Programma $sync $cmd.Nome ''); Azione = $cmd.Azione } }
        'apri_sito'           { Wait-Umano; return @{ Ok = $true; Gestito = $true; Messaggio = (Open-UrlInBrowser $sync $cmd.Url); Azione = $cmd.Azione } }
        'cerca'               { Wait-Umano; return @{ Ok = $true; Gestito = $true; Messaggio = (Invoke-WebSearch $sync $cmd.Query $true); Azione = $cmd.Azione } }
        'scrivi_testo'        { return @{ Ok = $true; Gestito = $true; Messaggio = (Send-TestoAttivo $cmd.Testo); Azione = $cmd.Azione } }
        'whatsapp'            { return (Invoke-WhatsApp $sync $cmd.Destinatario $cmd.Messaggio) }
    }
    return @{ Ok = $false; Gestito = $false; Messaggio = '' }
}

function Invoke-WhatsApp {
    # WhatsApp Web in un browser REALE e gia' loggato. Il messaggio NON parte da solo:
    # la conferma finale resta all'utente (rispetto dei termini d'uso, nessun anti-bot forzato).
    param($sync, [string]$Destinatario, [string]$Messaggio)
    $dest = [string]$Destinatario
    $msg  = [string]$Messaggio
    if (-not $msg) { $msg = '' }

    $soloNumero = ($dest -match '^\+?[0-9\s\-]{6,20}$')
    if ($soloNumero) {
        $n = ($dest -replace '[^0-9]', '')
        $url = 'https://web.whatsapp.com/send?phone=' + $n
        if ($msg) { $url += '&text=' + [System.Uri]::EscapeDataString($msg) }
        [void](Open-UrlInBrowser $sync $url)
        return @{ Ok = $true; Gestito = $true; Azione = 'whatsapp'; Messaggio = ("Ho aperto la chat di WhatsApp con +$n" + $(if ($msg) { ' e ho preparato il messaggio' } else { '' }) + ". Controlla e premi tu Invio per inviare.") }
    }

    [void](Open-UrlInBrowser $sync 'https://web.whatsapp.com')
    Start-Sleep -Seconds 3
    [void](Focus-Finestra 'whatsapp')
    Wait-Umano 400 800
    if ($msg) { try { Set-Clipboard -Value $msg } catch { } }
    $testo = "Ho aperto WhatsApp Web.`n"
    if ($msg) { $testo += "Il messaggio e' negli APPUNTI: cerca '$dest' nella barra di ricerca e premi Ctrl+V per incollarlo.`n" }
    else     { $testo += "Cerca '$dest' nella barra di ricerca di WhatsApp.`n" }
    $testo += 'Poi premi tu Invio: l''invio lo confermi sempre tu.'
    return @{ Ok = $true; Gestito = $true; Azione = 'whatsapp'; Messaggio = $testo }
}
