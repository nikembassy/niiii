﻿# provider_ai.ps1 -- Registro dei servizi IA + router per tipo di lavoro (v6).
# Le chiavi restano SOLO in config.json (sezione provider_ai). Non finiscono mai nei log.
# Non servono moduli esterni: si usa Invoke-RestMethod e il serializzatore di brain\llm.ps1.

function Get-ProviderRegistry {
    # Endpoint ufficiali. Per i servizi "openai" l'URL completo e' <base>/chat/completions.
    # Il modello NON e' precompilato di proposito: i nomi cambiano spesso e un nome
    # inventato romperebbe la chiamata. Lo scrive l'utente nel pannello.
    return @(
        @{ id='gemini';     nome='Google Gemini';       tipo='gemini';    base='https://generativelanguage.googleapis.com'; endpoint='https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'; auth='x-goog-api-key'; keyurl='https://aistudio.google.com/app/apikey'; compiti=@('visione','ricerca','codice','testo','veloce') },
        @{ id='openai';     nome='OpenAI (ChatGPT)';    tipo='openai';    base='https://api.openai.com/v1'; endpoint='https://api.openai.com/v1/chat/completions'; auth='bearer'; keyurl='https://platform.openai.com/api-keys'; compiti=@('visione','codice','testo','veloce') },
        @{ id='anthropic';  nome='Anthropic (Claude)';  tipo='anthropic'; base='https://api.anthropic.com/v1'; endpoint='https://api.anthropic.com/v1/messages'; auth='x-api-key'; keyurl='https://console.anthropic.com/settings/keys'; compiti=@('codice','testo') },
        @{ id='qwen';       nome='Alibaba Qwen';        tipo='openai';    base='https://dashscope-intl.aliyuncs.com/compatible-mode/v1'; endpoint='https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions'; auth='bearer'; keyurl='https://modelstudio.console.alibabacloud.com/'; compiti=@('codice','testo') },
        @{ id='ollama';     nome='Ollama (sul tuo PC)'; tipo='openai';    base='http://localhost:11434/v1'; endpoint='http://localhost:11434/v1/chat/completions'; auth='nessuna'; keyurl='https://ollama.com/download'; compiti=@('testo','codice','veloce') },
        @{ id='openrouter'; nome='OpenRouter';          tipo='openai';    base='https://openrouter.ai/api/v1'; endpoint='https://openrouter.ai/api/v1/chat/completions'; auth='bearer'; keyurl='https://openrouter.ai/keys'; compiti=@('visione','codice','testo') },
        @{ id='groq';       nome='Groq';                tipo='openai';    base='https://api.groq.com/openai/v1'; endpoint='https://api.groq.com/openai/v1/chat/completions'; auth='bearer'; keyurl='https://console.groq.com/keys'; compiti=@('testo','codice','veloce') },
        @{ id='mistral';    nome='Mistral';             tipo='openai';    base='https://api.mistral.ai/v1'; endpoint='https://api.mistral.ai/v1/chat/completions'; auth='bearer'; keyurl='https://console.mistral.ai/api-keys'; compiti=@('codice','testo') },
        @{ id='deepseek';   nome='DeepSeek';            tipo='openai';    base='https://api.deepseek.com/v1'; endpoint='https://api.deepseek.com/v1/chat/completions'; auth='bearer'; keyurl='https://platform.deepseek.com/api_keys'; compiti=@('codice','testo') },
        @{ id='xai';        nome='xAI Grok';            tipo='openai';    base='https://api.x.ai/v1'; endpoint='https://api.x.ai/v1/chat/completions'; auth='bearer'; keyurl='https://console.x.ai'; compiti=@('testo','codice') },
        @{ id='together';   nome='Together AI';         tipo='openai';    base='https://api.together.xyz/v1'; endpoint='https://api.together.xyz/v1/chat/completions'; auth='bearer'; keyurl='https://api.together.ai/settings/api-keys'; compiti=@('codice','testo') },
        @{ id='perplexity'; nome='Perplexity';          tipo='openai';    base='https://api.perplexity.ai'; endpoint='https://api.perplexity.ai/chat/completions'; auth='bearer'; keyurl='https://www.perplexity.ai/settings/api'; compiti=@('ricerca','testo') },
        @{ id='cerebras';   nome='Cerebras';            tipo='openai';    base='https://api.cerebras.ai/v1'; endpoint='https://api.cerebras.ai/v1/chat/completions'; auth='bearer'; keyurl='https://cloud.cerebras.ai'; compiti=@('testo','veloce') },
        @{ id='fireworks';  nome='Fireworks AI';        tipo='openai';    base='https://api.fireworks.ai/inference/v1'; endpoint='https://api.fireworks.ai/inference/v1/chat/completions'; auth='bearer'; keyurl='https://fireworks.ai/account/api-keys'; compiti=@('codice','testo') }
    )
}

function Get-ProviderById {
    param([string]$Id)
    if (-not $Id) { return $null }
    $k = $Id.Trim().ToLower()
    foreach ($r in Get-ProviderRegistry) { if ([string]$r.id -eq $k) { return $r } }
    return $null
}

function Get-DefaultProviderAi {
    $h = @{}
    foreach ($r in Get-ProviderRegistry) {
        $h[[string]$r.id] = @{ chiave = ''; endpoint = [string]$r.endpoint; modello = ''; compiti = @($r.compiti); abilitato = $true }
    }
    return $h
}

function Get-CfgValue {
    # Legge una proprieta' sia da una hashtable sia da un oggetto di ConvertFrom-Json.
    param($Obj, [string]$Name)
    if ($null -eq $Obj) { return $null }
    if ($Obj -is [System.Collections.IDictionary]) { if ($Obj.Contains($Name)) { return $Obj[$Name] } ; return $null }
    return $Obj.$Name
}

function Get-ProviderConfig {
    param($sync, [string]$Id)
    $r = Get-ProviderById $Id
    if (-not $r) { return $null }

    $stored = $null
    try { $stored = Get-CfgValue $sync.Config.provider_ai ([string]$r.id) } catch { }

    $chiave    = [string](Get-CfgValue $stored 'chiave')
    $modello   = [string](Get-CfgValue $stored 'modello')
    $endpoint  = [string](Get-CfgValue $stored 'endpoint')
    $abilitato = Get-CfgValue $stored 'abilitato'
    $compiti   = @(Get-CfgValue $stored 'compiti')

    $legacy = ''
    try { $legacy = [string]$sync.Config.provider } catch { }

    # Retrocompatibilita': il vecchio blocco piatto (provider/api_base/api_key/modello)
    # resta valido per il servizio scelto storicamente.
    if ([string]$r.id -eq 'gemini') {
        if (-not $chiave)  { $chiave  = [string]$sync.Config.api_key }
        if (-not $modello) { $modello = [string]$sync.Config.modello }
    } elseif ($legacy -and ([string]$r.id -eq $legacy)) {
        if (-not $chiave)  { $chiave  = [string]$sync.Config.api_key }
        if (-not $modello) { $modello = [string]$sync.Config.modello }
        if (-not $endpoint -and $sync.Config.api_base) {
            $endpoint = ($sync.Config.api_base.TrimEnd('/')) + '/chat/completions'
        }
    }
    if (-not $endpoint) { $endpoint = [string]$r.endpoint }
    if ($compiti.Count -eq 0) { $compiti = @($r.compiti) }
    if ($null -eq $abilitato) { $abilitato = $true }

    $priorita = Get-CfgValue $stored 'priorita'
    if ($null -eq $priorita) { $priorita = Get-CfgValue $r 'priorita' }
    if ($null -eq $priorita) { $priorita = 20 }

    return @{
        id = [string]$r.id; nome = [string]$r.nome; tipo = [string]$r.tipo; base = [string]$r.base
        endpoint = $endpoint; modello = $modello; chiave = $chiave; auth = [string]$r.auth
        compiti = $compiti; abilitato = [bool]$abilitato; keyurl = [string]$r.keyurl
        priorita = [int]$priorita
    }
}

$script:OllamaUpCache = $null
$script:OllamaUpQuando = [datetime]::MinValue

function Test-OllamaUp {
    # Il modello LOCALE (Llama via Ollama) e' pronto solo se il programma Ollama e' davvero
    # in ascolto su questo PC. La risposta resta in cache 30 secondi per non rallentare.
    try {
        if ($script:OllamaUpCache -ne $null -and (((Get-Date) - $script:OllamaUpQuando).TotalSeconds -lt 10)) {
            return [bool]$script:OllamaUpCache
        }
    } catch { }
    $up = $false
    try {
        $cl = New-Object System.Net.Sockets.TcpClient
        $iar = $cl.BeginConnect('127.0.0.1', 11434, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne(1500)) { $cl.EndConnect($iar); $up = $true }
        $cl.Close()
    } catch { $up = $false }
    $script:OllamaUpCache = $up
    $script:OllamaUpQuando = Get-Date
    return $up
}

function Test-ProviderReady {
    param($sync, [string]$Id)
    $c = Get-ProviderConfig $sync $Id
    if (-not $c) { return $false }
    if ($c.abilitato -eq $false) { return $false }
    if (-not (([string]$c.modello).Trim())) { return $false }
    if (([string]$c.auth) -ne 'nessuna' -and -not (([string]$c.chiave).Trim())) { return $false }
    # v6.5: il servizio locale (Ollama/Llama) e' pronto solo se il programma e' acceso
    if ([string]$c.id -eq 'ollama') { return (Test-OllamaUp) }
    return $true
}

function Get-ProviderAlternativo {
    # Primo servizio pronto diverso da $Escludi. Serve a non bloccare la chat quando
    # il servizio scelto e' a quota esaurita (429) o sovraccarico (503).
    param($sync, [string]$Escludi)
    foreach ($r in Get-ProviderRegistry) {
        $id = [string]$r.id
        if ($id -eq $Escludi) { continue }
        if ($id -eq 'ollama') { continue }
        if (Test-ProviderReady $sync $id) { return (Get-ProviderConfig $sync $id) }
    }
    return $null
}

function Get-AiPronti {
    param($sync)
    $out = @()
    foreach ($r in Get-ProviderRegistry) { if (Test-ProviderReady $sync ([string]$r.id)) { $out += [string]$r.id } }
    return $out
}

function Get-UltimoTestoUtente {
    param([array]$Messages)
    if (-not $Messages) { return '' }
    for ($i = $Messages.Count - 1; $i -ge 0; $i--) {
        $m = $Messages[$i]
        if ([string]$m.role -eq 'user') {
            if ($m.content -is [string]) { return [string]$m.content }
            try { return [string]($m.content | Out-String) } catch { return '' }
        }
    }
    return ''
}

function Get-AiTaskType {
    # Classifica il lavoro per scegliere il servizio giusto.
    param([string]$Testo)
    $t = ''
    if ($Testo) { $t = $Testo.ToLower() }
    if ($t -match 'foto|immagine|schermo|screenshot|vedi|guarda|visione|screen|descrivi quel che vedi') { return 'visione' }
    if ($t -match 'cerca|cercami|ricerca|su internet|sul web|google|notizie|ultim') { return 'ricerca' }
    if ($t -match 'codice|script|programma|funzione|errore|debug|compila|powershell|python|sql') { return 'codice' }
    if ($t.Length -gt 600) { return 'testo' }
    return 'veloce'
}

function Resolve-AiProvider {
    # Restituisce il servizio da usare: quello fissato a mano (se pronto) oppure il
    # primo pronto che sa fare questo tipo di lavoro. $null se nessuno e' pronto.
    param($sync, [string]$TaskType = 'veloce')
    $mod = 'auto'
    try { if ($sync.Config.modalita_ai) { $mod = ([string]$sync.Config.modalita_ai).Trim().ToLower() } } catch { }
    if ($mod -and $mod -ne 'auto') {
        if (Test-ProviderReady $sync $mod) { return (Get-ProviderConfig $sync $mod) }
    }
    # v6.5: domande semplici/veloci -> modello LOCALE (Llama via Ollama) se e' acceso;
    # visione, ricerca e codice restano sul cloud (Gemini). Cosi' "dipende dalla domanda".
    if ($TaskType -eq 'veloce') {
        if (Test-ProviderReady $sync 'ollama') { return (Get-ProviderConfig $sync 'ollama') }
    }
    # v7.10: among ready providers prefer the one with the highest "priorita"
    # (config.json -> provider_ai.<id>.priorita), so code/text can go to Claude
    # instead of always stopping at the first provider in the list.
    $candidati = @()
    foreach ($r in Get-ProviderRegistry) {
        if (-not (Test-ProviderReady $sync ([string]$r.id))) { continue }
        $candidati += (Get-ProviderConfig $sync ([string]$r.id))
    }
    $candidati = @($candidati | Sort-Object -Property @{ Expression = { [int]$_.priorita } } -Descending)
    foreach ($t in @($TaskType, 'testo', 'veloce')) {
        foreach ($c in $candidati) {
            if (@($c.compiti) -contains $t) { return $c }
        }
    }
    if ($candidati.Count -gt 0) { return $candidati[0] }
    return $null
}

function Get-ProviderStato {
    param($sync, [string]$Id)
    $c = Get-ProviderConfig $sync $Id
    if (-not $c) { return ('servizio sconosciuto: ' + $Id) }
    $pronto = Test-ProviderReady $sync $Id
    $manca = @()
    if (-not (([string]$c.modello).Trim())) { $manca += 'modello' }
    if (([string]$c.auth) -ne 'nessuna' -and -not (([string]$c.chiave).Trim())) { $manca += 'chiave' }
    $extra = ''
    if ($manca.Count -gt 0) { $extra = ' (manca: ' + ($manca -join ', ') + ')' }
    $mod = '(vuoto)'
    if (([string]$c.modello).Trim()) { $mod = [string]$c.modello }
    return ([string]$c.nome + ' [' + $(if ($pronto) { 'PRONTO' } else { 'non pronto' }) + ']' + $extra + ' - modello: ' + $mod)
}

function Get-AiRouterText {
    param($sync)
    $righe = @()
    $mod = 'auto'
    try { if ($sync.Config.modalita_ai) { $mod = [string]$sync.Config.modalita_ai } } catch { }
    $righe += ('INTELLIGENZE AI - modalita: ' + $mod)
    $pronti = @(Get-AiPronti $sync)
    if ($pronti.Count -eq 0) {
        $righe += 'Nessun servizio pronto: apri INTELLIGENZE AI e incolla almeno una chiave + un modello.'
    } else {
        $righe += ('Servizi pronti (' + $pronti.Count + '): ' + ($pronti -join ', '))
    }
    foreach ($r in Get-ProviderRegistry) {
        $c = Get-ProviderConfig $sync ([string]$r.id)
        $p = Test-ProviderReady $sync ([string]$r.id)
        $segno = '[ ]'
        if ($p) { $segno = '[X]' }
        $righe += ('  ' + $segno + ' ' + [string]$c.nome + ' - lavori: ' + (@($c.compiti) -join ', '))
    }
    $oll = 'non attivo (installa Ollama e fai: ollama pull llama3.1)'
    if (Test-OllamaUp) { $oll = 'ATTIVO su questo PC' }
    $righe += ('Modello locale (Llama via Ollama): ' + $oll + ' - le domande semplici vanno in locale, il resto in cloud.')
    $righe += 'Comandi: /ai auto (scelta automatica), /ai stato, /ai <servizio> (es. /ai openai).'
    return ($righe -join "`n")
}
