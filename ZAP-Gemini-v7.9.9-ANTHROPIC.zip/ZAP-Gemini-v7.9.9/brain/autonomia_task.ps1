﻿# ============================================================================
#  autonomia_task.ps1  --  ZAP 7.0/7.1 : autonomia nel tempo (task pianificati)
# ----------------------------------------------------------------------------
#  ZAP esegue compiti ANCHE A FINESTRA CHIUSA, tramite il Task Scheduler di Windows.
#  Tipi: 'orario'/'settimanale'/'intervallo'/'una_volta'/'cartella'.
#  Ogni task ha uno 'script' PowerShell (deterministico, eseguito dal ponte) e/o
#  una 'azione' in linguaggio naturale (accodata per l'agente ZAP).
# ============================================================================

function Get-DatiDir {
    param([string]$base)
    $d = Join-Path $base 'dati'
    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
    return $d
}
function Get-TaskStorePath { param([string]$base) return (Join-Path (Get-DatiDir $base) 'tasks.json') }
function Get-TaskStore {
    param([string]$base)
    $p = Get-TaskStorePath $base
    if (-not (Test-Path -LiteralPath $p)) { return @() }
    try { return @((Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json)) } catch { return @() }
}
function Save-TaskStore { param([string]$base, $tasks) (ConvertTo-Json -InputObject @($tasks) -Depth 8) | Set-Content -LiteralPath (Get-TaskStorePath $base) -Encoding UTF8 }

function New-EseguiTaskScript {
    # Crea/aggiorna il "ponte" eseguito dal Task Scheduler. Notifica in basso a destra.
    param([string]$base)
    $runner = Join-Path $base 'ESEGUI_TASK.ps1'
    $contenuto = @'
# ESEGUI_TASK.ps1 -- eseguito da Windows Task Scheduler per conto di ZAP. Non modificare.
param([Parameter(Mandatory=$true)][string]$TaskId)
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$logDir = Join-Path $base 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
$log = Join-Path $logDir 'automazioni.log'
$dati = Join-Path $base 'dati'
if (-not (Test-Path $dati)) { New-Item -ItemType Directory -Force -Path $dati | Out-Null }
$stamp = (Get-Date).ToString('s')

function ZapNotifica {
    param([string]$Titolo, [string]$Messaggio)
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
        $ni = New-Object System.Windows.Forms.NotifyIcon
        $ni.Icon = [System.Drawing.SystemIcons]::Information
        $ni.Visible = $true
        $ni.BalloonTipTitle = [string]$Titolo
        $ni.BalloonTipText  = [string]$Messaggio
        $ni.ShowBalloonTip(8000)
        Start-Sleep -Seconds 6
        $ni.Dispose()
    } catch { }
}

function ZapCartella {
    param([string]$nome)
    switch ([string]$nome) {
        'Desktop'   { return [Environment]::GetFolderPath('Desktop') }
        'Documenti' { return [Environment]::GetFolderPath('MyDocuments') }
        'Immagini'  { return [Environment]::GetFolderPath('MyPictures') }
        'Video'     { return [Environment]::GetFolderPath('MyVideos') }
        'Musica'    { return [Environment]::GetFolderPath('MyMusic') }
        'Download'  { return (Join-Path $env:USERPROFILE 'Downloads') }
        default     { return (Join-Path $env:USERPROFILE ([string]$nome)) }
    }
}

function ZapBackup {
    param([string]$nome)
    $src = ZapCartella $nome
    if (-not $src -or -not (Test-Path -LiteralPath $src)) { return ('Cartella ' + $nome + ' non trovata') }
    $dst = Join-Path $env:USERPROFILE ('ZAP_Backup\' + $nome + '_' + (Get-Date -Format 'yyyy-MM-dd'))
    New-Item -ItemType Directory -Force -Path $dst | Out-Null
    Copy-Item -LiteralPath (Join-Path $src '*') -Destination $dst -Recurse -Force -ErrorAction SilentlyContinue
    return ('Backup di ' + $nome + ' completato in ' + $dst)
}

function ZapAccoda {
    param([string]$Testo)
    $coda = Join-Path $base 'dati\task_in_coda.json'
    $arr = @()
    if (Test-Path -LiteralPath $coda) { try { $arr = @(Get-Content -LiteralPath $coda -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { $arr = @() } }
    $arr += [pscustomobject]@{ quando = $stamp; testo = $Testo }
    (ConvertTo-Json -InputObject @($arr) -Depth 5) | Set-Content -LiteralPath $coda -Encoding UTF8
}

try {
    $store = @(Get-Content -LiteralPath (Join-Path $base 'dati\tasks.json') -Raw -Encoding UTF8 | ConvertFrom-Json)
    $t = $store | Where-Object { $_.id -eq $TaskId } | Select-Object -First 1
    if (-not $t) { return }
    Add-Content -LiteralPath $log -Value "[$stamp] avvio: $($t.nome)"
    $esito = ''
    if ($t.script) {
        try { $esito = [string](Invoke-Expression ([string]$t.script)) }
        catch { $esito = 'errore: ' + $_.Exception.Message }
    }
    elseif ($t.azione) {
        ZapAccoda ([string]$t.azione)
        $esito = 'accodato per ZAP (verra eseguito all avvio)'
    }
    if (-not $esito) { $esito = 'fatto' }
    Add-Content -LiteralPath $log -Value "[$stamp] esito: $esito"
    ZapNotifica ('ZAP - ' + $t.nome) $esito
}
catch {
    Add-Content -LiteralPath $log -Value "[$stamp] ERRORE: $($_.Exception.Message)"
}
'@
    Set-Content -LiteralPath $runner -Value $contenuto -Encoding UTF8
    return $runner
}

function New-TaskWrapper {
    param([string]$base, [string]$id)
    $cmd = Join-Path $base ("ESEGUI_TASK_{0}.cmd" -f $id)
    $righe = ("@echo off`r`n" +
              "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"%~dp0ESEGUI_TASK.ps1`" -TaskId $id >> `"%~dp0logs\automazioni.log`" 2>&1`r`n")
    Set-Content -LiteralPath $cmd -Value $righe -Encoding ASCII
    return $cmd
}

function Register-WinTask {
    param([string]$base, [string]$id, [string]$tipo, [string]$quando, [string]$orario)
    [void](New-EseguiTaskScript $base)
    $cmd = New-TaskWrapper $base $id
    $tn  = "ZAP\$id"
    if (-not $orario) { $orario = '09:00' }
    switch ($tipo) {
        'orario'      { schtasks /Create /TN $tn /TR "`"$cmd`"" /SC DAILY   /ST $orario /F | Out-Null }
        'settimanale' { if (-not $quando) { $quando = 'SUN' }; schtasks /Create /TN $tn /TR "`"$cmd`"" /SC WEEKLY /D $quando /ST $orario /F | Out-Null }
        'intervallo'  { $m = [int]$quando; if ($m -lt 1) { $m = 15 }; schtasks /Create /TN $tn /TR "`"$cmd`"" /SC MINUTE /MO $m /F | Out-Null }
        'una_volta'   { schtasks /Create /TN $tn /TR "`"$cmd`"" /SC ONCE /ST $orario /SD $quando /F | Out-Null }
    }
}
function Remove-WinTask { param([string]$id) schtasks /Delete /TN "ZAP\$id" /F 2>$null | Out-Null }

function Test-TriggerCartelle {
    param([string]$base)
    $store = @(Get-TaskStore $base)
    $scatti = @()
    foreach ($t in ($store | Where-Object { $_.tipo -eq 'cartella' -and $_.attivo })) {
        $cart = [string]$t.quando
        if (-not (Test-Path -LiteralPath $cart)) { continue }
        $file = @(Get-ChildItem -LiteralPath $cart -File -ErrorAction SilentlyContinue)
        $firma = ($file | Sort-Object Name | ForEach-Object { "$($_.Name):$($_.Length):$($_.LastWriteTimeUtc.Ticks)" }) -join '|'
        if ($firma -ne [string]$t.firma) { $scatti += $t; $t.firma = $firma }
    }
    if ($scatti.Count -gt 0) { Save-TaskStore $base $store }
    return @($scatti)
}

# ------------------------------- TOOLS -------------------------------------

function Tool-PianificaTask {
    param([string]$base, [string]$nome, [string]$tipo, [string]$quando, [string]$azione, [string]$orario, [string]$script)
    if (-not $azione -and -not $script) { return "Serve cosa deve fare ZAP (azione o script)." }
    $tipo = ([string]$tipo).Trim().ToLower()
    if ($tipo -notin @('orario','settimanale','intervallo','una_volta','cartella')) { $tipo = 'orario' }
    if (-not $orario) { $orario = '09:00' }
    if (-not $nome)   { $nome = ("Task " + (Get-Date).ToString('HHmmss')) }
    $id = 'task_' + (Get-Date).ToString('yyyyMMdd_HHmmss')
    $task = [pscustomobject]@{
        id = $id; nome = $nome; tipo = $tipo; quando = [string]$quando; orario = [string]$orario
        azione = [string]$azione; script = [string]$script
        creato = (Get-Date).ToString('s'); attivo = $true; firma = ''
    }
    $store = @(Get-TaskStore $base); $store += $task; Save-TaskStore $base $store
    if ($tipo -in @('orario','settimanale','intervallo','una_volta')) {
        Register-WinTask -base $base -id $id -tipo $tipo -quando ([string]$quando) -orario ([string]$orario)
        return "programmato ($tipo $quando $orario) - id=$id"
    }
    return "trigger su cartella creato (id=$id)"
}

function Tool-ListaTask {
    param([string]$base)
    $store = @(Get-TaskStore $base)
    if ($store.Count -eq 0) { return "Nessun task pianificato." }
    $righe = foreach ($t in $store) { "  - [$($t.id)] $($t.nome) | $($t.tipo) $($t.quando) $($t.orario)" }
    return "Task pianificati ($($store.Count)):`n" + ($righe -join "`n")
}

function Tool-AnnullaTask {
    param([string]$base, [string]$id)
    if (-not $id) { return "Serve l'id del task (vedi lista_task)." }
    $store = @(Get-TaskStore $base | Where-Object { $_.id -ne $id })
    Save-TaskStore $base $store
    Remove-WinTask $id
    return "Task '$id' annullato."
}
