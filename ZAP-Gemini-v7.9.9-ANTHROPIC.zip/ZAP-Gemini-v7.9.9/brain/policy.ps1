# policy.ps1 -- PERMESSI GRANULARI: cosa ZAP puo' fare, per tipo di azione e per percorso.
# Analizza il comando (AST PowerShell) e confronta VERBI (leggi/scrivi/cancella) e PERCORSI
# con le regole. Esito: consenti | chiedi | blocca.
# Limite dichiarato (onesta'): resta un filtro "nel codice". Codice costruito a runtime puo'
# aggirarlo. Per una garanzia ASSOLUTA serve un utente Windows a privilegi limitati che esegua
# i comandi al posto di ZAP (passo successivo).
#
# v7.9.7 HARDENING (da review di sicurezza) -- chiude alcuni bypass noti:
#   1) ALIAS: 'rm' e 'ri' (alias di Remove-Item) non erano riconosciuti -> ora normalizzati.
#   2) METODI .NET: [IO.File]::Delete/WriteAllText/ecc. non erano visti -> ora contano come scrivi/cancella.
#   3) PERCORSO NON STATICO (fail-closed): scrittura/cancellazione con percorso in VARIABILE
#      ("$p = "$env:WINDIR\x"; Remove-Item $p") non e' verificabile -> ora diventa 'chiedi', non 'consenti'.
#   4) COMANDI DINAMICI: Invoke-Expression / Add-Type / Start-Process / cmd / powershell / mshta /
#      rundll32 / -EncodedCommand / FromBase64String -> ora 'chiedi' (costruzione di codice a runtime).
#   5) PERCORSI: espansione di %VAR% e $env:VAR, normalizzazione di .. e \. -> meno falsi negativi.
#   6) LINK: New-Item -ItemType SymbolicLink|Junction|HardLink e mklink trattati come scrittura.
#   Restano possibili bypass via COM/reflection/PSRemoting: per quelli servono i passi 1-2 della
#   tabella del rapporto (utente limitato + EDR/AppLocker).

function Get-PolicyDefault {
    $prot = @()
    try { if ($env:WINDIR)        { $prot += (([string]$env:WINDIR).TrimEnd('\')) } } catch { }
    try { if ($env:ProgramFiles)  { $prot += (([string]$env:ProgramFiles).TrimEnd('\')) } } catch { }
    try { $x86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)'); if ($x86) { $prot += (([string]$x86).TrimEnd('\')) } } catch { }
    return @{
        attivo = $true
        cartelle_consentite = @()
        cartelle_protette   = $prot
        conferma_eliminazione = $true
        conferma_scritture_esterne = $true
        blocca_percorso_non_statico = $true    # v7.9.7: fail-closed sulle scritture non verificabili
    }
}

function Expand-PolicyPath {
    # [PURA] Espande %VAR% e $env:VAR noti e normalizza .. e \. (best effort, senza toccare il FS).
    param([string]$Percorso)
    $p = ([string]$Percorso).Trim().Trim('"', "'")
    if (-not $p) { return '' }
    foreach ($nome in @('WINDIR','SystemRoot','ProgramFiles','ProgramData','LOCALAPPDATA','APPDATA','USERPROFILE','PUBLIC','TEMP','TMP','SystemDrive')) {
        $val = ''; try { $val = [Environment]::GetEnvironmentVariable($nome) } catch { }
        if ($val) {
            $p = $p -replace ('(?i)%' + [regex]::Escape($nome) + '%'), $val
            $p = $p -replace ('(?i)\$env:' + [regex]::Escape($nome)), $val
        }
    }
    $p = $p.Replace('/', '\').TrimEnd('\')
    while ($p -match '\\[^\\]+\\\.\.\\') { $p = $p -replace '\\[^\\]+\\\.\.\\', '\' }
    $p = $p -replace '\\\.\\', '\'
    return $p
}

function Test-PercorsoInLista {
    param([string]$Percorso, $Lista)
    $p = (Expand-PolicyPath $Percorso).ToLower()
    if (-not $p) { return $false }
    foreach ($c in @($Lista)) {
        $cc = (Expand-PolicyPath ([string]$c)).ToLower()
        if (-not $cc) { continue }
        if ($p -eq $cc -or $p.StartsWith($cc + '\')) { return $true }
    }
    return $false
}

function Get-PolicyVerbi {
    return @{
        elimina = @('remove-item','del','erase','rd','rm','ri','rmdir','clear-content','remove-itemproperty','clear-recyclebin','format-volume','clear-disk','initialize-disk')
        scrivi  = @('set-content','add-content','out-file','new-item','copy-item','move-item','rename-item','set-item','set-itemproperty','new-itemproperty','export-csv','export-clixml','set-acl','icacls','attrib','takeown','robocopy','xcopy','mkdir','md','ni','sc','ac','tee-object','mklink')
        rete    = @('invoke-webrequest','invoke-restmethod','start-bitstransfer','curl','wget','bitsadmin','ftp','scp','sftp','ssh')
    }
}

function Get-PolicyAliasMap {
    return @{
        'rm'='remove-item'; 'ri'='remove-item'; 'del'='remove-item'; 'erase'='remove-item'; 'rd'='remove-item'; 'rmdir'='remove-item'
        'ni'='new-item'; 'ac'='add-content'; 'sc'='set-content'
        'cp'='copy-item'; 'cpi'='copy-item'; 'mv'='move-item'; 'mi'='move-item'; 'ren'='rename-item'; 'rni'='rename-item'
        'iwr'='invoke-webrequest'; 'irm'='invoke-restmethod'; 'curl'='invoke-webrequest'; 'wget'='invoke-webrequest'
        'iex'='invoke-expression'
    }
}

function Get-PolicySospetti {
    # Comandi in grado di costruire o eseguire codice a runtime: non li blocco (troppi usi legittimi),
    # ma li faccio sempre confermare.
    return @('invoke-expression','iex','add-type','start-process','cmd','cmd.exe','powershell','powershell.exe','pwsh','pwsh.exe','mshta','rundll32','regsvr32','wmic','start-job','invoke-command','cscript','wscript')
}

function Get-PolicyMetodiFile {
    return @{
        elimina = @('delete','deletedirectory')
        scrivi  = @('writealltext','writeallbytes','writealllines','appendalltext','appendalllines','createdirectory','moveto','copyto','replace')
    }
}

function Test-PolicyComando {
    param($sync, [string]$Code)
    $esito = @{ Verdetto = 'consenti'; Motivo = ''; PercorsiScrittura = @(); PercorsiEliminazione = @(); Comandi = @() }
    if (-not $Code) { return $esito }
    # v7.9.8: MODALITA' HACKER -- la policy non blocca (difesa in profondita': l'audit resta attivo).
    try { if (Get-Command Test-ModalitaHacker -ErrorAction SilentlyContinue) { if (Test-ModalitaHacker $sync) { $esito.Motivo = 'modalita hacker: policy disattivata (audit attivo)'; return $esito } } } catch { }
    $pol = $null
    try { $pol = $sync.Config.policy } catch { }
    if ($null -eq $pol) { try { $pol = Get-PolicyDefault } catch { } }
    $attivo = $true
    try { if ($pol.attivo -ne $null) { $attivo = [bool]$pol.attivo } } catch { }
    if (-not $attivo) { return $esito }

    $verbi = Get-PolicyVerbi
    $cmds = @(); $strs = @(); $redirs = @(); $metodi = @()
    try {
        $tok = $null; $err = $null
        $ast = [System.Management.Automation.Language.Parser]::ParseInput($Code, [ref]$tok, [ref]$err)
        $pC = [System.Func[System.Management.Automation.Language.Ast, bool]]{ param($n) $n -is [System.Management.Automation.Language.CommandAst] }
        foreach ($c in $ast.FindAll($pC, $true)) { $n = ''; try { $n = [string]$c.GetCommandName() } catch { } ; if ($n) { $cmds += $n.ToLower() } }
        $pS = [System.Func[System.Management.Automation.Language.Ast, bool]]{ param($n) $n -is [System.Management.Automation.Language.StringConstantExpressionAst] }
        foreach ($s in $ast.FindAll($pS, $true)) { $strs += [string]$s.Value }
        $pR = [System.Func[System.Management.Automation.Language.Ast, bool]]{ param($n) $n -is [System.Management.Automation.Language.FileRedirectionAst] }
        foreach ($r in $ast.FindAll($pR, $true)) { try { $redirs += [string]$r.Location } catch { } }
        # v7.9.7: metodi .NET invocati (es. [IO.File]::Delete(...))
        $pM = [System.Func[System.Management.Automation.Language.Ast, bool]]{ param($n) $n -is [System.Management.Automation.Language.InvokeMemberExpressionAst] }
        foreach ($m in $ast.FindAll($pM, $true)) { $mn = ''; try { $mn = [string]$m.Member.Value } catch { }; if ($mn) { $metodi += $mn.ToLower() } }
    } catch { }

    # v7.9.7: normalizza gli alias ai cmdlet reali
    $alias = Get-PolicyAliasMap
    $cmdsNorm = @()
    foreach ($c in $cmds) { if ($alias.ContainsKey($c)) { $cmdsNorm += $alias[$c] } else { $cmdsNorm += $c } }
    $esito.Comandi = $cmdsNorm

    $faElimina = $false; $faScrive = $false
    foreach ($c in $cmdsNorm) {
        if ($verbi.elimina -contains $c) { $faElimina = $true }
        elseif ($verbi.scrivi -contains $c) { $faScrive = $true }
    }
    $mm = Get-PolicyMetodiFile
    foreach ($m in $metodi) {
        if ($mm.elimina -contains $m) { $faElimina = $true }
        elseif ($mm.scrivi -contains $m) { $faScrive = $true }
    }
    if (@($redirs).Count -gt 0) { $faScrive = $true }
    # v7.9.7: creazione di link/junction/hardlink trattata come scrittura
    if (@($cmdsNorm) -contains 'mklink') { $faScrive = $true }
    try { if ((@($cmdsNorm) -contains 'new-item') -and ((([string]($strs -join ' ')).ToLower()) -match 'symboliclink|junction|hardlink')) { $faScrive = $true } } catch { }

    # v7.9.7: comando dinamico/sospetto?
    $sospetti = Get-PolicySospetti
    $usaSospetto = $false
    foreach ($c in $cmdsNorm) { if ($sospetti -contains $c) { $usaSospetto = $true } }
    if (-not $usaSospetto) {
        foreach ($s in $strs) {
            $sl = ([string]$s).ToLower()
            if ($sl -match 'frombase64string' -or $sl -match '(?<![a-z0-9])-e(nc(odedcommand)?)?\b') { $usaSospetto = $true }
        }
    }

    $percorsi = @()
    foreach ($s in $strs) {
        $v = ([string]$s).Trim()
        if (-not $v) { continue }
        if ($v -match '^[A-Za-z]:\\' -or $v -match '^\\\\' -or $v -match '^/' -or $v -match '^%[A-Za-z_]+%' -or $v -match '^\$env:') { $percorsi += $v }
    }
    foreach ($r in @($redirs)) { $percorsi += ([string]$r).Trim() }

    $consentite = @($pol.cartelle_consentite); $protette = @($pol.cartelle_protette)
    $failClosed = $true
    try { if ($pol.blocca_percorso_non_statico -eq $false) { $failClosed = $false } } catch { }

    if ($faScrive -or $faElimina) {
        foreach ($p in $percorsi) {
            if (Test-PercorsoInLista $p $protette) {
                $esito.Verdetto = 'blocca'
                $esito.Motivo = ('scrittura/cancellazione in una cartella di sistema (' + $p + ')')
                return $esito
            }
        }
    }
    if ($faElimina) {
        $esito.PercorsiEliminazione = $percorsi
        try { if ($pol.conferma_eliminazione -ne $false) { $esito.Verdetto = 'chiedi'; $esito.Motivo = 'cancellazione di file/cartelle' } } catch { }
    }
    if ($faScrive) {
        $inConsentite = @($percorsi | Where-Object { Test-PercorsoInLista $_ $consentite })
        foreach ($p in $percorsi) {
            if (Test-PercorsoInLista $p $consentite) { continue }
            $esito.PercorsiScrittura += $p
            try {
                if ($pol.conferma_scritture_esterne -ne $false) {
                    if ($esito.Verdetto -ne 'blocca') { $esito.Verdetto = 'chiedi'; $esito.Motivo = ('scrittura fuori dalle cartelle consentite (' + $p + ')') }
                }
            } catch { }
        }
    }

    # v7.9.7 -- FAIL-CLOSED: scrittura/cancellazione senza percorsi riconoscibili (percorso in variabile).
    if (($faScrive -or $faElimina) -and @($percorsi).Count -eq 0 -and $esito.Verdetto -ne 'blocca') {
        if ($failClosed) {
            $esito.Verdetto = 'chiedi'
            $esito.Motivo = 'scrittura/cancellazione con percorso NON statico (variabile/espressione): non verificabile, richiedo conferma'
        }
    }

    # v7.9.7 -- comando dinamico: chiedo sempre conferma.
    if ($usaSospetto -and $esito.Verdetto -ne 'blocca') {
        $esito.Verdetto = 'chiedi'
        if (-not $esito.Motivo) { $esito.Motivo = 'comando che puo'' costruire/eseguire codice a runtime' }
    }

    return $esito
}

function Format-PolicyInfo {
    param($sync)
    $pol = $null
    try { $pol = $sync.Config.policy } catch { }
    if ($null -eq $pol) { try { $pol = Get-PolicyDefault } catch { } }
    $attivo = $true
    try { if ($pol.attivo -ne $null) { $attivo = [bool]$pol.attivo } } catch { }
    $cons = @($pol.cartelle_consentite); $prot = @($pol.cartelle_protette)
    $canc = 'si'; try { if ($pol.conferma_eliminazione -eq $false) { $canc = 'no' } } catch { }
    $scrt = 'si'; try { if ($pol.conferma_scritture_esterne -eq $false) { $scrt = 'no' } } catch { }
    $out = @()
    $out += 'PERMESSI GRANULARI (ruoli/regole)'
    $out += ('  stato: ' + $(if ($attivo) { 'ATTIVO' } else { 'disattivato' }))
    $out += ('  scrittura LIBERA in: ' + $(if ($cons.Count) { ($cons -join ' | ') } else { '(nessuna: ogni scrittura viene confermata)' }))
    $out += ('  PROTETTE (mai scrivere/cancellare): ' + $(if ($prot.Count) { ($prot -join ' | ') } else { '(nessuna)' }))
    $out += ('  conferma cancellazioni: ' + $canc + '   |   conferma scritture esterne: ' + $scrt)
    $out += '  comandi: /policy consenti <cartella>  |  /policy protetta <cartella>  |  /policy on|off'
    return ($out -join "`n")
}
