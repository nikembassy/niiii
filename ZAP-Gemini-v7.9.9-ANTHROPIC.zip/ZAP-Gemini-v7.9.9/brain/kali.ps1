﻿# ============================================================================
#  kali.ps1  --  ZAP 7.9.9 : console e strumenti Kali Linux (via WSL)
# ----------------------------------------------------------------------------
#  Kali NON si puo' emulare "davvero" in PowerShell puro. Il modo corretto su
#  Windows e' WSL2 con la distro UFFICIALE Kali. ZAP (PowerShell) la pilota:
#  console stile Kali + catalogo strumenti con stato e installazione.
#  Se Kali non c'e', la console ripiega su PowerShell.
#
#  IMPORTANTE (v7.3): ogni chiamata a wsl.exe ha un TIMEOUT reale (non si blocca
#  mai) e il controllo dei tool usa UNA SOLA chiamata. La UI chiama queste
#  funzioni da un runspace in BACKGROUND, cosi' la finestra resta reattiva.
#
#  IMPORTANTE (v7.9.9): l'installazione di Kali richiede i permessi di
#  AMMINISTRATORE (Windows chiede il consenso UAC). Tutta la logica vive nel
#  file..\installa_kali.ps1, che si eleva da solo: qui lo richiamiamo e ne
#  leggiamo l'esito (logs\kali_install.stato + logs\kali_install.log).
#
#  AVVISO D'USO: strumenti dual-use. Usali SOLO su sistemi TUOI o per cui hai
#  autorizzazione scritta a eseguire test. Nessuna automazione d'attacco inclusa.
# ============================================================================

function Invoke-WslArgs {
    # Esegue wsl.exe con argomenti grezzi e TIMEOUT reale. Ritorna @{ ok; out }.
    param([string]$argomenti, [int]$timeoutSec = 8)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'wsl.exe'
    $psi.Arguments = $argomenti
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow  = $true
    try { $p = [System.Diagnostics.Process]::Start($psi) } catch { return @{ ok = $false; out = '' } }
    $ot = $p.StandardOutput.ReadToEndAsync()
    $et = $p.StandardError.ReadToEndAsync()
    if (-not $ot.Wait([int]($timeoutSec * 1000))) { try { $p.Kill() } catch { }; return @{ ok = $false; out = 'timeout wsl' } }
    [void]$p.WaitForExit(500)
    return @{ ok = $true; out = (([string]$ot.Result + [string]$et.Result) -replace "`0", '') }
}

function Get-WslLista {
    $r = Invoke-WslArgs '-l -q' 6
    if (-not $r.ok) { return @() }
    return @($r.out -split "\r?\n" | ForEach-Object { ($_ -replace [char]0, '').Trim() } | Where-Object { $_ })
}

function Get-KaliDistro {
    param([switch]$Ricalcola)
    if ($script:ZapKaliDistro -and -not $Ricalcola) { return $script:ZapKaliDistro }
    $k = @(Get-WslLista | Where-Object { $_ -match 'kali' })
    if ($k.Count -gt 0) { $script:ZapKaliDistro = $k[0].Trim() } else { $script:ZapKaliDistro = '' }
    return $script:ZapKaliDistro
}

function Test-KaliPronto {
    $d = Get-KaliDistro
    if (-not $d) { return $false }
    $r = Invoke-WslArgs ("-d `"$d`" -- bash -lc `"echo ZAPOK`"") 20
    return ($r.ok -and ($r.out -match 'ZAPOK'))
}

function Invoke-KaliRaw {
    param([string]$comando, [int]$timeoutSec = 120, [switch]$ComeRoot)
    $d = Get-KaliDistro
    if (-not $d) { return @{ ok = $false; out = 'Kali non installato (nessuna distro WSL con nome kali).' } }
    $esc = ([string]$comando) -replace '"', '\"'
    if ($ComeRoot) { $argsStr = "-d `"$d`" -u root -- bash -lc `"$esc`"" }
    else           { $argsStr = "-d `"$d`" -- bash -lc `"$esc`"" }
    return (Invoke-WslArgs $argsStr $timeoutSec)
}

function Invoke-PsConsole {
    param([string]$comando, [int]$timeoutSec = 60)
    try { $r = (& powershell.exe -NoProfile -Command ([string]$comando) 2>&1) | Out-String; return @{ ok = $true; out = $r } }
    catch { return @{ ok = $false; out = $_.Exception.Message } }
}

function Invoke-KaliCommand {
    # Se Kali c'e' esegue DENTRO Kali; altrimenti ripiega su PowerShell.
    param([string]$comando, [int]$timeoutSec = 120)
    if (Test-KaliPronto) { return (Invoke-KaliRaw $comando $timeoutSec) }
    return (Invoke-PsConsole $comando $timeoutSec)
}

function Get-KaliTools {
    return @(
        @{ id='nmap';         nome='Nmap';                 pkg='nmap';                 bin='nmap';         desc='Scansione di rete e porte' },
        @{ id='wireshark';    nome='Wireshark/tshark';     pkg='tshark';               bin='tshark';       desc='Analisi del traffico' },
        @{ id='metasploit';   nome='Metasploit';           pkg='metasploit-framework'; bin='msfconsole';   desc='Framework di exploit (pentest)' },
        @{ id='sqlmap';       nome='sqlmap';               pkg='sqlmap';               bin='sqlmap';       desc='Test di injection SQL' },
        @{ id='hydra';        nome='Hydra';                pkg='hydra';                bin='hydra';        desc='Test robustezza login (audit)' },
        @{ id='john';         nome='John the Ripper';      pkg='john';                 bin='john';         desc='Recupero password (audit)' },
        @{ id='hashcat';      nome='hashcat';              pkg='hashcat';              bin='hashcat';      desc='Recupero password (audit)' },
        @{ id='aircrack';     nome='Aircrack-ng';          pkg='aircrack-ng';          bin='aircrack-ng';  desc='Audit di reti Wi-Fi' },
        @{ id='nikto';        nome='Nikto';                pkg='nikto';                bin='nikto';        desc='Scansione vulnerabilita web' },
        @{ id='gobuster';     nome='Gobuster';             pkg='gobuster';             bin='gobuster';     desc='Ricerca directory/URL nascosti' },
        @{ id='theharvester'; nome='theHarvester';         pkg='theharvester';         bin='theHarvester'; desc='Raccolta informazioni OSINT' },
        @{ id='netcat';       nome='Netcat (nc)';          pkg='netcat-traditional';   bin='nc';           desc='Connessioni TCP/UDP' },
        @{ id='responder';    nome='Responder';            pkg='responder';            bin='responder';    desc='Analisi reti Windows (lab)' },
        @{ id='burp';         nome='Burp Suite Community'; pkg='burpsuite';            bin='burpsuite';    desc='Proxy per test web' },
        @{ id='dirb';         nome='DIRB';                 pkg='dirb';                 bin='dirb';         desc='Scansione contenuti web' }
    )
}

function Get-KaliToolById { param([string]$id) return @(Get-KaliTools | Where-Object { $_.id -eq $id })[0] }

function Get-KaliToolsStato {
    $kali = Test-KaliPronto
    if ($kali) {
        # UNA SOLA chiamata a wsl: controlla tutti i binari insieme.
        $binari = ((Get-KaliTools | ForEach-Object { $_.bin }) -join ' ')
        $cmd = 'for b in ' + $binari + '; do if command -v "$b" >/dev/null 2>&1; then echo "OK:$b"; else echo "NO:$b"; fi; done'
        $r = Invoke-KaliRaw $cmd 40
        $trovati = @{}
        if ($r.ok) {
            foreach ($ln in ($r.out -split "\r?\n")) {
                if ($ln -match '^OK:(.+)$') { $trovati[$Matches[1].Trim()] = $true }
            }
        }
        $out = New-Object System.Collections.ArrayList
        foreach ($t in (Get-KaliTools)) {
            $inst = $trovati.ContainsKey($t.bin)
            [void]$out.Add([pscustomobject]@{ id = $t.id; nome = $t.nome; pkg = $t.pkg; desc = $t.desc; installato = [bool]$inst })
        }
        return $out
    }
    $out2 = New-Object System.Collections.ArrayList
    foreach ($t in (Get-KaliTools)) {
        $inst = $false
        try { $inst = [bool](Get-Command $t.bin -ErrorAction SilentlyContinue) } catch { $inst = $false }
        [void]$out2.Add([pscustomobject]@{ id = $t.id; nome = $t.nome; pkg = $t.pkg; desc = $t.desc; installato = [bool]$inst })
    }
    return $out2
}

# ---------------------------------------------------------------------------
#  v7.9.9: INSTALLAZIONE DI KALI  (richiede AMMINISTRATORE / consenso UAC)
# ---------------------------------------------------------------------------

function Test-AdminKali {
    try {
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object System.Security.Principal.WindowsPrincipal($id)
        return [bool]$pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Get-KaliInstaller {
    $root = Split-Path -Parent $PSScriptRoot
    $cand = Join-Path $root 'installa_kali.ps1'
    if (Test-Path $cand) { return $cand }
    return ''
}

function Installa-KaliDistro {
    # Richiama il vero installer (installa_kali.ps1), che si eleva da solo con
    # il consenso UAC di Windows. Poi riporta esito + coda del log.
    $installer = Get-KaliInstaller
    if (-not $installer) {
        return ('Manca il file installa_kali.ps1 accanto ad AVVIA.ps1: non posso installare Kali ' +
                'automaticamente. Usa INSTALLA_KALI.bat nella cartella dell app, oppure apri PowerShell ' +
                'come amministratore ed esegui: wsl --install -d kali-linux')
    }
    $root  = Split-Path -Parent $installer
    $log   = Join-Path $root 'logs\kali_install.log'
    $stato = Join-Path $root 'logs\kali_install.stato'
    try { if (Test-Path $stato) { Remove-Item -LiteralPath $stato -Force -ErrorAction SilentlyContinue } } catch { }

    # Avvia l'installer in una FINESTRA VISIBILE (cosi' l'utente vede il lavoro).
    # Prova elevato (RunAs); se non possibile, ripiega senza elevazione:
    # installa_kali.ps1 si eleva comunque da solo.
    $argInst = @('-NoProfile','-ExecutionPolicy','Bypass','-File', ('"' + $installer + '"'))
    try {
        $p = Start-Process -FilePath 'powershell.exe' -Verb RunAs -Wait -PassThru -ArgumentList $argInst
    } catch {
        try {
            $p = Start-Process -FilePath 'powershell.exe' -Wait -PassThru -ArgumentList $argInst
        } catch {
            return ('Installazione non riuscita: ' + $_.Exception.Message)
        }
    }

    $msg = 'Installazione Kali conclusa.'
    if (Test-Path $stato) {
        try {
            $s = [string](Get-Content -LiteralPath $stato -Raw -ErrorAction SilentlyContinue)
            if ($s) {
                $pezzi = $s.Split('|', 2)
                $cod = $pezzi[0].Trim()
                $det = ''
                if ($pezzi.Count -gt 1) { $det = $pezzi[1] }
                switch ($cod) {
                    'OK'     { $msg = 'KALI INSTALLATO con successo. ' + $det }
                    'REBOOT' { $msg = 'RIAVVIO NECESSARIO. ' + $det }
                    'ERRORE' { $msg = 'ERRORE di installazione. ' + $det }
                    'AVVIO'  { $msg = 'Installazione in corso... ' + $det }
                    default  { $msg = $s }
                }
            }
        } catch { }
    }
    if (Test-Path $log) {
        try {
            $t = @(Get-Content -LiteralPath $log -Tail 20 -ErrorAction SilentlyContinue)
            if ($t.Count -gt 0) { $msg += "`n--- log installazione ---`n" + ($t -join "`n") }
        } catch { }
    }
    if (Test-KaliPronto) { $msg += "`nKali e pronto: la console ora gira DENTRO Kali Linux." }
    return $msg
}

function Installa-KaliTool {
    param([string]$id)
    $t = Get-KaliToolById $id
    if (-not $t) { return ("Strumento '" + $id + "' sconosciuto.") }
    if (-not (Test-KaliPronto)) { return 'Kali non e installato: premi prima INSTALLA KALI.' }
    [void](Invoke-KaliRaw 'apt-get update' 600 -ComeRoot)
    $r = Invoke-KaliRaw ('DEBIAN_FRONTEND=noninteractive apt-get install -y ' + $t.pkg) 1800 -ComeRoot
    if ($r.ok) { return ($t.nome + ': installazione completata.') }
    return ($t.nome + ': errore -> ' + $r.out)
}

# ---------------------------- TOOLS per l'agente ---------------------------

function Tool-KaliEsegui {
    param([string]$comando, [int]$timeoutSec = 120)
    if (-not $comando) { return "Serve un comando da eseguire." }
    $r = Invoke-KaliCommand $comando $timeoutSec
    $amb = 'PowerShell'; if (Test-KaliPronto) { $amb = 'Kali (WSL)' }
    return ('[' + $amb + '] $ ' + $comando + "`n" + [string]$r.out)
}

function Tool-KaliStato {
    $kali = 'no'; if (Test-KaliPronto) { $kali = 'si' }
    $righe = foreach ($t in (Get-KaliToolsStato)) {
        $s = 'NON installato'; if ($t.installato) { $s = 'installato' }
        '  - ' + $t.id + ': ' + $t.nome + ' [' + $s + ']'
    }
    return ('Kali pronto: ' + $kali + "`nStrumenti:`n" + ($righe -join "`n"))
}

function Tool-KaliInstallaTool { param([string]$id) return (Installa-KaliTool $id) }
