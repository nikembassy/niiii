﻿# AVVIA.ps1 — ZAP! Assistente Desktop (grafica AURA oro/argento, upload foto/video/PDF) — v6.3
# Avvio:  powershell -ExecutionPolicy Bypass -File .\AVVIA.ps1
# Funziona con Windows PowerShell 5.1 (viene rilanciato automaticamente da pwsh 7).
[CmdletBinding()]
param(
    [switch]$NoVoice,
    [switch]$Admin
)

# --- Su pwsh (PowerShell 7) rilancia con Windows PowerShell 5.1 in STA (serve per WPF + voce) ---
if ($PSVersionTable.PSEdition -eq 'Core') {
    $psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $psExe)) { $psExe = 'powershell.exe' }
    $argList = @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath)
    if ($NoVoice) { $argList += '-NoVoice' }
    if ($Admin) { $argList += '-Admin' }
    Start-Process $psExe -ArgumentList $argList
    return
}

# --- se qualcosa va storto, MOSTRALO (finestra + logs\errore.log) ---
trap {
    $testo = ($_ | Out-String)
    try {
        $logDir = Join-Path $PSScriptRoot 'logs'
        if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
        Add-Content -Path (Join-Path $logDir 'errore.log') -Value ((Get-Date -Format 'o') + [Environment]::NewLine + $testo) -Encoding UTF8
    } catch { }
    Write-Host $testo -ForegroundColor Red
    try { [System.Windows.MessageBox]::Show($testo, 'ZAP - errore', 'OK', 'Error') | Out-Null } catch { }
    exit 1
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Speech

$base = $PSScriptRoot
foreach ($d in 'logs', 'memory', 'skills', 'brain', 'voice', 'ui', 'ui\avatar', 'programmi', 'appunti') {
    $p = Join-Path $base $d
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null }
}

# v5: i moduli nuovi vengono caricati SUBITO (servono anche a Get-DefaultConfig)
foreach ($__m in @('brain\log.ps1', 'brain\audit.ps1', 'brain\policy.ps1', 'brain\sandbox.ps1', 'brain\pentest.ps1', 'brain\provider_ai.ps1', 'brain\tema.ps1', 'brain\tema_foto.ps1', 'brain\modalita.ps1', 'brain\autonomia.ps1', 'brain\programmi.ps1', 'brain\pc_controllo.ps1', 'brain\osint.ps1', 'brain\mini_agenti.ps1')) {
    $__p = Join-Path $base $__m
    if (Test-Path $__p) { . $__p }
}

# v5: traccia delle fasi di avvio. Se ZAP non parte, logs\avvio.log dice FIN DOVE e' arrivato.
function Write-Fase {
    param([string]$Testo)
    try {
        $d = Join-Path $base 'logs'
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
        Add-Content -Path (Join-Path $d 'avvio.log') -Value ((Get-Date -Format 'HH:mm:ss') + '  [avvio] ' + $Testo) -Encoding UTF8
    } catch { }
    Write-Host ('[ZAP avvio] ' + $Testo)
}
Write-Fase '1/6 moduli caricati'

# --------------------------------------------------------------------------
# v6.5 -- Motore della palette: applica dal vivo i colori/il carattere scelti
# --------------------------------------------------------------------------
function ConvertTo-Colore {
    param([string]$Hex)
    try {
        $h = ([string]$Hex).Trim().TrimStart('#')
        if ($h.Length -eq 3) { $h = ($h[0] + $h[0] + $h[1] + $h[1] + $h[2] + $h[2]) }
        if ($h.Length -eq 6) { $h = 'FF' + $h }
        return [System.Windows.Media.Color]::FromArgb(
            [Convert]::ToByte($h.Substring(0,2),16), [Convert]::ToByte($h.Substring(2,2),16),
            [Convert]::ToByte($h.Substring(4,2),16), [Convert]::ToByte($h.Substring(6,2),16))
    } catch { return [System.Windows.Media.Colors]::Gray }
}

function ConvertTo-HexNorm {
    param([string]$h)
    $h = ([string]$h).Trim()
    if (-not $h.StartsWith('#')) { $h = '#' + $h }
    if ($h.Length -eq 7) { $h = '#FF' + $h.Substring(1) }
    return $h.ToUpper()
}

function New-PaletteMappa {
    param($vecchia, $nuova)
    $m = @{}
    foreach ($k in @($vecchia.Keys)) {
        if ($k -eq 'font' -or $k -eq 'fontSize' -or $k -eq 'preset' -or $k -eq 'sfondoImmagine') { continue }
        $o = ConvertTo-HexNorm $vecchia[$k]
        $n = ConvertTo-HexNorm $nuova[$k]
        if ($o -and $n -and ($o -ne $n)) { $m[$o] = $n }
    }
    return $m
}

function Send-Palette {
    param($el, $mappa, [double]$ratio)
    if ($null -eq $el) { return }
    foreach ($prop in @('Background','Foreground','BorderBrush','Fill','Stroke','CaretBrush','SelectionBrush')) {
        try {
            $v = $el.$prop
            if ($v -is [System.Windows.Media.SolidColorBrush]) {
                $key = '#FF' + $v.Color.ToString().Substring(2)
                if ($mappa.ContainsKey($key)) {
                    $nb = New-Object System.Windows.Media.SolidColorBrush((ConvertTo-Colore $mappa[$key]))
                    $nb.Freeze()
                    $el.$prop = $nb
                }
            }
        } catch { }
    }
    if ($ratio -ne 1.0) {
        try { $fs = [double]$el.FontSize; if ($fs -gt 0) { $el.FontSize = [Math]::Round($fs * $ratio, 1) } } catch { }
    }
    try {
        if ($el -is [System.Windows.Controls.Panel]) { foreach ($c in $el.Children) { Send-Palette $c $mappa $ratio } }
        elseif ($el -is [System.Windows.Controls.Decorator]) { Send-Palette $el.Child $mappa $ratio }
        elseif ($el -is [System.Windows.Controls.ContentControl]) { if ($el.Content -is [System.Windows.UIElement]) { Send-Palette $el.Content $mappa $ratio } }
    } catch { }
}

function Applica-Palette {
    param($sync, $radice, $nuova)
    if (-not $radice -or -not $nuova) { return }
    $vecchia = $null
    try { $vecchia = $sync.PaletteCorr } catch { }
    if (-not $vecchia) { $vecchia = Get-PaletteDefault }
    $mappa = New-PaletteMappa $vecchia $nuova
    $ratio = 1.0
    try {
        $of = [double]$vecchia.fontSize; $nf = [double]$nuova.fontSize
        if ($of -gt 0 -and $nf -gt 0) { $ratio = $nf / $of }
    } catch { }
    Send-Palette $radice $mappa $ratio
    try { $radice.FontFamily = [System.Windows.Media.FontFamily]::new([string]$nuova.font) } catch { }
    try { $sync.Palette = $nuova; $sync.PaletteCorr = $nuova } catch { }
}

# --------------------------------------------------------------------------
# v7.9.3 -- SFONDO DALLA FOTO: usa una tua foto come sfondo del pannello sinistro
# (con un velo scuro, cosi' logo e avatar restano leggibili). Senza foto: torna
# allo sfondo normale a puntini.
# --------------------------------------------------------------------------
function Asp-ApplicaSfondo {
    param($sync, [string]$Percorso)
    if (-not $PannelloSinistro) { return }
    if ($Percorso -and (Test-Path $Percorso)) {
        try {
            $bi = New-Object System.Windows.Media.Imaging.BitmapImage
            $bi.BeginInit()
            $bi.CacheOption = 'OnLoad'
            $bi.UriSource  = New-Object System.Uri($Percorso)
            $bi.EndInit()
            $bi.Freeze()
            $br = New-Object System.Windows.Media.ImageBrush($bi)
            $br.Stretch = 'UniformToFill'
            $br.Opacity = 0.55
            $br.Freeze()
            $PannelloSinistro.Background = $br
            return
        } catch { }
    }
    try {
        $orig = $Window.FindResource('Halftone')
        if ($orig) { $PannelloSinistro.Background = $orig }
    } catch { }
}

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

function Get-DefaultConfig {
    return @{
        nome      = 'ZAP'
        api_base  = ''
        api_key   = ''
        modello   = 'gemini-3.1-flash-lite'
        provider  = 'gemini'
        gemini_model_fallbacks = @('gemini-3.6-flash', 'gemini-flash-lite-latest')
        modalita_ai = 'auto'
        provider_ai = (Get-DefaultProviderAi)
        sicurezza = 'smart'
        browser   = 'yandex'
        browser_fallbacks = @('yandex', 'thorium')
        motore_ricerca = 'duckduckgo'
        tema      = 'oro'
        browser_paths = @{}
        cartella_lavoro = ''
        timeout_powershell_sec = 30
        # v7.9.4
        simulazione = $false
        audit     = $true
        policy    = (Get-PolicyDefault)
        sandbox   = (Get-SandboxDefault)
        pentest   = (Get-PentestDefault)
        osint     = (Get-OsintDefault)
        miniagenti = (Get-MiniAgentiDefault)
        hacker    = (Get-HackerDefault)
        voce = @{
            risposte_ad_alta_voce = $true
            ascolto_lingua  = 'it-IT'
            ascolto_secondi = 6
            velocita = 1
            volume   = 100
            telecomando = $true
        }
        programmi     = (Get-DefaultProgrammiConfig)
    }
}

function Write-Utf8NoBom {
    # Scrive SEMPRE UTF-8 senza BOM (Windows PowerShell 5.1 con -Encoding UTF8 lo aggiungerebbe,
    # e il BOM in testa a config.json faceva fallire ConvertFrom-Json su altri lettori).
    param([string]$Path, [string]$Testo)
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Testo, $enc)
}

function Split-ConfigSegreti {
    # Divide la configurazione in: parte pubblica (va in config.json) e parte segreta
    # (va SOLO in config.local.json, che .gitignore ignora).
    param($Config)
    $copia = @{}
    foreach ($k in @($Config.Keys)) { $copia[$k] = $Config[$k] }
    $copia['api_key'] = ''
    $paPub = @{}
    $paSeg = @{}
    foreach ($k in @($Config.provider_ai.Keys)) {
        $blk = $Config.provider_ai[$k]
        $pub = @{}
        foreach ($f in @($blk.Keys)) { if ($f -ne 'chiave') { $pub[$f] = $blk[$f] } }
        $pub['chiave'] = ''
        $paPub[$k] = $pub
        if (([string]$blk['chiave']).Trim()) { $paSeg[$k] = @{ chiave = [string]$blk['chiave'] } }
    }
    $copia['provider_ai'] = $paPub
    return @{ Pubblica = $copia; Segreti = $paSeg }
}

function Save-Config {
    param($sync)
    try {
        $d = Split-ConfigSegreti $sync.Config
        Write-Utf8NoBom $sync.CfgPath (($d.Pubblica | ConvertTo-Json -Depth 6))
        if ($d.Segreti.Count -gt 0) {
            $lp = Join-Path $sync.Base 'config.local.json'
            Write-Utf8NoBom $lp ((@{ provider_ai = $d.Segreti } | ConvertTo-Json -Depth 6))
        }
    } catch { }
}

$cfgPath = Join-Path $base 'config.json'
$config = Get-DefaultConfig
if (Test-Path $cfgPath) {
    try {
        $loaded = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @('nome','provider','api_base','api_key','modello','gemini_model_fallbacks','sicurezza','browser','browser_fallbacks','motore_ricerca','tema','aspetto','gemini_model_scelto','cartella_lavoro','timeout_powershell_sec','modalita_ai','simulazione','audit','pentest','osint','miniagenti','hacker')) {
            if ($null -ne $loaded.$k) { $config[$k] = $loaded.$k }
        }
        if ($loaded.browser_paths) { $config.browser_paths = $loaded.browser_paths }
        if ($loaded.voce) {
            foreach ($k in @('risposte_ad_alta_voce','ascolto_lingua','ascolto_secondi','velocita','volume','telecomando')) {
                if ($null -ne $loaded.voce.$k) { $config.voce[$k] = $loaded.voce.$k }
            }
        }
        if ($loaded.policy) {
            $pl = Get-PolicyDefault
            foreach ($k in @('attivo','cartelle_consentite','cartelle_protette','conferma_eliminazione','conferma_scritture_esterne')) {
                if ($null -ne $loaded.policy.$k) { $pl[$k] = $loaded.policy.$k }
            }
            $config.policy = $pl
        }
        if ($loaded.sandbox) {
            $sbb = Get-SandboxDefault
            foreach ($k in @('attivo','memoria_mb','cpu_sec','max_processi')) {
                if ($null -ne $loaded.sandbox.$k) { $sbb[$k] = $loaded.sandbox.$k }
            }
            $config.sandbox = $sbb
        }
        if ($loaded.programmi) {
            if ($loaded.programmi.cartella) { $config.programmi.cartella = [string]$loaded.programmi.cartella }
            if ($null -ne $loaded.programmi.voci) { $config.programmi.voci = @($loaded.programmi.voci) }
        }
        if ($loaded.provider_ai) {
            $pa = @{}
            foreach ($p in @($loaded.provider_ai.PSObject.Properties)) {
                $ee = @{}
                foreach ($f in @('chiave','endpoint','modello','abilitato')) {
                    $vv = $p.Value.$f
                    if ($null -ne $vv) { $ee[$f] = $vv }
                }
                if ($p.Value.compiti) { $ee['compiti'] = @($p.Value.compiti) }
                $pa[[string]$p.Name] = $ee
            }
            foreach ($k in @($pa.Keys)) {
                if (-not $config.provider_ai.ContainsKey($k)) { $config.provider_ai[$k] = @{} }
                foreach ($f in @($pa[$k].Keys)) { $config.provider_ai[$k][$f] = $pa[$k][$f] }
            }
        }
    } catch { }
}
$cfgLocalPath = Join-Path $base 'config.local.json'
if (Test-Path $cfgLocalPath) {
    try {
        $loc = Get-Content $cfgLocalPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @('provider','api_base','api_key','modello')) {
            if ($null -ne $loc.$k -and (([string]$loc.$k).Trim())) { $config[$k] = $loc.$k }
        }
        if ($loc.provider_ai) {
            foreach ($p in @($loc.provider_ai.PSObject.Properties)) {
                $id = [string]$p.Name
                if (-not $config.provider_ai.ContainsKey($id)) { continue }
                foreach ($f in @('chiave','endpoint','modello','abilitato')) {
                    $vv = $p.Value.$f
                    if ($null -ne $vv -and (([string]$vv).Trim() -or $f -eq 'abilitato')) { $config.provider_ai[$id][$f] = $vv }
                }
                if ($p.Value.compiti) { $config.provider_ai[$id]['compiti'] = @($p.Value.compiti) }
            }
        }
        Write-Fase '2b/6 segreti locali letti (config.local.json)'
    } catch { Write-Fase '2b/6 config.local.json illeggibile: uso config.json' }
}
if ($NoVoice) { $config.voce.risposte_ad_alta_voce = $false }
# v7.9: AVVIA_ADMIN.bat avvia ZAP NON elevato (per non rompere il trascinamento dei
# file) e mette questo flag: i comandi che richiedono i privilegi vengono rieseguiti
# elevati al momento del bisogno.
$config.admin_su_richiesta = [bool]$Admin
if ((Get-ModalitaSequenza) -notcontains [string]$config.sicurezza) { $config.sicurezza = 'smart' }
Write-Fase '2/6 configurazione letta'

# --------------------------------------------------------------------------
# Stato condiviso (tutti i passaggi tra UI e agente avvengono SOLO via dati)
# --------------------------------------------------------------------------

$sync = [hashtable]::Synchronized(@{})
$sync.Base       = $base
$sync.CfgPath    = $cfgPath
$sync.Config     = $config
$sync.UiQueue    = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
$sync.InputQueue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[string]'
$sync.Quit       = $false
$sync.AvatarState  = 'neutro'
$sync.SpeakingTicks = 0
$sync.Listening  = $false
$sync.CurrentExec  = $null
$sync.Tts          = $null
$sync.Avatars      = @{}
$sync.ListenShell  = $null
$sync.ListenRunspace = $null
$sync.ListenHandle = $null
$sync.ListenStato  = 'spento'
$sync.ListenLivello = 0
$sync.ListenResult = $null
$sync.ListenStop   = $false
$sync.MicAttivo    = $false
$sync.MicEngine    = $null
$sync.MicTesto     = ''
$sync.MicInizio    = (Get-Date)
$sync.MicUltimoSuono = (Get-Date)
$sync.MicTimeout   = 12
$sync.MicSidLevel  = ''
$sync.MicSidDet    = ''
$sync.MicSidRec    = ''
$sync.MicModo      = 'spento'
$sync.MicFase      = ''
$sync.MicOperazione = $null
$sync.MicErrWinRT  = ''
$sync.MicErrLegacy = ''
$sync.AiActive     = $null
$sync.Allegati     = New-Object System.Collections.ArrayList
$sync.ConfirmRequest = $null
$sync.ConfirmResult  = $false
$sync.ConfirmDone    = $null

. (Join-Path $base 'brain\tools.ps1')
. (Join-Path $base 'voice\tts.ps1')
. (Join-Path $base 'voice\stt.ps1')
. (Join-Path $base 'brain\llm.ps1')

# --------------------------------------------------------------------------
# Finestra
# --------------------------------------------------------------------------

# v5: Get-TemaXaml ora vive in brain\tema.ps1, cosi' i test possono verificarla.

$temaAvvio = 'oro'   # grafica unica: scura con accenti oro
$xaml = Get-Content (Join-Path $base 'ui\window.xaml') -Raw -Encoding UTF8
$xaml = Get-TemaXaml $xaml $temaAvvio
try {
    $Window = [Windows.Markup.XamlReader]::Parse($xaml)
} catch {
    Write-Fase ('ERRORE nel caricare l''interfaccia ui\window.xaml: ' + $_.Exception.Message)
    throw
}
Write-Fase '3/6 interfaccia caricata'

$Avatar        = $Window.FindName('Avatar')
$OnomaText     = $Window.FindName('OnomaText')
$StatusText    = $Window.FindName('StatusText')
$ChatScroll    = $Window.FindName('ChatScroll')
$ChatPanel     = $Window.FindName('ChatPanel')
$InputBox      = $Window.FindName('InputBox')
$BtnInvia      = $Window.FindName('BtnInvia')
$BtnParla      = $Window.FindName('BtnParla')
$BtnInsegna    = $Window.FindName('BtnInsegna')
$BtnModo       = $Window.FindName('BtnModo')
$BtnImpostazioni = $Window.FindName('BtnImpostazioni')
$BtnFerma      = $Window.FindName('BtnFerma')
$SettingsPanel = $Window.FindName('SettingsPanel')
$TeachPanel    = $Window.FindName('TeachPanel')
$CfgNome       = $Window.FindName('CfgNome')
$CfgApiBase    = $Window.FindName('CfgApiBase')
$CfgApiKey     = $Window.FindName('CfgApiKey')
$CfgModello    = $Window.FindName('CfgModello')
$CfgBrowser    = $Window.FindName('CfgBrowser')
$CfgMotore     = $Window.FindName('CfgMotore')
$ModelInfo     = $Window.FindName('ModelInfo')
$BtnScaricaModello = $Window.FindName('BtnScaricaModello')
$CfgCartella   = $Window.FindName('CfgCartella')
$CfgVoce       = $Window.FindName('CfgVoce')
$BtnSalvaCfg   = $Window.FindName('BtnSalvaCfg')
$BtnChiudiCfg  = $Window.FindName('BtnChiudiCfg')
$TeachNome     = $Window.FindName('TeachNome')
$TeachQuando   = $Window.FindName('TeachQuando')
$TeachCodice   = $Window.FindName('TeachCodice')
$BtnSalvaTeach = $Window.FindName('BtnSalvaTeach')
$BtnChiudiTeach = $Window.FindName('BtnChiudiTeach')
# --- v5 ---
$BtnProgrammi   = $Window.FindName('BtnProgrammi')
$BtnAppunti     = $Window.FindName('BtnAppunti')
$AppuntiPanel   = $Window.FindName('AppuntiPanel')
$AppuntiBox     = $Window.FindName('AppuntiBox')
$BtnAppuntiSalva = $Window.FindName('BtnAppuntiSalva')
$BtnAppuntiChiudi = $Window.FindName('BtnAppuntiChiudi')
$BtnAspetto     = $Window.FindName('BtnAspetto')
$AspettoPanel   = $Window.FindName('AspettoPanel')
$BtnTemaFoto    = $Window.FindName('BtnTemaFoto')
$PannelloSinistro = $Window.FindName('PannelloSinistro')
$AspSfondo      = $Window.FindName('AspSfondo')
$AspSuperficie  = $Window.FindName('AspSuperficie')
$AspCampo       = $Window.FindName('AspCampo')
$AspPill        = $Window.FindName('AspPill')
$AspAccento     = $Window.FindName('AspAccento')
$AspAccentoChiaro = $Window.FindName('AspAccentoChiaro')
$AspAccentoScuro  = $Window.FindName('AspAccentoScuro')
$AspArgento     = $Window.FindName('AspArgento')
$AspArgentoScuro = $Window.FindName('AspArgentoScuro')
$AspTesto       = $Window.FindName('AspTesto')
$AspTestoSuAccento = $Window.FindName('AspTestoSuAccento')
$AspBordo       = $Window.FindName('AspBordo')
$AspFont        = $Window.FindName('AspFont')
$AspSize        = $Window.FindName('AspSize')
$BtnAspApplica  = $Window.FindName('BtnAspApplica')
$BtnAspRipristina = $Window.FindName('BtnAspRipristina')
$BtnAspChiudi   = $Window.FindName('BtnAspChiudi')
$BtnTemaAura    = $Window.FindName('BtnTemaAura')
$BtnTemaNotte   = $Window.FindName('BtnTemaNotte')
$BtnTemaSmeraldo = $Window.FindName('BtnTemaSmeraldo')
$BtnTemaViola   = $Window.FindName('BtnTemaViola')
$BtnTemaChiaro  = $Window.FindName('BtnTemaChiaro')
$BtnAi          = $Window.FindName('BtnAi')
$AiPanel        = $Window.FindName('AiPanel')
$AiList         = $Window.FindName('AiList')
$AiIntro        = $Window.FindName('AiIntro')
$AiSel          = $Window.FindName('AiSel')
$BtnChiudiAi    = $Window.FindName('BtnChiudiAi')
$BtnAiSalvaTutti = $Window.FindName('BtnAiSalvaTutti')
$BtnAiAiutoChiavi = $Window.FindName('BtnAiAiutoChiavi')
$ProgrammiPanel = $Window.FindName('ProgrammiPanel')
$ProgElenco     = $Window.FindName('ProgElenco')
$ProgCombo      = $Window.FindName('ProgCombo')
$ProgInfo       = $Window.FindName('ProgInfo')
$BtnProgAvvia   = $Window.FindName('BtnProgAvvia')
$BtnProgAggiorna= $Window.FindName('BtnProgAggiorna')
$BtnProgCartella= $Window.FindName('BtnProgCartella')
$BtnChiudiProg  = $Window.FindName('BtnChiudiProg')
$MicLevel       = $Window.FindName('MicLevel')
$MicText        = $Window.FindName('MicText')
# --- upload / allegati ---
$BtnAllegati    = $Window.FindName('BtnAllegati')
$BtnFoto        = $Window.FindName('BtnFoto')
$BtnVideo       = $Window.FindName('BtnVideo')
$AllegatiBar    = $Window.FindName('AllegatiBar')
$AllegatiInfo   = $Window.FindName('AllegatiInfo')
$Trasparenza      = $Window.FindName('Trasparenza')
$TrasparenzaLabel = $Window.FindName('TrasparenzaLabel')
$TitleBarDrag     = $Window.FindName('TitleBarDrag')
$BtnWinMin        = $Window.FindName('BtnWinMin')
$BtnWinMax        = $Window.FindName('BtnWinMax')
$BtnWinClose      = $Window.FindName('BtnWinClose')
$BtnAutomazioni   = $Window.FindName('BtnAutomazioni')
$AutomazioniPanel = $Window.FindName('AutomazioniPanel')
$AutoList         = $Window.FindName('AutoList')
$AutoDescr        = $Window.FindName('AutoDescr')
$BtnAutoCrea      = $Window.FindName('BtnAutoCrea')
$BtnAutoAggiorna  = $Window.FindName('BtnAutoAggiorna')
$BtnAutoChiudi    = $Window.FindName('BtnAutoChiudi')
$BtnKali          = $Window.FindName('BtnKali')
$KaliPanel        = $Window.FindName('KaliPanel')
$KaliStatus       = $Window.FindName('KaliStatus')
$KaliOut          = $Window.FindName('KaliOut')
$KaliCmd          = $Window.FindName('KaliCmd')
$BtnKaliEsegui    = $Window.FindName('BtnKaliEsegui')
$KaliTools        = $Window.FindName('KaliTools')
$BtnKaliInstalla  = $Window.FindName('BtnKaliInstalla')
$BtnKaliSetup     = $Window.FindName('BtnKaliSetup')
$BtnKaliAggiorna  = $Window.FindName('BtnKaliAggiorna')
$BtnKaliChiudi    = $Window.FindName('BtnKaliChiudi')
Write-Fase '4/6 controlli collegati'

# v6.5: palette (tema/colori) salvata dall'utente -> la applico subito alla finestra
$sync.PaletteCorr = Get-PaletteDefault
$sync.Palette     = Merge-Palette $sync.Config.aspetto
try { Applica-Palette $sync $Window $sync.Palette } catch { }
try { Asp-ApplicaSfondo $sync ([string]$sync.Palette.sfondoImmagine) } catch { }

# v6.6: riprendo il modello che ha gia' funzionato -> nessuna caccia ai modelli ad ogni messaggio
try { $sync.ModelloOk = Get-ModelloSalvato $sync } catch { }

$scale = New-Object System.Windows.Media.ScaleTransform
$Avatar.RenderTransform = $scale

# Immagini avatar
$imgMap = @{ neutro = 'robot.png'; parla = 'robot_parla.png'; pensa = 'robot_pensa.png' }
foreach ($k in $imgMap.Keys) {
    $imgPath = Join-Path $base ('ui\avatar\' + $imgMap[$k])
    if (Test-Path $imgPath) {
        try {
            $bi = New-Object System.Windows.Media.Imaging.BitmapImage
            $bi.BeginInit()
            $bi.UriSource = New-Object System.Uri($imgPath)
            $bi.CacheOption = 'OnLoad'
            $bi.EndInit()
            $bi.Freeze()
            $sync.Avatars[$k] = $bi
        } catch { }
    }
}

# --------------------------------------------------------------------------
# Funzioni UI (solo sul thread grafico)
# --------------------------------------------------------------------------

function Set-AvatarState {
    param([string]$State)
    if ($State -eq 'ok') { $State = 'neutro' }
    if (-not $sync.Avatars.ContainsKey($State)) { $State = 'neutro' }
    $sync.AvatarState = $State
    if ($sync.Avatars[$State]) { $Avatar.Source = $sync.Avatars[$State] }

    $da = New-Object System.Windows.Media.Animation.DoubleAnimation
    $da.From = 0.9
    $da.To = 1.0
    $da.Duration = New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(220))
    $scale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleXProperty, $da)
    $scale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleYProperty, $da.Clone())
}

function Add-MenuVoce {
    param($menu, [string]$testo, $comando)
    $mi = New-Object System.Windows.Controls.MenuItem
    $mi.Header = $testo
    $mi.Command = $comando
    [void]$menu.Items.Add($mi)
}

function Set-TextBoxCopyMenu {
    # v6: sulle risposte di ZAP si puo' selezionare e copiare (menu tasto destro).
    param($tb)
    $menu = New-Object System.Windows.Controls.ContextMenu
    Add-MenuVoce $menu 'Copia' ([System.Windows.Input.ApplicationCommands]::Copy)
    Add-MenuVoce $menu 'Seleziona tutto' ([System.Windows.Input.ApplicationCommands]::SelectAll)
    $tb.ContextMenu = $menu
}

function Set-InputTextMenu {
    # v6: copia/incolla espliciti sul campo dove scrivi (oltre a Ctrl+C / Ctrl+V nativi).
    param($tb)
    $menu = New-Object System.Windows.Controls.ContextMenu
    Add-MenuVoce $menu 'Taglia' ([System.Windows.Input.ApplicationCommands]::Cut)
    Add-MenuVoce $menu 'Copia' ([System.Windows.Input.ApplicationCommands]::Copy)
    Add-MenuVoce $menu 'Incolla' ([System.Windows.Input.ApplicationCommands]::Paste)
    Add-MenuVoce $menu 'Seleziona tutto' ([System.Windows.Input.ApplicationCommands]::SelectAll)
    $tb.ContextMenu = $menu
}

$script:LiveBorder = $null
$script:LiveText   = $null

function Get-LiveBubble {
    # Bolla temporanea in cui si scrive il testo mentre arriva (streaming). Viene
    # tolta e sostituita dalla bolla definitiva quando la risposta e' completa.
    param($Pal)
    if ($script:LiveBorder) { return $script:LiveBorder }
    $b = New-Object System.Windows.Controls.Border
    $b.CornerRadius = '14'
    $b.BorderThickness = '1.5'
    $b.BorderBrush = [string]$Pal.accentoScuro
    $b.Background = [string]$Pal.accentoChiaro
    $b.Padding = '12,8,12,8'
    $b.MaxWidth = 640
    $b.HorizontalAlignment = 'Left'
    $b.Margin = '0,6,60,6'
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.TextWrapping = 'Wrap'
    $tb.FontSize = 14
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.Margin = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    $tb.Foreground = [string]$Pal.testoSuAccento
    Set-TextBoxCopyMenu $tb
    $b.Child = $tb
    [void]$ChatPanel.Children.Add($b)
    $script:LiveBorder = $b
    $script:LiveText = $tb
    return $b
}

function Add-LiveBubble {
    param([string]$Text)
    $pal = $sync.Palette
    if (-not $pal) { $pal = Get-PaletteDefault }
    [void](Get-LiveBubble $pal)
    if ($script:LiveText) { $script:LiveText.Text = $Text }
}

function Clear-LiveBubble {
    if ($script:LiveBorder) {
        try { [void]$ChatPanel.Children.Remove($script:LiveBorder) } catch { }
    }
    $script:LiveBorder = $null
    $script:LiveText = $null
}

function Add-Bubble {
    param([string]$Who, [string]$Text)
    if (-not $Text) { return }
    $pal = $sync.Palette
    if (-not $pal) { $pal = Get-PaletteDefault }

    $b = New-Object System.Windows.Controls.Border
    $b.CornerRadius = '14'
    $b.BorderThickness = '1.5'
    $b.BorderBrush = [string]$pal.bordo
    $b.Padding = '12,8,12,8'
    $b.MaxWidth = 640

    # v6: era un TextBlock (non copiabile). Ora e' un campo di testo in sola lettura:
    # si seleziona e si copia (Ctrl+C oppure tasto destro -> Copia).
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = $Text
    $tb.TextWrapping = 'Wrap'
    $tb.FontSize = 14
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.Margin = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    Set-TextBoxCopyMenu $tb

    if ($Who -eq 'utente') {
        # bolla utente: grigio-antracite, testo chiaro (contrasto alto = sempre leggibile)
        $b.Background = [string]$pal.pill
        $b.BorderBrush = [string]$pal.bordo
        $b.HorizontalAlignment = 'Left'
        $b.Margin = '12,6,80,6'
        $tb.Foreground = [string]$pal.testo
        $tb.FontWeight = 'SemiBold'
        $b.Child = $tb
        [void]$ChatPanel.Children.Add($b)
    }
    else {
        # bolla ZAP: ORO con testo SCURO (nero su oro = leggibilita' massima), preceduta dal clown
        $b.Background = [string]$pal.accentoChiaro
        $b.BorderBrush = [string]$pal.accentoScuro
        $b.HorizontalAlignment = 'Left'
        $b.Margin = '0,6,60,6'
        $tb.Foreground = [string]$pal.testoSuAccento
        $b.Child = $tb
        $riga = New-Object System.Windows.Controls.Grid
        $riga.Margin = '0'
        $c0 = New-Object System.Windows.Controls.ColumnDefinition
        $c0.Width = 'Auto'
        $c1 = New-Object System.Windows.Controls.ColumnDefinition
        $c1.Width = '*'
        [void]$riga.ColumnDefinitions.Add($c0)
        [void]$riga.ColumnDefinitions.Add($c1)
        $av = New-Object System.Windows.Controls.Image
        $av.Width = 34
        $av.Height = 34
        $av.Stretch = 'UniformToFill'
        $av.VerticalAlignment = 'Top'
        $av.Margin = '12,6,8,0'
        if ($sync.Avatars -and $sync.Avatars['neutro']) { $av.Source = $sync.Avatars['neutro'] }
        $clip = New-Object System.Windows.Media.EllipseGeometry
        $clip.Center = [System.Windows.Point]::new(17.0, 17.0)
        $clip.RadiusX = 17.0
        $clip.RadiusY = 17.0
        $av.Clip = $clip
        [System.Windows.Controls.Grid]::SetColumn($av, 0)
        [System.Windows.Controls.Grid]::SetColumn($b, 1)
        [void]$riga.Children.Add($av)
        [void]$riga.Children.Add($b)
        [void]$ChatPanel.Children.Add($riga)
    }
    $ChatScroll.ScrollToEnd()
}

function Add-Activity {
    param([string]$Text)
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = $Text
    $tb.FontSize = 11
    $tb.FontStyle = 'Italic'
    $tb.Foreground = [string]$sync.Palette.argentoScuro
    $tb.TextWrapping = 'Wrap'
    $tb.Margin = '18,2,18,2'
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    Set-TextBoxCopyMenu $tb
    [void]$ChatPanel.Children.Add($tb)
    $ChatScroll.ScrollToEnd()
}

function Show-Onomatopea {
    param([string]$Word)
    if (-not $Word) {
        $Word = @('POW!', 'ZAP!', 'BAM!', 'WHAM!', 'BOOM!', 'CLICK!', 'TAP!') | Get-Random
    }
    $OnomaText.Text = $Word
    $OnomaText.Opacity = 1.0
    $fade = New-Object System.Windows.Media.Animation.DoubleAnimation
    $fade.From = 1.0
    $fade.To = 0.0
    $fade.BeginTime = [TimeSpan]::FromMilliseconds(500)
    $fade.Duration = New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(1300))
    $OnomaText.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fade)
}

function Update-MicLabel {
    # v6.1: indicatore del microfono. Con il motore MODERNO di Windows non esiste un
    # livello da mostrare: si legge lo stato (il motore moderno non espone il volume).
    if (-not $MicText) { return }
    if ($sync.Listening) {
        $st = ''
        try { $st = [string]$sync.ListenStato } catch { }
        if (-not $st) { $st = 'ascolto...' }
        $modo = ''
        try { $modo = [string]$sync.MicModo } catch { }
        if ($modo -eq 'winrt') { $st = $st + '  (motore moderno)' }
        elseif ($modo -eq 'storico') { $st = $st + '  (motore storico)' }
        $MicText.Text = ('MICROFONO: ' + $st)
        if ($MicLevel) {
            $lv = 0
            try { $lv = [int]$sync.ListenLivello } catch { }
            if ($lv -lt 0) { $lv = 0 }
            $MicLevel.Value = [Math]::Min(100, [Math]::Max(0, $lv))
        }
    } else {
        $MicText.Text = 'MICROFONO: spento'
        if ($MicLevel) { $MicLevel.Value = 0 }
    }
}

function Update-ModeButton {
    $m = [string]$sync.Config.sicurezza
    if ((Get-ModalitaSequenza) -notcontains $m) { $m = 'smart' }
    $sync.Config.sicurezza = $m
    $BtnModo.Content = (Get-ModalitaEtichetta $m)
    $BtnModo.ToolTip = ('Modalita: ' + (Get-ModalitaEtichetta $m) + ' - clicca per cambiare')
    $BtnModo.Background = (Get-ModalitaColore $m)
    switch ($m) {
        'prudente'      { $BtnModo.Foreground = '#F0E9D8' }
        'libera'        { $BtnModo.Foreground = '#F0E9D8' }
        'sviluppatore'  { $BtnModo.Foreground = '#F0E9D8' }
        'hacker'        { $BtnModo.Foreground = '#39FF14' }
        default         { $BtnModo.Foreground = '#1A1408' }
    }
    $InputBox.ToolTip = ''
    try { Update-MicLabel } catch { }
}

function Set-Mode {
    param([string]$M, [string]$Pin = '')
    $M = ([string]$M).Trim().ToLower()
    if ((Get-ModalitaSequenza) -notcontains $M) { $M = 'smart' }
    $sync.Config.sicurezza = $M
    Update-ModeButton
    Save-Config $sync
    Add-Bubble 'zap' (Get-ModalitaDescrizione $M)
    if ($m -eq 'sviluppatore')  { Add-Activity '— sviluppatore: autonomia piena, retry sui rifiuti —' }
    if ($m -eq 'hacker')        { Add-Activity '— hacker: nessun limite, pentest+OSINT (solo sistemi tuoi) —' }
}

function Switch-Mode {
    $seq = Get-ModalitaSequenza
    $cur = [string]$sync.Config.sicurezza
    $i = [array]::IndexOf($seq, $cur)
    if ($i -lt 0) { $i = 1 }
    $next = $seq[($i + 1) % $seq.Count]
    Set-Mode $next
}

function Send-UserText {
    param([string]$Text)
    if (-not $Text) { return }
    $t = $Text.Trim()
    if (-not $t) { return }

    if ($t.StartsWith('/')) {
        Handle-Command $t
        return
    }

    Add-Bubble 'utente' $t

    # v7.9.3: se hai allegato una FOTO e mi chiedi un tema/look, creo il tema dai suoi colori.
    $chiedeTema = ($t -match '(?i)\b(tema|aspetto|look)\b') -or (($t -match '(?i)\b(crea|creami|fai|famme|cambia|cambiami|fammi)\b') -and ($t -match '(?i)\bcolori?\b'))
    if ($chiedeTema) {
        $foto = ''
        foreach ($a in @($sync.Allegati)) {
            $pp = ''
            try { $pp = [string]$a.Percorso } catch { }
            if ($pp -and (Test-Path $pp) -and ((Get-TipoAllegato $pp) -eq 'immagine')) { $foto = $pp; break }
        }
        if ($foto) { Asp-TemaDaFoto $foto; return }
    }

    # v5: comandi diretti (apri/chiudi/scrivi/lancia/cerca) eseguiti SUBITO, senza giro sull'IA.
    try {
        $dc = Invoke-ComandoDiretto -sync $sync -Testo $t
        if ($dc.Gestito) {
            if ($dc.Messaggio) { Add-Bubble 'zap' ([string]$dc.Messaggio) }
            try { $sync.UiQueue.Enqueue(@{ Type = 'speak'; Data = [string]$dc.Messaggio }) } catch { }
            $StatusText.Text = 'FATTO!'
            Set-AvatarState 'ok'
            return
        }
    } catch {
        Add-Activity ('— comando diretto non riuscito: ' + $_.Exception.Message + ' —')
    }

    # v6.1: gli allegati vengono letti (e le immagini guardate) e passati allo ZAP.
    $extra = ''
    try { $extra = Get-AllegatiPerIA $sync } catch { }
    if ($extra) {
        Add-Activity ('— allegati passati allo ZAP (' + $sync.Allegati.Count + ') —')
        Svuota-Allegati $sync
    }
    $sync.InputQueue.Enqueue($t + $extra)
    $StatusText.Text = 'HO RICEVUTO! PENSO...'
}

function Handle-Command {
    param([string]$Cmd)
    $parts = $Cmd -split '\s+', 2
    switch ($parts[0].ToLower()) {
        '/aiuto' {
            $h = @()
            $h += 'COMANDI RAPIDI'
            $h += '/skills — elenco delle cose che ho imparato'
            $h += '/insegna — insegnami una cosa nuova'
            $h += '/mode — cambia modalita (prudente, smart, libera, sviluppatore, enterprise, hacker)'
            $h += '/simula — SIMULAZIONE: non eseguo, ti mostro solo cosa farei (dry-run)'
            $h += '/audit — ultime azioni registrate (scatola nera);  /audit verifica — controlla che il registro non sia stato manomesso'
            $h += '/policy — permessi granulari (proteggi cartelle, consenti cartelle) e stato'
            $h += '/sandbox — modalita isolata (sandbox di sistema: limiti + chiusura garantita) on|off'
            $h += '/allegati — scegli uno o piu file da guardare ed elaborare (foto, video, PDF, documenti)'
            $h += '/foto — scegli una o piu immagini'
            $h += '/video — scegli uno o piu video'
            $h += '/allegati-vuota — togli tutti gli allegati'
            $h += '/appunti — apri il blocco appunti (resta salvato)'
            $h += '/impara-schermo — imparo guardando lo schermo'
            $h += '/migliorati — trucchi e opzioni per rendermi migliore'
            $h += '/admin — permessi di amministratore'
            $h += '/tema — apri il pannello tema e colori'
            $h += '/tema-foto - crea il tema dai colori di una FOTO che alleghi'
            $h += '/programmi — i tuoi programmi, da lanciare con un clic'
            $h += '/automazioni - elenco di cose da far fare a ZAP da solo'
            $h += '/kali - console e strumenti Kali Linux (ethical hacking)'
            $h += '/hacker - modalita HACKER: nessun limite, pentest + OSINT (solo su TUOI sistemi)'
            $h += '/osint <dominio|ip|email|username|metadati> <bersaglio> - ricognizione passiva da fonti pubbliche'
            $h += '/mini <compito> - crea un mini-agente PowerShell leggero (bassa RAM)'
            $h += '/mic — diagnostica del microfono'
            $h += '/ai auto|stato|<servizio> — quale cervello IA usare (es. /ai openai)'
            $h += '/ferma — ferma tutto'
            $h += '/vuota — svuota la chat'
            $h += ''
            $h += 'A voce o per scritto: "chiudi questa pagina", "aprimi il blocco note", "lancia il mio backup", "apri WhatsApp e scrivi a Mario: ci vediamo alle 8".'
            Add-Bubble 'zap' ($h -join "`n")
        }
        '/skills' {
            Add-Bubble 'zap' (Format-SkillList $sync)
        }
        '/insegna' {
            $TeachPanel.Visibility = 'Visible'
            $TeachNome.Focus()
        }
        '/ai' {
            $p = ''
            if ($parts.Count -gt 1) { $p = [string]$parts[1] }
            $p = $p.Trim().ToLower()
            if (-not $p -or $p -eq 'auto') {
                $sync.Config.modalita_ai = 'auto'
                Save-Config $sync
                Aggiorna-AiCombo
                Add-Bubble 'zap' ('IA in AUTOMATICO: scelgo io il servizio in base al lavoro.' + "`n`n" + (Get-AiRouterText $sync))
            }
            elseif ($p -eq 'stato') {
                Add-Bubble 'zap' (Get-AiRouterText $sync)
            }
            elseif (Get-ProviderById $p) {
                $sync.Config.modalita_ai = $p
                Save-Config $sync
                Aggiorna-AiCombo
                Add-Bubble 'zap' ('IA fissata su ' + $p + '. ' + (Get-ProviderStato $sync $p))
            }
            else {
                Add-Bubble 'zap' ('Servizio sconosciuto: ' + $p + '. Usa /ai stato per l elenco.')
            }
        }
        '/simula' {
            $on = -not [bool]$sync.Config.simulazione
            $sync.Config.simulazione = $on
            Save-Config $sync
            if ($on) {
                Add-Bubble 'zap' ('MODALITA SIMULAZIONE: ON. Da ora NON eseguo nulla: ti mostro solo cosa farei (anteprima del comando). Scrivi /simula di nuovo per tornare a eseguire davvero.')
                try { $StatusText.Text = 'SIMULAZIONE ON' } catch { }
            } else {
                Add-Bubble 'zap' 'MODALITA SIMULAZIONE: OFF. Torno a eseguire i comandi davvero.'
                try { $StatusText.Text = 'PRONTO!' } catch { }
            }
            Set-AvatarState 'ok'
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('simulazione ' + $(if ($on) { 'ON' } else { 'OFF' })) -Esito 'ok' } catch { }
        }
        '/audit' {
            $sub = [string]$parts[1]
            if ($sub -match '(?i)verifica|integrit') { Add-Bubble 'zap' (Test-AuditIntegrita $sync) }
            else { Add-Bubble 'zap' (Format-AuditUltimi $sync 20) }
        }
        '/policy' {
            $sub = [string]$parts[1]
            if ($sub -match '(?i)^consenti\s+(.+)$') {
                $cart = $Matches[1].Trim()
                $pl = $sync.Config.policy
                $pl['cartelle_consentite'] = @(@($pl.cartelle_consentite) + $cart | Select-Object -Unique)
                Save-Config $sync
                Add-Bubble 'zap' ('Aggiunta alle cartelle consentite (scrittura libera): ' + $cart)
            } elseif ($sub -match '(?i)^protetta\s+(.+)$') {
                $cart = $Matches[1].Trim()
                $pl = $sync.Config.policy
                $pl['cartelle_protette'] = @(@($pl.cartelle_protette) + $cart | Select-Object -Unique)
                Save-Config $sync
                Add-Bubble 'zap' ('Aggiunta alle cartelle PROTTETE: ' + $cart)
            } elseif ($sub -match '(?i)^(on|off)$') {
                $pl = $sync.Config.policy
                $pl['attivo'] = ($Matches[1].ToLower() -eq 'on')
                Save-Config $sync
                Add-Bubble 'zap' ('Permessi granulari: ' + $Matches[1].ToUpper())
            } else {
                Add-Bubble 'zap' (Format-PolicyInfo $sync)
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('policy ' + $sub) -Esito 'ok' } catch { }
        }
        '/sandbox' {
            $sub = [string]$parts[1]
            if ($sub -match '(?i)^(on|off)$') {
                if (-not $sync.Config.sandbox) { $sync.Config.sandbox = Get-SandboxDefault }
                $sync.Config.sandbox['attivo'] = ($Matches[1].ToLower() -eq 'on')
                Save-Config $sync
                Add-Bubble 'zap' ('Modalita isolata (sandbox di sistema): ' + $Matches[1].ToUpper() + '. I comandi girano in un processo separato con limiti di memoria/tempo/processi e chiusura garantita allo scadere del timeout.')
            } else {
                Add-Bubble 'zap' (Get-SandboxInfo $sync)
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('sandbox ' + $sub) -Esito 'ok' } catch { }
        }
                '/pentest' {
            $sub = ''
            if ($parts.Count -gt 1) { $sub = [string]$parts[1] }
            $resto = ''
            if ($parts.Count -gt 2) { $resto = ([string]::Join(' ', $parts[2..($parts.Count-1)])).Trim() }
            if (-not $sync.Config.pentest) { $sync.Config.pentest = Get-PentestDefault }
            $pe = $sync.Config.pentest
            switch -regex ($sub) {
                '(?i)^(on|off)$'             { $pe['attivo'] = ($sub.ToLower() -eq 'on'); Save-Config $sync; Add-Bubble 'zap' (Get-PentestInfo $sync) }
                '(?i)^scope$'                { if (-not $resto) { Add-Bubble 'zap' 'Uso: /pentest scope <host|*.dominio|CIDR>' } else { $t = ($resto -split '\s+')[0]; $pe['scope'] = @(@($pe.scope) | Where-Object { $_ -and ($_ -ne $t) }) + $t; Save-Config $sync; Add-Bubble 'zap' ('Scope pentest: ' + (@($pe.scope) -join ' | ')) } }
                '(?i)^dimentica$'            { if ($resto) { $t = ($resto -split '\s+')[0]; $pe['scope'] = @(@($pe.scope) | Where-Object { $_ -and ($_ -ne $t) }); Save-Config $sync }; Add-Bubble 'zap' (Get-PentestInfo $sync) }
                '(?i)^autorizza$'            { $pe['autorizzazione'] = $resto; Save-Config $sync; Add-Bubble 'zap' ('Autorizzazione registrata: ' + $(if ($resto) { $resto } else { '(vuota)' })) }
                '(?i)^scadenza$'             { $pe['scadenza'] = $resto; Save-Config $sync; Add-Bubble 'zap' ('Scadenza scope: ' + $(if ($resto) { $resto } else { '(nessuna)' })) }
                '(?i)^intrusivo\s+(on|off)$' { $pe['consenti_intrusive'] = ($Matches[1].ToLower() -eq 'on'); Save-Config $sync; Add-Bubble 'zap' ('Strumenti intrusivi: ' + $(if ($pe.consenti_intrusive) { 'ABILITATI (solo se autorizzato)' } else { 'disattivati' })) }
                '(?i)^demo\s+(on|off)$'      { $pe['dimostrazione'] = ($Matches[1].ToLower() -eq 'on'); Save-Config $sync; Add-Bubble 'zap' ('Modalita dimostrativa: ' + $(if ($pe.dimostrazione) { 'SI (pianifica e mostra, non esegue)' } else { 'no' })) }
                '(?i)^piano'                 { $f = 'ricognizione'; $tt = ''; if ($parts.Count -gt 2) { $f = [string]$parts[2] }; if ($parts.Count -gt 3) { $tt = [string]$parts[3] }; Add-Bubble 'zap' (Format-PentestPianoInfo $sync (New-PentestPiano $sync $f $tt) $f $tt) }
                '(?i)^esegui'                { $f = 'ricognizione'; $tt = ''; if ($parts.Count -gt 2) { $f = [string]$parts[2] }; if ($parts.Count -gt 3) { $tt = [string]$parts[3] }; Add-Bubble 'zap' (Invoke-PentestPiano $sync $f $tt) }
                default                      { Add-Bubble 'zap' (Get-PentestInfo $sync) }
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('pentest ' + $sub + ' ' + $resto) -Esito 'ok' } catch { }
        }
        '/hacker' {
            $rest = ''
            if ($parts.Count -gt 1) { $rest = ([string]$parts[1]).Trim() }
            $sub = ''
            if ($rest) { $sub = ([string](($rest -split '\s+')[0])).ToLower() }
            if (-not $sync.Config.hacker) { $sync.Config.hacker = (Get-HackerDefault) }
            switch -regex ($sub) {
                '^(on|attiva|attivo)$' { $sync.Config.hacker.attivo = $true; Set-Mode 'hacker'; Save-Config $sync; Add-Bubble 'zap' (Format-HackerInfo $sync) }
                '^(off|disattiva)$'    { $sync.Config.hacker.attivo = $false; if ([string]$sync.Config.sicurezza -eq 'hacker') { Set-Mode 'smart' }; Save-Config $sync; Add-Bubble 'zap' 'Modalita HACKER disattivata.' }
                '^scope$' {
                    $tk = @($rest -split '\s+')
                    $t = ''
                    if ($tk.Count -gt 1) { $t = [string]$tk[1] }
                    if ($t) { $sync.Config.hacker.scope = @(@($sync.Config.hacker.scope) | Where-Object { $_ -and ($_ -ne $t) }) + $t; Save-Config $sync; Add-Bubble 'zap' ('Scope hacker: ' + (@($sync.Config.hacker.scope) -join ' | ')) }
                    else { Add-Bubble 'zap' 'Uso: /hacker scope <host|*.dominio|CIDR>' }
                }
                default                { Add-Bubble 'zap' (Format-HackerInfo $sync) }
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('hacker ' + $rest) -Esito 'ok' } catch { }
        }
        '/osint' {
            $rest = ''
            if ($parts.Count -gt 1) { $rest = ([string]$parts[1]).Trim() }
            $tk = @($rest -split '\s+' | Where-Object { $_ })
            if ($tk.Count -eq 0) { Add-Bubble 'zap' (Tool-OsintCatalogo) }
            else {
                $tipo = [string]$tk[0]; $target = ''; $extra = ''
                if ($tk.Count -gt 1) { $target = [string]$tk[1] }
                if ($tk.Count -gt 2) { $extra = [string]$tk[2] }
                Add-Bubble 'zap' (Tool-OsintRicerca $base $sync $tipo $target $extra)
            }
        }
        '/mini' {
            $rest = ''
            if ($parts.Count -gt 1) { $rest = [string]$parts[1] }
            if (-not $rest) { Add-Bubble 'zap' (Format-MiniAgentiStato $sync) }
            else { Add-Bubble 'zap' (Tool-MiniAgente $sync '' $rest $true 120) }
        }
        '/mode' { Switch-Mode }
        '/sviluppatore' { Set-Mode 'sviluppatore' }
        '/allegati' {
            Apri-SceltaFile $sync 'tutto'
            Add-Bubble 'zap' ('Allegati pronti: ' + $sync.Allegati.Count + '. Scrivi cosa vuoi che ne faccia, poi premi INVIA.')
        }
        '/foto' {
            Apri-SceltaFile $sync 'foto'
            Add-Bubble 'zap' ('Immagini pronte: ' + $sync.Allegati.Count + '. Scrivi cosa vuoi sapere, poi premi INVIA.')
        }
        '/video' {
            Apri-SceltaFile $sync 'video'
            Add-Bubble 'zap' ('Video pronti: ' + $sync.Allegati.Count + '. Scrivi cosa vuoi sapere, poi premi INVIA.')
        }
        '/appunti' {
            try { $AppuntiBox.Text = Get-AppuntiText $sync } catch { $AppuntiBox.Text = '' }
            $AppuntiPanel.Visibility = 'Visible'
            $AppuntiBox.Focus()
        }
        '/impara-schermo' {
            $q = ''
            if ($parts.Count -gt 1) { $q = [string]$parts[1] }
            Add-Bubble 'zap' 'Guardo lo schermo e imparo...'
            $ris = ''
            try { $ris = [string](Invoke-ImparaDalloSchermo $sync $q) } catch { $ris = ('Errore: ' + $_.Exception.Message) }
            Add-Bubble 'zap' $ris
        }
        '/migliorati' {
            $a = ''
            if ($parts.Count -gt 1) { $a = [string]$parts[1] }
            $ris = ''
            try { $ris = [string](Invoke-ConsigliMiglioramento $sync $a) } catch { $ris = ('Errore: ' + $_.Exception.Message) }
            Add-Bubble 'zap' $ris
        }
        '/admin' {
            Add-Bubble 'zap' (Get-AdminStatus)
        }
        '/tema-foto' {
            Asp-TemaDaFoto ([string]$parts[1])
        }
        '/tema' {
            $AspettoPanel.Visibility = 'Visible'
            Asp-Ricarica
        }
        '/aspetto' {
            $AspettoPanel.Visibility = 'Visible'
            Asp-Ricarica
        }
        '/allegati-vuota' {
            Svuota-Allegati $sync
            Add-Bubble 'zap' 'Allegati tolti.'
        }
        '/programmi' { $ProgrammiPanel.Visibility = 'Visible'; Aggiorna-PannelloProgrammi }
        '/automazioni' { Aggiorna-PannelloAutomazioni; $AutomazioniPanel.Visibility = 'Visible' }
        '/kali' { Aggiorna-PannelloKali; $KaliPanel.Visibility = 'Visible' }
        '/mic' { Add-Bubble 'zap' (Get-SpeechDiagnostica) }
        '/ferma' { Do-Stop }
        '/vuota' {
            $ChatPanel.Children.Clear()
            Add-Activity '— chat svuotata —'
        }
        default {
            Add-Bubble 'zap' "Comando sconosciuto: $($parts[0]). Prova /aiuto."
        }
    }
}

function Do-Stop {
    Stop-Listen $sync
    $sync.Listening = $false
    $BtnParla.Content = 'PARLA'
    Stop-Speak $sync
    if ($sync.CurrentExec) {
        try { $sync.CurrentExec.Stop() } catch { }
    }
    $StatusText.Text = 'INTERROTTO!'
    Show-Onomatopea 'WHAM!'
    Add-Activity '— tutto fermato —'
}

function Aggiorna-PannelloProgrammi {
    $dir = Get-ProgrammiDir $sync
    if (-not (Test-Path $dir)) { try { New-Item -ItemType Directory -Path $dir | Out-Null } catch { } }
    $voci = @(Get-ProgrammiScansionati $dir)
    $ProgElenco.Text = (Format-ProgrammiElenco $sync)
    $ProgCombo.Items.Clear()
    foreach ($v in $voci) { [void]$ProgCombo.Items.Add($v.nome) }
    if ($ProgCombo.Items.Count -gt 0) { $ProgCombo.SelectedIndex = 0 }
    $ProgInfo.Text = ('Cartella: ' + $dir + '   (' + $voci.Count + ' programmi)')
}

# --------------------------------------------------------------------------
# Pulsanti
# --------------------------------------------------------------------------

$BtnInvia.Add_Click({
    Send-UserText $InputBox.Text
    $InputBox.Text = ''
})

$InputBox.Add_PreviewKeyDown({
    param($s, $e)
    if ($e.Key -eq 'Return' -and -not ([System.Windows.Input.Keyboard]::Modifiers -band [System.Windows.Input.ModifierKeys]::Shift)) {
        $e.Handled = $true
        Send-UserText $InputBox.Text
        $InputBox.Text = ''
        $InputBox.CaretIndex = 0
    }
})

# v6: copia/incolla garantiti nel campo dove scrivi (Ctrl+C/Ctrl+V nativi + menu tasto destro).
Set-InputTextMenu $InputBox

$BtnParla.Add_Click({
    if ($sync.Listening) {
        Stop-Listen $sync
        $sync.Listening = $false
        $BtnParla.Content = 'PARLA'
        Set-AvatarState 'neutro'
        $StatusText.Text = 'ASCOLTO ANNULLATO'
        return
    }
    if (-not (Test-SpeechAvailable)) {
        [System.Windows.MessageBox]::Show($Window,
            "Nessun motore vocale disponibile su Windows.`n`nAggiungi il pacchetto italiano: Impostazioni -> Data e ora e lingua -> Lingua e area -> Italiano -> Opzioni -> Riconoscimento vocale.`nControlla anche: Impostazioni -> Privacy e sicurezza -> Microfono (attiva anche per le app desktop).`n`nNel frattempo puoi scrivere nella chat!",
            'ZAP! Microfono', 'OK', 'Warning') | Out-Null
        Add-Bubble 'zap' (Get-SpeechDiagnostica)
        return
    }
    Stop-Speak $sync
    $lingua = [string]$sync.Config.voce.ascolto_lingua
    $sec = 12
    try { $sec = [int]$sync.Config.voce.ascolto_secondi } catch { }
    Start-Listen -sync $sync -Culture $lingua -TimeoutSec $sec
    $sync.Listening = $true
    $BtnParla.Content = 'ASCOLTO...'
    $StatusText.Text = 'TI ASCOLTO... PARLA PURE!'
    Set-AvatarState 'pensa'
    Show-Onomatopea 'TAP!'
})

$BtnInsegna.Add_Click({
    $TeachPanel.Visibility = 'Visible'
    $TeachNome.Focus()
})

$BtnModo.Add_Click({ Switch-Mode })

$BtnProgrammi.Add_Click({
    $ProgrammiPanel.Visibility = 'Visible'
    Aggiorna-PannelloProgrammi
})

$BtnAi.Add_Click({
    Aggiorna-AiList
    $AiPanel.Visibility = 'Visible'
})

$BtnChiudiAi.Add_Click({ $AiPanel.Visibility = 'Collapsed' })

$BtnAiSalvaTutti.Add_Click({
    Save-AiPanel
    Aggiorna-AiList
    Aggiorna-AiCombo
    Add-Bubble 'zap' ('Servizi IA salvati. ' + (Get-AiRouterText $sync))
    Show-Onomatopea 'ZAP!'
})

$BtnAiAiutoChiavi.Add_Click({
    $p = Join-Path $sync.Base 'ISTRUZIONI_API_KEY.md'
    try { Start-Process 'notepad.exe' $p } catch { }
    Add-Bubble 'zap' ('Le chiavi le ottieni dai siti ufficiali (io non posso procurartele). Ho aperto ISTRUZIONI_API_KEY.md:' + "`n" +
        'per ogni servizio c e il link della pagina da cui copiare la chiave. Poi la incolli qui e premi SALVA QUESTO SERVIZIO.' + "`n`n" +
        'Nota: Ollama gira sul TUO PC (usa la tua RAM). Google, OpenAI, Anthropic, Qwen e gli altri girano in cloud.')
})

if ($AiSel) { $AiSel.Add_SelectionChanged({ Set-AiDaCombo }) }

$BtnAllegati.Add_Click({ Apri-SceltaFile $sync 'tutto' })
$BtnFoto.Add_Click({ Apri-SceltaFile $sync 'foto' })
$BtnVideo.Add_Click({ Apri-SceltaFile $sync 'video' })

# v7.9: TRASPARENZA VERA. La finestra e' dichiarata trasparente in ui\window.xaml
# (WindowStyle=None + AllowsTransparency=True + sfondo trasparente): ora abbassare
# l'opacita' rende DAVVERO la finestra semitrasparente (si vede il desktop dietro),
# invece di limitarsi a scurire il contenuto come faceva la vecchia versione.
function Set-OpacitaFinestra {
    param([double]$Percento)
    $a = [Math]::Max(0.25, [Math]::Min(1.0, $Percento / 100.0))
    $Window.Opacity = $a
    if ($TrasparenzaLabel) { $TrasparenzaLabel.Text = ([int][Math]::Round($Percento)).ToString() + '%' }
}
$Window.AllowDrop = $true
if ($Trasparenza) {
    $Trasparenza.Add_ValueChanged({
        param($s, $e)
        Set-OpacitaFinestra ([double]$Trasparenza.Value)
    })
}
Set-OpacitaFinestra ([double]$(if ($Trasparenza) { $Trasparenza.Value } else { 100 }))

# v7.9.2: SPOSTARE e RIDIMENSIONARE la finestra anche senza i bordi di Windows.
# WPF (DragMove) su una finestra trasparente NON la sposta e non la ridimensiona:
# allora mando alla finestra un "clic sul titolo/bordo" (WM_NCLBUTTONDOWN) e lascio
# fare a Windows, che la trascina e la ridimensiona come una finestra normale.
# (Cosi' funzionano anche il doppio clic per ingrandire e l'aggancio ai lati.)
if (-not ('ZapDrag' -as [type])) {
    try {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ZapDrag {
    [DllImport("user32.dll")] public static extern bool ReleaseCapture();
    [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
}
'@
    } catch { }
}
$script:ZapHwnd = [IntPtr]::Zero
function Get-ZapHwnd {
    if ($script:ZapHwnd -eq [IntPtr]::Zero) {
        try { $script:ZapHwnd = (New-Object System.Windows.Interop.WindowInteropHelper($Window)).Handle } catch { }
    }
    return $script:ZapHwnd
}
function Start-ZapMossa {
    param([int]$Hit)
    try {
        $h = Get-ZapHwnd
        if ($h -eq [IntPtr]::Zero) { return }
        [void][ZapDrag]::ReleaseCapture()
        [void][ZapDrag]::SendMessage($h, 0xA1, [IntPtr]$Hit, [IntPtr]::Zero)
    } catch { }
}
# 1) TRASCINA la finestra dalla barra del titolo (doppio clic = ingrandisci/ripristina: lo fa Windows)
$barra = $TitleBarDrag
if (-not $barra) { try { $barra = $Window.FindName('TitleBar') } catch { } }
if ($barra) {
    $barra.Add_MouseLeftButtonDown({
        param($s, $e)
        $src = $e.OriginalSource
        if ($src -is [System.Windows.Controls.Button]) { return }
        if ($src -and $src.TemplatedParent -is [System.Windows.Controls.Button]) { return }
        Start-ZapMossa 2
    })
}
# 2) RIDIMENSIONA afferrando i bordi (7 pixel attorno alla finestra). I bottoni restano cliccabili.
$script:ZapBordo = 7
$Window.Add_PreviewMouseLeftButtonDown({
    param($s, $e)
    try {
        if ($Window.WindowState -eq 'Maximized') { return }
        $src = $e.OriginalSource
        if ($src -is [System.Windows.Controls.Button]) { return }
        if ($src -and $src.TemplatedParent -is [System.Windows.Controls.Button]) { return }
        $p = $e.GetPosition($Window)
        $b = $script:ZapBordo
        $w = $Window.ActualWidth; $hh = $Window.ActualHeight
        $L = ($p.X -lt $b); $R = ($p.X -gt ($w - $b)); $T = ($p.Y -lt $b); $B = ($p.Y -gt ($hh - $b))
        $hit = 0
        if ($T -and $L) { $hit = 13 }
        elseif ($T -and $R) { $hit = 14 }
        elseif ($B -and $L) { $hit = 16 }
        elseif ($B -and $R) { $hit = 17 }
        elseif ($L) { $hit = 10 }
        elseif ($R) { $hit = 11 }
        elseif ($T) { $hit = 12 }
        elseif ($B) { $hit = 15 }
        if ($hit -ne 0) { Start-ZapMossa $hit; $e.Handled = $true }
    } catch { }
})
if ($BtnWinMin)   { $BtnWinMin.Add_Click({ $Window.WindowState = 'Minimized' }) }
if ($BtnWinMax)   { $BtnWinMax.Add_Click({ if ($Window.WindowState -eq 'Maximized') { $Window.WindowState = 'Normal' } else { $Window.WindowState = 'Maximized' } }) }
if ($BtnWinClose) { $BtnWinClose.Add_Click({ $Window.Close() }) }

# v7.6: TRASCINA i file dentro la finestra per allegarli (foto, video, PDF, documenti)
$Window.AllowDrop = $true
$Window.Add_PreviewDragOver({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $e.Effects = [System.Windows.DragDropEffects]::Copy
    } else {
        $e.Effects = [System.Windows.DragDropEffects]::None
    }
    $e.Handled = $true
})
$Window.Add_PreviewDrop({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $files = @($e.Data.GetData([System.Windows.DataFormats]::FileDrop))
        foreach ($f in $files) { if ($f) { Aggiungi-Allegato $sync ([string]$f) } }
        $StatusText.Text = ('ALLEGATI: ' + $sync.Allegati.Count + ' pronti (trascinati)')
        Set-AvatarState 'pensa'
        Show-Onomatopea 'PRESO!'
        $e.Handled = $true
    }
})

$BtnFerma.Add_Click({ Do-Stop })

$BtnImpostazioni.Add_Click({
    $CfgNome.Text         = [string]$sync.Config.nome
    $CfgApiBase.Text      = [string]$sync.Config.api_base
    $CfgApiKey.Text       = [string]$sync.Config.api_key
    $CfgModello.Text      = [string]$sync.Config.modello
    $CfgBrowser.Text      = [string]$sync.Config.browser
    if ($CfgMotore.Items.Contains([string]$sync.Config.motore_ricerca)) { $CfgMotore.SelectedItem = [string]$sync.Config.motore_ricerca }
    $CfgCartella.Text     = [string]$sync.Config.cartella_lavoro
    $CfgVoce.IsChecked    = [bool]$sync.Config.voce.risposte_ad_alta_voce
    try { $ModelInfo.Text = Get-ModelStatusText $sync } catch { }
    $SettingsPanel.Visibility = 'Visible'
})

$BtnChiudiCfg.Add_Click({ $SettingsPanel.Visibility = 'Collapsed' })

$BtnSalvaCfg.Add_Click({
    $sync.Config.nome  = $CfgNome.Text.Trim()
    if (-not $sync.Config.nome) { $sync.Config.nome = 'ZAP' }
    $sync.Config.api_base = $CfgApiBase.Text.Trim()
    $sync.Config.api_key  = $CfgApiKey.Text.Trim()
    $sync.Config.modello  = $CfgModello.Text.Trim()
    $sync.Config.browser  = $CfgBrowser.Text.Trim()
    if (-not $sync.Config.browser) { $sync.Config.browser = 'thorium' }
    if ($CfgMotore.SelectedItem) { $sync.Config.motore_ricerca = [string]$CfgMotore.SelectedItem }
    $sync.Config.cartella_lavoro = $CfgCartella.Text.Trim()
    $sync.Config.voce.risposte_ad_alta_voce = [bool]$CfgVoce.IsChecked
    Save-Config $sync
    Initialize-Tts $sync
    $SettingsPanel.Visibility = 'Collapsed'
    Add-Bubble 'zap' 'Impostazioni salvate! BAM!'
    Show-Onomatopea 'BAM!'
    try { $ModelInfo.Text = Get-ModelStatusText $sync } catch { }
})

$BtnChiudiTeach.Add_Click({
    $TeachPanel.Visibility = 'Collapsed'
})

$BtnSalvaTeach.Add_Click({
    $n = $TeachNome.Text.Trim()
    $d = $TeachQuando.Text.Trim()
    $c = $TeachCodice.Text
    if (-not $n -or -not $c.Trim()) {
        [System.Windows.MessageBox]::Show($Window, 'Servono almeno il nome e lo script!', 'ZAP!', 'OK', 'Warning') | Out-Null
        return
    }
    if (-not $d) { $d = "Skill insegnata dall'utente il $(Get-Date -Format 'yyyy-MM-dd')" }
    $res = Save-Skill $sync $n $d $d $c
    $TeachPanel.Visibility = 'Collapsed'
    $TeachNome.Text = ''; $TeachQuando.Text = ''; $TeachCodice.Text = ''
    Add-Bubble 'zap' $res
    Show-Onomatopea 'IMPARATO!'
    Set-AvatarState 'ok'
    $StatusText.Text = 'HO IMPARATO QUALCOSA DI NUOVO!'
})

$BtnProgAggiorna.Add_Click({ Aggiorna-PannelloProgrammi })

$BtnProgAvvia.Add_Click({
    $nome = ''
    if ($ProgCombo.Text) { $nome = $ProgCombo.Text.Trim() }
    elseif ($ProgCombo.SelectedItem) { $nome = [string]$ProgCombo.SelectedItem }
    if (-not $nome) { Add-Bubble 'zap' 'Scegli un programma dalla lista.'; return }
    $r = Start-Programma $sync $nome ''
    Add-Bubble 'zap' ([string]$r)
})

$BtnProgCartella.Add_Click({
    $dir = Get-ProgrammiDir $sync
    try { if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null } } catch { }
    try { Start-Process 'explorer.exe' $dir } catch { Add-Bubble 'zap' ('Cartella programmi: ' + $dir) }
})

$BtnChiudiProg.Add_Click({ $ProgrammiPanel.Visibility = 'Collapsed' })
# --- AUTOMAZIONI: elenco di cose da far fare a ZAP da solo ---
function Aggiorna-PannelloAutomazioni {
    $AutoList.Children.Clear()
    $conv = New-Object System.Windows.Media.BrushConverter
    $catalogo = @(Get-CatalogoAutomazioni $sync.Base)
    foreach ($a in $catalogo) {
        $riga = New-Object System.Windows.Controls.StackPanel
        $riga.Margin = [System.Windows.Thickness]::new(0, 4, 0, 4)
        $cb = New-Object System.Windows.Controls.CheckBox
        $cb.Content = [string]$a.titolo
        $cb.Tag = [string]$a.id
        $cb.FontSize = 14
        $cb.FontWeight = [System.Windows.FontWeights]::SemiBold
        $cb.Foreground = $conv.ConvertFromString('#F0E9D8')
        [void]$riga.Children.Add($cb)
        $tb = New-Object System.Windows.Controls.TextBlock
        $tb.Text = ([string]$a.desc + '  [' + [string]$a.categoria + ' - ' + [string]$a.tipo + ' ' + [string]$a.orario + ']')
        $tb.FontSize = 11
        $tb.Foreground = $conv.ConvertFromString('#9AA4AE')
        $tb.TextWrapping = 'Wrap'
        $tb.Margin = [System.Windows.Thickness]::new(24, 0, 0, 0)
        [void]$riga.Children.Add($tb)
        [void]$AutoList.Children.Add($riga)
    }
}

if ($BtnAutomazioni) {
    $BtnAutomazioni.Add_Click({
        Aggiorna-PannelloAutomazioni
        $AutomazioniPanel.Visibility = 'Visible'
    })
}
if ($BtnAutoCrea) {
    $BtnAutoCrea.Add_Click({
        $fatte = 0
        foreach ($riga in $AutoList.Children) {
            $cb = $riga.Children[0]
            if (($cb -is [System.Windows.Controls.CheckBox]) -and $cb.IsChecked) {
                $item = Get-AutomazioneById $sync.Base ([string]$cb.Tag)
                if ($item) { Add-Bubble 'zap' (New-AutomazioneScelta $sync $item); $fatte++ }
            }
        }
        $testo = ''
        if ($AutoDescr) { $testo = [string]$AutoDescr.Text.Trim() }
        if ($testo) { Add-Bubble 'zap' (New-AutomazioneLibera $sync $testo); $fatte++ }
        if ($fatte -eq 0) { Add-Bubble 'zap' 'Non hai scelto nulla: spunta una o piu automazioni, oppure scrivi cosa vuoi automatizzare.' }
        else { Show-Onomatopea 'FATTO!'; Set-AvatarState 'ok'; $StatusText.Text = 'AUTOMAZIONI ATTIVATE!' }
        $AutoDescr.Text = ''
        Aggiorna-PannelloAutomazioni
    })
    $BtnAutoAggiorna.Add_Click({ Aggiorna-PannelloAutomazioni })
    $BtnAutoChiudi.Add_Click({ $AutomazioniPanel.Visibility = 'Collapsed' })
}

# --- KALI: console + strumenti (via WSL) - tutto in BACKGROUND, la UI non si blocca ---
function Start-KaliBackground {
    param([string]$Modo, [string]$Arg)
    $jobTxt = @'
param($base, $sync, $modo, $arg)
. (Join-Path $base 'brain\kali.ps1')
try {
    if ($modo -eq 'check') {
        $pronto = Test-KaliPronto
        $lista  = @(Get-KaliToolsStato)
        $sync.UiQueue.Enqueue(@{ Type = 'kali_tools'; Data = @{ pronto = [bool]$pronto; lista = $lista } })
    }
    elseif ($modo -eq 'cmd') {
        $r = Invoke-KaliCommand ([string]$arg) 300
        $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = [string]$r.out })
    }
    elseif ($modo -eq 'install') {
        foreach ($one in ([string]$arg -split ',')) {
            if ($one) { $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = (Installa-KaliTool $one) }) }
        }
        $sync.UiQueue.Enqueue(@{ Type = 'kali_tools'; Data = @{ pronto = (Test-KaliPronto); lista = @(Get-KaliToolsStato) } })
    }
    elseif ($modo -eq 'setup') {
        $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = (Installa-KaliDistro) })
    }
} catch {
    $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = ('errore: ' + $_.Exception.Message) })
}
'@
    try {
        $rs = [runspacefactory]::CreateRunspace()
        $rs.ApartmentState = 'MTA'
        $rs.Open()
        $ps = [powershell]::Create()
        $ps.Runspace = $rs
        [void]$ps.AddScript($jobTxt).AddArgument([string]$sync.Base).AddArgument($sync).AddArgument([string]$Modo).AddArgument([string]$Arg)
        [void]$ps.BeginInvoke()
    } catch {
        if ($KaliOut) { $KaliOut.AppendText('errore avvio: ' + $_.Exception.Message + "`r`n") }
    }
}

function Aggiorna-PannelloKali {
    if ($KaliTools) { $KaliTools.Children.Clear() }
    if ($KaliStatus) {
        $KaliStatus.Text = 'Controllo ambiente Kali... (la finestra resta reattiva)'
        $KaliStatus.Foreground = (New-Object System.Windows.Media.BrushConverter).ConvertFromString('#9BD39B')
    }
    Start-KaliBackground -Modo 'check' -Arg ''
}

function Invoke-KaliDaUI {
    $cmd = ''
    if ($KaliCmd) { $cmd = [string]$KaliCmd.Text.Trim() }
    if (-not $cmd) { return }
    $KaliOut.AppendText('$ ' + $cmd + "`r`n")
    $KaliOut.ScrollToEnd()
    $KaliCmd.Text = ''
    Start-KaliBackground -Modo 'cmd' -Arg $cmd
}

if ($BtnKali) {
    $BtnKali.Add_Click({ Aggiorna-PannelloKali; $KaliPanel.Visibility = 'Visible' })
}
if ($BtnKaliEsegui) {
    $BtnKaliEsegui.Add_Click({ Invoke-KaliDaUI })
    $KaliCmd.Add_KeyDown({ param($s, $e) if ($e.Key -eq [System.Windows.Input.Key]::Return) { Invoke-KaliDaUI } })
}
if ($BtnKaliInstalla) {
    $BtnKaliInstalla.Add_Click({
        $ids = @()
        foreach ($riga in $KaliTools.Children) {
            $cb = $riga.Children[0]
            if (($cb -is [System.Windows.Controls.CheckBox]) -and $cb.IsChecked) { $ids += [string]$cb.Tag }
        }
        if ($ids.Count -eq 0) { $KaliOut.AppendText('Nessuno strumento spuntato.' + "`r`n"); return }
        foreach ($id in $ids) { $KaliOut.AppendText('Installazione di ' + $id + ' in corso...' + "`r`n") }
        $KaliOut.ScrollToEnd()
        Start-KaliBackground -Modo 'install' -Arg ($ids -join ',')
    })
}
if ($BtnKaliSetup)    { $BtnKaliSetup.Add_Click({ $KaliOut.AppendText('Installazione di Kali: apparira la richiesta di AMMINISTRATORE di Windows (finestra UAC) - clicca SI. ' + 'Puo richiedere alcuni minuti. Se e il PRIMO avvio di WSL puo servire un riavvio del PC.' + "`r`n"); $KaliOut.ScrollToEnd(); Start-KaliBackground -Modo 'setup' -Arg '' }) }
if ($BtnKaliAggiorna) { $BtnKaliAggiorna.Add_Click({ Aggiorna-PannelloKali }) }
if ($BtnKaliChiudi)   { $BtnKaliChiudi.Add_Click({ $KaliPanel.Visibility = 'Collapsed' }) }

function Flush-TaskInCoda {
    $coda = Join-Path $sync.Base 'dati\task_in_coda.json'
    if (-not (Test-Path -LiteralPath $coda)) { return }
    try {
        $voci = @(Get-Content -LiteralPath $coda -Raw -Encoding UTF8 | ConvertFrom-Json)
        foreach ($v in $voci) { if ($v.testo) { $sync.InputQueue.Enqueue('[AUTOMAZIONE] ' + [string]$v.testo) } }
        Remove-Item -LiteralPath $coda -Force -ErrorAction SilentlyContinue
    } catch { }
}


# --- APPUNTI: sessione di scrittura salvata su file (non si perde) ---
$BtnAppunti.Add_Click({
    try { $AppuntiBox.Text = Get-AppuntiText $sync } catch { $AppuntiBox.Text = '' }
    $AppuntiPanel.Visibility = 'Visible'
    $AppuntiBox.Focus()
})
$BtnAppuntiSalva.Add_Click({
    try { [void](Set-Appunti $sync $AppuntiBox.Text) } catch { }
    Set-AvatarState 'ok'
    Show-Onomatopea 'SALVATO!'
    $StatusText.Text = 'APPUNTI SALVATI!'
})
$BtnAppuntiChiudi.Add_Click({
    try { [void](Set-Appunti $sync $AppuntiBox.Text) } catch { }
    $AppuntiPanel.Visibility = 'Collapsed'
})

# --- CAMBIA TEMA E COLORI ---
function Asp-Ricarica {
    $p = $sync.PaletteCorr
    if (-not $p) { $p = Get-PaletteDefault }
    $AspSfondo.Text = [string]$p.sfondo
    $AspSuperficie.Text = [string]$p.superficie
    $AspCampo.Text = [string]$p.campo
    $AspPill.Text = [string]$p.pill
    $AspAccento.Text = [string]$p.accento
    $AspAccentoChiaro.Text = [string]$p.accentoChiaro
    $AspAccentoScuro.Text = [string]$p.accentoScuro
    $AspArgento.Text = [string]$p.argento
    $AspArgentoScuro.Text = [string]$p.argentoScuro
    $AspTesto.Text = [string]$p.testo
    $AspTestoSuAccento.Text = [string]$p.testoSuAccento
    $AspBordo.Text = [string]$p.bordo
    $AspFont.Text = [string]$p.font
    $AspSize.Text = [string]$p.fontSize
}

function Asp-LeggiPalette {
    $p = Get-PaletteDefault
    $p.preset = 'personalizzato'
    $p.sfondo = $AspSfondo.Text.Trim()
    $p.superficie = $AspSuperficie.Text.Trim()
    $p.campo = $AspCampo.Text.Trim()
    $p.pill = $AspPill.Text.Trim()
    $p.accento = $AspAccento.Text.Trim()
    $p.accentoChiaro = $AspAccentoChiaro.Text.Trim()
    $p.accentoScuro = $AspAccentoScuro.Text.Trim()
    $p.argento = $AspArgento.Text.Trim()
    $p.argentoScuro = $AspArgentoScuro.Text.Trim()
    $p.testo = $AspTesto.Text.Trim()
    $p.testoSuAccento = $AspTestoSuAccento.Text.Trim()
    $p.bordo = $AspBordo.Text.Trim()
    $p.font = $AspFont.Text.Trim()
    try { $p.fontSize = [int]$AspSize.Text.Trim() } catch { $p.fontSize = 13 }
    if ($p.fontSize -lt 9) { $p.fontSize = 9 }
    if ($p.fontSize -gt 20) { $p.fontSize = 20 }
    return $p
}

function Asp-Salva {
    param($p)
    try {
        $h = @{}
        foreach ($k in @($p.Keys)) { $h[$k] = $p[$k] }
        $sync.Config.aspetto = $h
        Save-Config $sync
    } catch { }
}

function Asp-TemaDaFoto {
    param([string]$Percorso = '')
    # Se non mi passano un file, uso la prima FOTO allegata alla chat.
    if (-not $Percorso) {
        foreach ($a in @($sync.Allegati)) {
            $pp = ''
            try { $pp = [string]$a.Percorso } catch { }
            if ($pp -and (Test-Path $pp) -and ((Get-TipoAllegato $pp) -eq 'immagine')) { $Percorso = $pp; break }
        }
    }
    # Altrimenti chiedo di scegliere un'immagine.
    if (-not $Percorso) {
        try {
            $dlg = New-Object Microsoft.Win32.OpenFileDialog
            $dlg.Title  = 'Scegli una foto per creare il tema'
            $dlg.Filter = 'Immagini|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp;*.tif;*.tiff|Tutti i file|*.*'
            if ($dlg.ShowDialog($Window) -ne $true) { return }
            $Percorso = $dlg.FileName
        } catch { return }
    }
    $StatusText.Text = 'GUARDO LA FOTO...'
    $p = $null
    try { $p = Get-PaletteDaImmagine $Percorso } catch { $p = $null }
    if (-not $p) {
        Add-Bubble 'zap' 'Non riesco a leggere quella foto. Prova con un PNG o JPG.'
        $StatusText.Text = 'ERRORE'
        return
    }
    $p.sfondoImmagine = $Percorso
    Applica-Palette $sync $Window $p
    Asp-ApplicaSfondo $sync $Percorso
    Asp-Salva $p
    Asp-Ricarica
    Set-AvatarState 'ok'
    Show-Onomatopea 'NUOVO LOOK!'
    Add-Bubble 'zap' ('Ho creato un tema con i colori della foto "' + [System.IO.Path]::GetFileName($Percorso) + '". Se non ti piace: /tema e scegli AURA.')
    $StatusText.Text = 'TEMA DALLA FOTO!'
}

function Asp-Applica {
    param([string]$Nome)
    $p = $null
    if ($Nome) { $p = Get-TemaPreset $Nome } else { $p = Asp-LeggiPalette }
    Applica-Palette $sync $Window $p
    try { Asp-ApplicaSfondo $sync ([string]$p.sfondoImmagine) } catch { }
    Asp-Salva $p
    Asp-Ricarica
    Set-AvatarState 'ok'
    Show-Onomatopea 'NUOVO LOOK!'
    $StatusText.Text = 'TEMA APPLICATO!'
}

$BtnAspetto.Add_Click({
    Asp-Ricarica
    $AspettoPanel.Visibility = 'Visible'
})
$BtnAspApplica.Add_Click({ Asp-Applica '' })
$BtnAspRipristina.Add_Click({ Asp-Applica 'aura' })
$BtnAspChiudi.Add_Click({ $AspettoPanel.Visibility = 'Collapsed' })
if ($BtnTemaAura)     { $BtnTemaAura.Add_Click({ Asp-Applica 'aura' }) }
if ($BtnTemaNotte)    { $BtnTemaNotte.Add_Click({ Asp-Applica 'notte' }) }
if ($BtnTemaSmeraldo) { $BtnTemaSmeraldo.Add_Click({ Asp-Applica 'smeraldo' }) }
if ($BtnTemaViola)    { $BtnTemaViola.Add_Click({ Asp-Applica 'viola' }) }
if ($BtnTemaChiaro)   { $BtnTemaChiaro.Add_Click({ Asp-Applica 'chiaro' }) }
if ($BtnTemaFoto)     { $BtnTemaFoto.Add_Click({ Asp-TemaDaFoto }) }

$Window.Add_Closed({
    $sync.Quit = $true
    Stop-Listen $sync
    Stop-Speak $sync
    if ($sync.CurrentExec) { try { $sync.CurrentExec.Stop() } catch { } }
})

# --------------------------------------------------------------------------
# ALLEGATI / UPLOAD: allega un file di qualunque tipo, guardalo e fallo elaborare
# --------------------------------------------------------------------------

function Get-TipoAllegato {
    param([string]$Percorso)
    $ext = ''
    try { $ext = [System.IO.Path]::GetExtension($Percorso).ToLower() } catch { }
    if (@('.png','.jpg','.jpeg','.gif','.bmp','.webp','.tif','.tiff','.ico') -contains $ext) { return 'immagine' }
    if (@('.mp4','.mov','.avi','.mkv','.webm','.wmv','.m4v','.mpg','.mpeg','.3gp') -contains $ext) { return 'video' }
    if (@('.txt','.md','.log','.csv','.tsv','.json','.xml','.yml','.yaml','.ini','.cfg','.conf','.env',
          '.ps1','.psm1','.psd1','.bat','.cmd','.sh','.py','.js','.ts','.html','.htm','.css','.sql',
          '.cs','.java','.c','.cpp','.h','.r','.vb') -contains $ext) { return 'testo' }
    if (@('.docx','.xlsx','.pptx') -contains $ext) { return 'office' }
    if ($ext -eq '.pdf') { return 'pdf' }
    return 'altro'
}

function Get-TestoDaOffice {
    # docx/xlsx/pptx sono archivi ZIP con XML dentro: si estrae il testo senza altri programmi.
    param([string]$Percorso)
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $zip = [System.IO.Compression.ZipFile]::OpenRead($Percorso)
        $testo = ''
        foreach ($v in $zip.Entries) {
            if ($v.FullName -match '(document|sharedStrings|slide[0-9]+|sheet[0-9]+)\.xml$') {
                $sr = New-Object System.IO.StreamReader($v.Open())
                $x = $sr.ReadToEnd()
                $sr.Close()
                $x = $x -replace '<[^>]+>', ' '
                $testo = $testo + ' ' + ($x -replace '\s+', ' ')
            }
        }
        $zip.Dispose()
        return $testo.Trim()
    } catch { return '' }
}

function Get-TestoDaPdf {
    # Estrazione "best effort" del testo dei PDF non compressi (senza programmi esterni).
    param([string]$Percorso)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Percorso)
        $s = [System.Text.Encoding]::GetEncoding(1252).GetString($bytes)
        $pezzi = @()
        foreach ($m in [regex]::Matches($s, '\(([^)]{2,})\)\s*Tj')) { $pezzi += $m.Groups[1].Value }
        foreach ($m in [regex]::Matches($s, '\[(.*?)\]\s*TJ')) { $pezzi += ($m.Groups[1].Value -replace '[\[\]]', ' ') }
        return (($pezzi -join ' ') -replace '\s+', ' ').Trim()
    } catch { return '' }
}

function Aggiorna-BarraAllegati {
    param($sync)
    if (-not $AllegatiBar) { return }
    $AllegatiBar.Children.Clear()
    if ($sync.Allegati.Count -eq 0) {
        $AllegatiBar.Visibility = 'Collapsed'
        if ($AllegatiInfo) { $AllegatiInfo.Text = '' }
        return
    }
    $AllegatiBar.Visibility = 'Visible'
    $tot = 0
    foreach ($a in @($sync.Allegati)) { $tot += [int]$a.Byte }
    if ($AllegatiInfo) { $AllegatiInfo.Text = ('(' + $sync.Allegati.Count + ' allegati, ' + [Math]::Round($tot / 1024.0, 1) + ' KB)') }
    $i = 0
    foreach ($a in @($sync.Allegati)) {
        $btn = New-Object System.Windows.Controls.Button
        $btn.Content = ([string]$a.Tipo + ': ' + [string]$a.Nome + '   x')
        $btn.FontSize = 11
        $btn.Foreground = '#EFDC8F'
        $btn.Background = '#1C222C'
        $btn.BorderBrush = '#D4AF37'
        $btn.BorderThickness = '1'
        $btn.Padding = '8,3'
        $btn.Margin = '0,0,6,0'
        $btn.Tag = $i
        $h = { Rimuovi-Allegato $sync ([int]$btn.Tag) }
        $btn.Add_Click($h.GetNewClosure())
        [void]$AllegatiBar.Children.Add($btn)
        $i = $i + 1
    }
}

function Aggiungi-Allegato {
    param($sync, [string]$Percorso)
    if (-not (Test-Path $Percorso)) { return }
    $voce = @{
        Percorso = $Percorso
        Nome     = [System.IO.Path]::GetFileName($Percorso)
        Tipo     = (Get-TipoAllegato $Percorso)
        Byte     = 0
        Testo    = ''
        B64      = ''
        Mime     = 'image/png'
    }
    try { $voce.Byte = (Get-Item $Percorso).Length } catch { }
    if ($voce.Tipo -eq 'testo') {
        try { $voce.Testo = [string](Get-Content -Path $Percorso -Raw -Encoding UTF8) } catch {
            try { $voce.Testo = [string](Get-Content -Path $Percorso -Raw) } catch { $voce.Testo = '' }
        }
        if ($voce.Testo.Length -gt 20000) { $voce.Testo = $voce.Testo.Substring(0, 20000) + "`n[... testo tagliato per lunghezza ...]" }
    } elseif ($voce.Tipo -eq 'office') {
        $voce.Testo = Get-TestoDaOffice $Percorso
    } elseif ($voce.Tipo -eq 'pdf') {
        $voce.Testo = Get-TestoDaPdf $Percorso
        # PDF scansionato o con poco testo: lo fa leggere direttamente al modello (vista documento)
        if (([string]$voce.Testo).Trim().Length -lt 200 -and [int]$voce.Byte -le 14000000) {
            try {
                $voce.B64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Percorso))
                $voce.Mime = 'application/pdf'
            } catch { }
        }
    } elseif ($voce.Tipo -eq 'immagine') {
        $ext = [System.IO.Path]::GetExtension($Percorso).ToLower()
        $voce.Mime = 'image/png'
        if ($ext -eq '.jpg' -or $ext -eq '.jpeg') { $voce.Mime = 'image/jpeg' }
        elseif ($ext -eq '.gif') { $voce.Mime = 'image/gif' }
        elseif ($ext -eq '.bmp') { $voce.Mime = 'image/bmp' }
        elseif ($ext -eq '.webp') { $voce.Mime = 'image/webp' }
        try {
            if ([int]$voce.Byte -le 8000000) {
                $voce.B64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Percorso))
            } else { $voce.Testo = '[immagine troppo grande per essere inviata: oltre 8 MB]' }
        } catch { }
    } elseif ($voce.Tipo -eq 'video') {
        $ext = [System.IO.Path]::GetExtension($Percorso).ToLower()
        $voce.Mime = 'video/mp4'
        if ($ext -eq '.mov') { $voce.Mime = 'video/quicktime' }
        elseif ($ext -eq '.webm') { $voce.Mime = 'video/webm' }
        elseif ($ext -eq '.avi') { $voce.Mime = 'video/x-msvideo' }
        elseif ($ext -eq '.wmv') { $voce.Mime = 'video/x-ms-wmv' }
        elseif ($ext -eq '.mkv') { $voce.Mime = 'video/x-matroska' }
        elseif ($ext -eq '.m4v') { $voce.Mime = 'video/x-m4v' }
        elseif ($ext -eq '.mpg' -or $ext -eq '.mpeg') { $voce.Mime = 'video/mpeg' }
        try {
            if ([int]$voce.Byte -le 14000000) {
                $voce.B64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Percorso))
            } else { $voce.Testo = '[video troppo grande per l invio diretto: oltre 14 MB. Carica un fotogramma o riducilo.]' }
        } catch { }
    }
    [void]$sync.Allegati.Add($voce)
    Aggiorna-BarraAllegati $sync
}

function Rimuovi-Allegato {
    param($sync, [int]$Indice)
    if ($Indice -ge 0 -and $Indice -lt $sync.Allegati.Count) { $sync.Allegati.RemoveAt($Indice) }
    Aggiorna-BarraAllegati $sync
}

function Svuota-Allegati {
    param($sync)
    $sync.Allegati.Clear()
    Aggiorna-BarraAllegati $sync
}

function Apri-SceltaFile {
    param($sync, [string]$Tipo = 'tutto')
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Multiselect = $true
    if ($Tipo -eq 'foto') {
        $dlg.Title = 'Scegli una o piu immagini'
        $dlg.Filter = 'Immagini (*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp)|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp|Tutti i file (*.*)|*.*'
    } elseif ($Tipo -eq 'video') {
        $dlg.Title = 'Scegli uno o piu video'
        $dlg.Filter = 'Video (*.mp4;*.mov;*.avi;*.mkv;*.webm;*.wmv;*.m4v)|*.mp4;*.mov;*.avi;*.mkv;*.webm;*.wmv;*.m4v|Tutti i file (*.*)|*.*'
    } else {
        $dlg.Title = 'Scegli i file da dare a ZAP (qualunque tipo: foto, video, PDF, documenti)'
        $dlg.Filter = 'Tutti i file (*.*)|*.*'
    }
    $esito = $dlg.ShowDialog($Window)
    if ($esito -eq $true) {
        foreach ($f in @($dlg.FileNames)) { Aggiungi-Allegato $sync $f }
        $StatusText.Text = ('ALLEGATI: ' + $sync.Allegati.Count + ' pronti')
        Set-AvatarState 'pensa'
    }
}

function Get-AllegatiPerIA {
    # Trasforma gli allegati in testo per lo ZAP. Le immagini le fa "guardare" con la vista.
    param($sync)
    if ($sync.Allegati.Count -eq 0) { return '' }
    $righe = @()
    $righe += ''
    $righe += '--- ALLEGATI CHE TI HO DATO ---'
    foreach ($a in @($sync.Allegati)) {
        $righe += ('* ' + [string]$a.Tipo + ': ' + [string]$a.Nome + ' (' + [int]$a.Byte + ' byte)')
        if ([string]$a.Testo) {
            $righe += [string]$a.Testo
        } elseif ([string]$a.B64) {
            $descr = ''
            $domanda = 'Descrivi questa immagine in italiano, in modo breve e utile: cosa si vede, il testo leggibile e i dati importanti.'
            $etichetta = 'cosa vedo nell immagine'
            if ([string]$a.Tipo -eq 'video') {
                $domanda = 'Guarda questo video e raccontami in italiano, breve e utile: cosa succede, cosa si vede, eventuali testi o parlato importanti.'
                $etichetta = 'cosa vedo nel video'
            } elseif ([string]$a.Tipo -eq 'pdf') {
                $domanda = 'Leggi questo documento PDF e riassumi in italiano i punti importanti, i dati e i numeri che contiene.'
                $etichetta = 'cosa dice il documento'
            }
            try {
                $StatusText.Text = ('GUARDO: ' + [string]$a.Nome)
                $descr = [string](Invoke-GeminiVision $sync $domanda ([string]$a.B64) ([string]$a.Mime))
            } catch { $descr = '' }
            if ($descr) { $righe += ('[' + $etichetta + '] ' + $descr) }
            else { $righe += '[allegato: non sono riuscito a leggerlo (serve una chiave con la vista attiva)]' }
        } else {
            $righe += '[file allegato: non riesco a leggerne il contenuto automaticamente]'
        }
    }
    $righe += '--- FINE ALLEGATI ---'
    return ($righe -join "`n")
}

# --------------------------------------------------------------------------
# INTELLIGENZE AI (pannello + selettore). Le chiavi stanno solo in config.json.
# --------------------------------------------------------------------------

function Get-AiTextBoxes {
    param($radice)
    $out = New-Object System.Collections.ArrayList
    if ($null -eq $radice) { return @() }
    if ($radice -is [System.Windows.Controls.TextBox]) { [void]$out.Add($radice) }
    elseif ($radice -is [System.Windows.Controls.Panel]) { foreach ($c in $radice.Children) { foreach ($x in (Get-AiTextBoxes $c)) { [void]$out.Add($x) } } }
    elseif ($radice -is [System.Windows.Controls.Border]) { foreach ($x in (Get-AiTextBoxes $radice.Child)) { [void]$out.Add($x) } }
    elseif ($radice -is [System.Windows.Controls.ContentControl]) { if ($radice.Content) { foreach ($x in (Get-AiTextBoxes $radice.Content)) { [void]$out.Add($x) } } }
    return @($out.ToArray())
}

function New-AiField {
    param($pannello, [string]$etichetta, [string]$id, [string]$campo, [string]$valore)
    $l = New-Object System.Windows.Controls.TextBlock
    $l.Text = $etichetta; $l.FontSize = 11; $l.FontWeight = 'Bold'; $l.Margin = '0,4,0,0'; $l.Foreground = '#E8C86A'
    [void]$pannello.Children.Add($l)
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = [string]$valore
    $tb.FontSize = 13; $tb.FontFamily = 'Segoe UI'; $tb.Padding = '4,3'
    $tb.Background = '#141922'; $tb.Foreground = '#F0E9D8'; $tb.CaretBrush = '#D4AF37'
    $tb.BorderBrush = '#2A323D'; $tb.BorderThickness = '1'; $tb.Margin = '0,0,0,2'
    $tb.Tag = ($campo + ':' + $id)
    Set-InputTextMenu $tb
    [void]$pannello.Children.Add($tb)
}

function Aggiorna-AiList {
    if (-not $AiList) { return }
    $AiList.Children.Clear()
    if ($AiIntro) {
        $AiIntro.Text = ('Incolla la TUA chiave e scrivi il nome del modello per i servizi che vuoi usare. ' +
            'Finche'' un servizio non ha chiave E modello resta [ ] e non viene mai scelto. ' +
            'Io non posso procurarti le chiavi: premi "COME AVERE LE CHIAVI". ' +
            'Le chiavi restano solo nel tuo config.json e non finiscono mai nei log.')
    }
    foreach ($r in Get-ProviderRegistry) {
        $id = [string]$r.id
        $cfg = Get-ProviderConfig $sync $id
        $pronto = $false
        try { $pronto = Test-ProviderReady $sync $id } catch { }
        $box = New-Object System.Windows.Controls.Border
        $box.BorderBrush = '#2A323D'; $box.BorderThickness = '1.5'; $box.CornerRadius = '12'
        $box.Padding = '10'; $box.Margin = '0,0,0,8'; $box.Background = '#161B22'
        $sp = New-Object System.Windows.Controls.StackPanel
        $tit = New-Object System.Windows.Controls.TextBlock
        $tit.FontSize = 15; $tit.FontWeight = 'Bold'; $tit.Foreground = '#E8C86A'
        $tit.Text = ([string]$r.nome + '  ' + $(if ($pronto) { '[PRONTO]' } else { '[ ]' }))
        [void]$sp.Children.Add($tit)
        $nota = New-Object System.Windows.Controls.TextBlock
        $nota.FontSize = 11; $nota.FontStyle = 'Italic'; $nota.Foreground = '#9AA4AE'; $nota.TextWrapping = 'Wrap'
        $nota.Text = ('Lavori adatti: ' + (@($cfg.compiti) -join ', ') + '   -   pagina della chiave: ' + [string]$r.keyurl)
        [void]$sp.Children.Add($nota)
        New-AiField $sp 'Chiave (lascia vuoto se non usi questo servizio)' $id 'chiave' $cfg.chiave
        New-AiField $sp 'Endpoint (gia compilato: cambialo solo se sai cosa fai)' $id 'endpoint' $cfg.endpoint
        New-AiField $sp 'Modello (scrivi il nome esatto del modello scelto)' $id 'modello' $cfg.modello
        $b = New-Object System.Windows.Controls.Button
        $b.Content = 'SALVA QUESTO SERVIZIO'; $b.FontSize = 12; $b.Margin = '0,6,0,0'
        $b.Background = '#D4AF37'; $b.Foreground = '#1A1408'; $b.BorderBrush = '#D4AF37'; $b.BorderThickness = '1'; $b.Padding = '8,4'
        $b.Add_Click({ Save-AiPanel; Aggiorna-AiList; Add-Bubble 'zap' 'Salvato.' })
        [void]$sp.Children.Add($b)
        $box.Child = $sp
        [void]$AiList.Children.Add($box)
    }
}

function Save-AiPanel {
    if (-not $sync.Config.provider_ai) { $sync.Config.provider_ai = Get-DefaultProviderAi }
    foreach ($tb in (Get-AiTextBoxes $AiList)) {
        $tag = [string]$tb.Tag
        if (-not $tag -or ($tag -notlike '*:*')) { continue }
        $i = $tag.IndexOf(':')
        $campo = $tag.Substring(0, $i)
        $id = $tag.Substring($i + 1)
        if (-not $sync.Config.provider_ai.ContainsKey($id)) { continue }
        $sync.Config.provider_ai[$id][$campo] = $tb.Text.Trim()
    }
    Save-Config $sync
}

function Aggiorna-AiCombo {
    if (-not $AiSel) { return }
    $mod = 'auto'
    try { if ($sync.Config.modalita_ai) { $mod = [string]$sync.Config.modalita_ai } } catch { }
    $AiSel.Items.Clear()
    [void]$AiSel.Items.Add('AUTOMATICO')
    foreach ($r in Get-ProviderRegistry) {
        $segno = ''
        try { if (Test-ProviderReady $sync ([string]$r.id)) { $segno = ' *' } } catch { }
        [void]$AiSel.Items.Add(([string]$r.id + $segno))
    }
    $daScegliere = 'AUTOMATICO'
    if ($mod -and $mod -ne 'auto') { $daScegliere = $mod }
    foreach ($it in @($AiSel.Items)) {
        $s = [string]$it
        if ($s -eq $daScegliere -or $s -like ($daScegliere + ' *')) { $AiSel.SelectedItem = $it; break }
    }
}

function Set-AiDaCombo {
    if (-not $AiSel -or -not $AiSel.SelectedItem) { return }
    $v = [string]$AiSel.SelectedItem
    if ($v -like 'AUTOMATICO*') { $sync.Config.modalita_ai = 'auto' }
    else { $sync.Config.modalita_ai = ($v -replace '\s*\*$', '') }
    Save-Config $sync
}

# --------------------------------------------------------------------------
# Timer di servizio: coda UI, conferme, microfono, fine parlato
# --------------------------------------------------------------------------

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(120)

$timer.Add_Tick({

    # 1) Richieste di conferma dall'agente
    if ($sync.ConfirmRequest) {
        $req = $sync.ConfirmRequest
        $res = [System.Windows.MessageBox]::Show($Window,
            [string]$req.Text, 'ZAP! chiede conferma',
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Warning)
        $sync.ConfirmResult = ($res -eq [System.Windows.MessageBoxResult]::Yes)
        $sync.ConfirmRequest = $null
        try { if ($sync.ConfirmDone) { $sync.ConfirmDone.Set() } } catch { }
    }

    # 2) Coda dei messaggi dall'agente
    $item = $null
    while ($sync.UiQueue.TryDequeue([ref]$item)) {
        $type = [string]$item.Type
        $data = $item.Data
        switch ($type) {
            'chat' {
                Clear-LiveBubble
                Add-Bubble ([string]$data.who) ([string]$data.text)
            }
            'chatpartial' {
                if (([string]$data).Trim()) { Add-LiveBubble ([string]$data) }
            }
            'userbubble' {
                # (già mostrato dall'invio locale, se arriva doppio lo ignoriamo)
            }
            'status' {
                $StatusText.Text = [string]$data
            }
            'avatar' {
                Set-AvatarState ([string]$data)
            }
            'speak' {
                if ($sync.Config.voce.risposte_ad_alta_voce) {
                    $say = ConvertTo-SpeechText ([string]$data)
                    Set-AvatarState 'parla'
                    $sync.SpeakingTicks = 0
                    Start-Speak $sync $say
                }
            }
            'tool' {
                Clear-LiveBubble
                Add-Activity ("⚙ " + [string]$data + '...')
                $StatusText.Text = ("ESEGUO: " + [string]$data)
                Show-Onomatopea ''
                Set-AvatarState 'pensa'
            }
            'toolresult' {
                $t = [string]$data.text
                if ($t.Length -gt 260) { $t = $t.Substring(0, 260) + '…' }
                $t = $t -replace "`r?`n", ' '
                Add-Activity ("→ " + [string]$data.name + ': ' + $t)
            }
            'kali_out' {
                if ($KaliOut) { $KaliOut.AppendText([string]$data + "`r`n"); $KaliOut.ScrollToEnd() }
            }
            'kali_tools' {
                if ($KaliTools) {
                    $KaliTools.Children.Clear()
                    $convk = New-Object System.Windows.Media.BrushConverter
                    if ([bool]$data.pronto) {
                        $KaliStatus.Text = 'Kali pronto (WSL). I comandi vengono eseguiti DENTRO Kali Linux.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#39FF14')
                    } else {
                        $KaliStatus.Text = 'Kali non ancora installato. Premi INSTALLA KALI. Nel frattempo i comandi girano in PowerShell.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#FFD24A')
                    }
                    foreach ($t in @($data.lista)) {
                        $riga = New-Object System.Windows.Controls.StackPanel
                        $riga.Orientation = 'Horizontal'
                        $riga.Margin = [System.Windows.Thickness]::new(0, 3, 0, 3)
                        $cb = New-Object System.Windows.Controls.CheckBox
                        $cb.Tag = [string]$t.id
                        $cb.Foreground = $convk.ConvertFromString('#7CFF7C')
                        [void]$riga.Children.Add($cb)
                        $tb = New-Object System.Windows.Controls.TextBlock
                        $stato = 'NON INSTALLATO'
                        if ($t.installato) { $stato = 'INSTALLATO' }
                        $tb.Text = ('  ' + [string]$t.nome + '  [' + $stato + ']  ' + [string]$t.desc)
                        $tb.FontFamily = 'Consolas'
                        $tb.FontSize = 12
                        if ($t.installato) { $tb.Foreground = $convk.ConvertFromString('#39FF14') } else { $tb.Foreground = $convk.ConvertFromString('#C88B8B') }
                        [void]$riga.Children.Add($tb)
                        [void]$KaliTools.Children.Add($riga)
                    }
                }
            }
            'kali_out' {
                if ($KaliOut) { $KaliOut.AppendText([string]$data + "`r`n"); $KaliOut.ScrollToEnd() }
            }
            'kali_tools' {
                if ($KaliTools) {
                    $KaliTools.Children.Clear()
                    $convk = New-Object System.Windows.Media.BrushConverter
                    if ([bool]$data.pronto) {
                        $KaliStatus.Text = 'Kali pronto (WSL). I comandi vengono eseguiti DENTRO Kali Linux.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#39FF14')
                    } else {
                        $KaliStatus.Text = 'Kali non ancora installato. Premi INSTALLA KALI. Nel frattempo i comandi girano in PowerShell.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#FFD24A')
                    }
                    foreach ($t in @($data.lista)) {
                        $riga = New-Object System.Windows.Controls.StackPanel
                        $riga.Orientation = 'Horizontal'
                        $riga.Margin = [System.Windows.Thickness]::new(0, 3, 0, 3)
                        $cb = New-Object System.Windows.Controls.CheckBox
                        $cb.Tag = [string]$t.id
                        $cb.Foreground = $convk.ConvertFromString('#7CFF7C')
                        [void]$riga.Children.Add($cb)
                        $tb = New-Object System.Windows.Controls.TextBlock
                        $stato = 'NON INSTALLATO'
                        if ($t.installato) { $stato = 'INSTALLATO' }
                        $tb.Text = ('  ' + [string]$t.nome + '  [' + $stato + ']  ' + [string]$t.desc)
                        $tb.FontFamily = 'Consolas'
                        $tb.FontSize = 12
                        if ($t.installato) { $tb.Foreground = $convk.ConvertFromString('#39FF14') } else { $tb.Foreground = $convk.ConvertFromString('#C88B8B') }
                        [void]$riga.Children.Add($tb)
                        [void]$KaliTools.Children.Add($riga)
                    }
                }
            }
            'error' {
                Clear-LiveBubble
                Add-Bubble 'zap' ("⚠ " + [string]$data)
            }
        }
    }

    # 3) Ascolto vocale in corso
    try { Update-MicLabel } catch { }
    if ($sync.Listening) {
        $r = Update-Listen $sync
        if ($null -ne $r) {
            $sync.Listening = $false
            $BtnParla.Content = 'PARLA'
            $t = [string]$r.Testo
            $e = [string]$r.Errore
            Set-AvatarState 'neutro'
            # v6: i marcatori stanno nel campo Errore. Prima erano controllati in Testo:
            # per questo i messaggi di aiuto giusti non comparivano mai.
            if ($e -like '!NESSUN_MIC*') {
                Add-Bubble 'zap' ("Non trovo un motore vocale utilizzabile su questo Windows.`n`n" + (Get-SpeechDiagnostica))
                $StatusText.Text = 'MICROFONO NON DISPONIBILE'
            }
            elseif ($e -like '!AUDIO*' -or $e -like '!WINRT*') {
                Add-Bubble 'zap' ("Non riesco a usare il microfono.`nDettaglio: " + $e + "`n`n" + (Get-SpeechDiagnostica))
                $StatusText.Text = 'MICROFONO: CONTROLLA I PERMESSI'
            }
            elseif ($e -like '!ERRORE*') {
                Add-Bubble 'zap' ("Problema col microfono: " + $e + "`n`n" + (Get-SpeechDiagnostica))
                $StatusText.Text = 'MICROFONO: ERRORE'
            }
            elseif ($e -like '!NESSUN_PARLATO*') {
                Add-Bubble 'zap' 'Non ho sentito niente... riprova e parla forte, dopo che compare "TI ASCOLTO"!'
                $StatusText.Text = 'PRONTO!'
            }
            elseif ($t.Trim()) {
                Send-UserText $t
            }
            else {
                Add-Bubble 'zap' 'Non ho sentito niente... riprova e parla forte!'
                $StatusText.Text = 'PRONTO!'
            }
        }
    }

    # 4) Fine del parlato: avatar torna neutro
    if ($sync.AvatarState -eq 'parla' -and $sync.Tts) {
        if ($sync.Tts.State -eq [System.Speech.Synthesis.SynthesizerState]::Speaking) {
            $sync.SpeakingTicks = 0
        }
        else {
            $sync.SpeakingTicks = [int]$sync.SpeakingTicks + 1
            if ($sync.SpeakingTicks -gt 3) {
                Set-AvatarState 'neutro'
                $sync.SpeakingTicks = 0
            }
        }
    }
})

# --------------------------------------------------------------------------
# Avvio
# --------------------------------------------------------------------------

Write-Fase '5/6 voce pronta'
Initialize-Tts $sync
Update-ModeButton
if ($sync.Avatars['neutro']) { $Avatar.Source = $sync.Avatars['neutro'] }
try { Aggiorna-AiCombo } catch { }

# v5: log leggibile, senza segreti (ripulisce anche i log delle sessioni precedenti)
try { Protect-TuttiILog -Base $base | Out-Null } catch { }
try { Start-Transcript -Path (Join-Path $base 'logs\avvio.log') -Append | Out-Null } catch { }
try { Aggiorna-PannelloProgrammi } catch { }
Add-Activity ('— modalità: ' + (Get-ModalitaEtichetta ([string]$sync.Config.sicurezza)) + ' —')

# Riempie i campi impostazioni di default (servono se l'utente apre e salva subito)
$CfgNome.Text     = [string]$sync.Config.nome
$CfgApiBase.Text  = [string]$sync.Config.api_base
$CfgApiKey.Text   = [string]$sync.Config.api_key
$CfgModello.Text  = [string]$sync.Config.modello
foreach ($k in @('thorium','yandex','chrome','edge','brave','firefox')) { [void]$CfgBrowser.Items.Add($k) }
foreach ($k in @('duckduckgo','google','bing','yandex','startpage')) { [void]$CfgMotore.Items.Add($k) }
foreach ($k in @('Segoe UI','Calibri','Consolas','Verdana','Tahoma','Georgia','Trebuchet MS','Arial','Comic Sans MS')) { [void]$AspFont.Items.Add($k) }
foreach ($k in @('11','12','13','14','15','16')) { [void]$AspSize.Items.Add($k) }
try { Add-Activity ('- ' + (Get-AdminStatus) + ' -') } catch { }
$CfgBrowser.Text = [string]$sync.Config.browser
if (-not $CfgBrowser.Text) { $CfgBrowser.Text = 'thorium' }
if ($CfgMotore.Items.Contains([string]$sync.Config.motore_ricerca)) { $CfgMotore.SelectedItem = [string]$sync.Config.motore_ricerca } else { $CfgMotore.SelectedItem = 'duckduckgo' }
try { $ModelInfo.Text = Get-ModelStatusText $sync } catch { }
$BtnScaricaModello.Add_Click({
    Start-ModelPull $sync $CfgModello.Text.Trim()
    $ModelInfo.Text = 'Download avviato: guarda la chat per l esito.'
})

# Avvia l'agente in un runspace dedicato
$agentRs = [runspacefactory]::CreateRunspace()
$agentRs.ApartmentState = 'STA'
$agentRs.ThreadOptions  = 'ReuseThread'
$agentRs.Open()
$agentRs.SessionStateProxy.SetVariable('sync', $sync)
$agentRs.SessionStateProxy.SetVariable('base', $base)

$agentPs = [powershell]::Create()
$agentPs.Runspace = $agentRs
[void]$agentPs.AddScript((Get-Content (Join-Path $base 'brain\agent.ps1') -Raw))
$agentHandle = $agentPs.BeginInvoke()
try { Flush-TaskInCoda } catch { }

# ---- v7.9: TELECOMANDO VOCALE INTEGRATO ----
# All'avvio di ZAP si apre da solo anche "VOCE per ZAP" (dettatura + INVIA) e si chiude
# insieme a ZAP. Si disattiva con -NoVoice oppure con telecomando=$false in config.json.
# A ZAP_VOCE passo la MIA finestra (handle + pid): cosi' la trova sempre, anche se i
# titoli non sono leggibili per via dei privilegi diversi.
$script:VoceProc = $null
function Start-VoceRemoto {
    if ($NoVoice) { return }
    try { if (-not [bool]$sync.Config.voce.telecomando) { return } } catch { }
    $vps = Join-Path $base 'ZAP_VOCE.ps1'
    if (-not (Test-Path $vps)) { return }
    try {
        $hwnd = (New-Object System.Windows.Interop.WindowInteropHelper($Window)).Handle.ToInt64()
        $psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        if (-not (Test-Path $psExe)) { $psExe = 'powershell.exe' }
        $script:VoceProc = Start-Process -FilePath $psExe -PassThru -ArgumentList @(
            '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File', $vps,
            '-ZapHwnd', "$hwnd", '-ZapPid', "$PID")
    } catch { }
}
$timer.Start()
[void]$InputBox.Focus()
Write-Fase '6/6 finestra pronta: apro ZAP'
$Window.Add_ContentRendered({ try { Start-VoceRemoto } catch { } })

try {
    [void]$Window.ShowDialog()
}
finally {
    $sync.Quit = $true
    $timer.Stop()
    Stop-Listen $sync
    Stop-Speak $sync
    try { if ($script:VoceProc -and -not $script:VoceProc.HasExited) { $script:VoceProc.Kill() } } catch { }
    try { $agentPs.Stop() } catch { }
    try { $agentPs.Dispose() } catch { }
    try { $agentRs.Close() } catch { }
    try { Stop-Transcript | Out-Null } catch { }
    try { Protect-TuttiILog -Base $base | Out-Null } catch { }
}
