# ZAP-Gemini v6.6.1 — cosa e' stato corretto (e cosa nella diagnosi era sbagliato)

## Verifiche eseguite dal vivo (prove, non opinioni)
- Chiave Gemini presente nel progetto (prefisso `AQ.`): **funziona**. `GET /v1beta/models`
  con header `x-goog-api-key` -> HTTP 200, 61 modelli. `generateContent` con `gemini-3.6-flash` -> 200.
- I nomi `gemini-3.1-flash-lite`, `gemini-3.5-flash`, `gemini-3.6/3.7/3.8-flash`, `gemini-3-flash-preview`,
  `gemini-flash-latest`, `gemini-flash-lite-latest`, `gemini-pro-latest`: **esistono**.
- `gemini-2.0-flash` -> 404 "no longer available"; `gemini-1.5-flash` -> 404. Quindi la "correzione"
  che suggeriva di usare quei due nomi avrebbe rotto il progetto.
- Alcuni modelli rispondono 503 (sovraccarico temporaneo) o 429 (quota): e' questa la causa reale
  degli errori intermittenti e della lentezza, non i nomi dei modelli.
- I tre file `ui/avatar/robot*.png` erano byte-identici (stesso md5, 259.042 byte).

## Checklist dei requisiti
| # | Requisito | Stato | Dove |
|---|-----------|-------|------|
| 1 | `config.json` senza BOM | fatto | `config.json` (verifica byte iniziali) |
| 2 | Chiave non duplicata, segreti fuori dal file condiviso | fatto | `config.local.json` + `.gitignore` |
| 3 | Fallback con modelli REALI | fatto | `config.json` + `brain/llm.ps1` |
| 4 | `api_base` non punta a Ollama | fatto | `config.json` (`api_base: ""`) |
| 5 | `provider_ai`: 14 -> 2 attivi (gemini, openai) | fatto | `config.json` |
| 6 | Avatar distinti (neutro/parla/pensa) | fatto | `ui/avatar/*.png` |
| 7 | Timeout ridotti | fatto | `timeout_powershell_sec 30`, `ascolto_secondi 6`, sonda Ollama 1500 ms |
| 8 | Risposta in streaming | fatto | `brain/llm.ps1` (`streamGenerateContent?alt=sse`) + bolla live in `AVVIA.ps1` |
| 9 | OpenAI aggiunto (Bearer) | fatto | `config.json` + `config.local.json` |
| 10 | BAT con CRLF, percorsi quotati, avvio dalla cartella, prerequisiti | gia' presenti | `AVVIA.bat` e compagni |
| 11 | Log senza segreti | gia' presente, mantenuto | `brain/log.ps1` |

## Come si usa
1. Doppio clic su `AVVIA.bat` (o `AVVIA_DEBUG.bat` se qualcosa non parte).
2. Le chiavi stanno in `config.local.json`. Se manca la chiave di un servizio, quel servizio
   risulta "non pronto" e viene semplicemente saltato (nessun giro a vuoto).
3. Prova rapida del cervello IA: `DIAGNOSTICA.bat` oppure
   `powershell -NoProfile -File tests\selftest.ps1`.

## Nota di sicurezza
La chiave OpenAI di questo progetto e' stata condivisa in chat: va considerata compromessa.
Prima di usarla davvero, rigenerala su https://platform.openai.com/api-keys e incolla la nuova
in `config.local.json` (campo `provider_ai.openai.chiave`). Se condividi lo ZIP, togli
`config.local.json` oppure ruota entrambe le chiavi.
