@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ZAP - Installa Kali Linux (WSL2)

if not exist "%~dp0installa_kali.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca il file installa_kali.ps1 accanto a questo file.
  echo  Cartella: %~dp0
  echo.
  pause
  exit /b 1
)

echo.
echo  ============================================================
echo   ZAP - INSTALLA KALI LINUX (via WSL2)
echo  ============================================================
echo   Richiede i permessi di AMMINISTRATORE.
echo.
echo   Se non succede nulla, chiudi e fai:
echo     tasto destro su INSTALLA_KALI.bat -^> "Esegui come amministratore".
echo  ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installa_kali.ps1" -Pausa

echo.
echo  [ZAP] Operazione conclusa. Log completo: logs\kali_install.log
echo.
pause
endlocal
