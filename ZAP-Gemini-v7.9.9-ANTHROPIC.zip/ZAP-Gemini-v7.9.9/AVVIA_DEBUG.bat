@echo off
setlocal
cd /d "%~dp0"
title ZAP - DEBUG (questa finestra NON si chiude)
where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo.
  pause
  exit /b 1
)
if not exist "%~dp0AVVIA.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca AVVIA.ps1 accanto a questo .bat (cartella: %~dp0^)
  echo.
  pause
  exit /b 1
)
echo.
echo  Avvio ZAP in modalita DEBUG.
echo  Se ci sono errori restano scritti qui e NON si chiude niente.
echo.
powershell -NoProfile -STA -ExecutionPolicy Bypass -NoExit -File "%~dp0AVVIA.ps1"
endlocal
