@echo off
setlocal
cd /d "%~dp0"
title ZAP - Test completi v6.2
set "LOG=%~dp0logs\test_v5.log"
if not exist "%~dp0logs" mkdir "%~dp0logs"
if exist "%LOG%" del "%LOG%"

where powershell >nul 2>&1
if errorlevel 1 (
  echo  [ZAP] ERRORE: PowerShell non trovato.
  pause
  exit /b 1
)
for %%F in ("verifica_progetto.ps1" "test_v5.ps1" "test_ai.ps1" "test_voce.ps1" "selftest.ps1") do (
  if not exist "%~dp0tests\%%~F" (
    echo  [ZAP] ERRORE: manca tests\%%~F
    pause
    exit /b 1
  )
)

echo === ZAP - Test completi (log in logs\test_v5.log) ===
echo.
echo [1/5] Integrita del progetto (file, sintassi, XAML, config, segreti)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\verifica_progetto.ps1" >> "%LOG%" 2>&1
echo [2/5] Moduli (autonomia, programmi, controllo PC, tema, log, allegati)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\test_v5.ps1" >> "%LOG%" 2>&1
echo [3/5] Intelligenze AI (registro, router, chiavi nei log)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\test_ai.ps1" >> "%LOG%" 2>&1
echo [4/5] Voce e microfono (motore moderno/storico + stati di errore)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\test_voce.ps1" >> "%LOG%" 2>&1
echo [5/5] Selftest generale...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\selftest.ps1" >> "%LOG%" 2>&1
echo.
type "%LOG%"
echo.
echo === Risultati: cerca le righe RISULTATO e FAIL qui sopra ===
pause
endlocal
