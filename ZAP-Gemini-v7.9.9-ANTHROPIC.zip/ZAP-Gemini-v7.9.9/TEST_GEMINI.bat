@echo off
setlocal
cd /d "%~dp0"
title ZAP - Test cervello Gemini
set "LOG=%~dp0logs\test_gemini.log"
if not exist "%~dp0logs" mkdir "%~dp0logs"
where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo.
  pause
  exit /b 1
)
if not exist "%~dp0tests\test_gemini.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca tests\test_gemini.ps1 (cartella: %~dp0^)
  echo.
  pause
  exit /b 1
)
echo.
echo  Provo il cervello Gemini... (log in logs\test_gemini.log)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\test_gemini.ps1" > "%LOG%" 2>&1
type "%LOG%"
echo.
pause
endlocal
