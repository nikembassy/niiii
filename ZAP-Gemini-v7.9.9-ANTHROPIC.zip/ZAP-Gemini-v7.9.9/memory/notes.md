# Memoria di ZAP

Qui ZAP scrive ciò che ricorda di te: nome, preferenze, abitudini, progetti.
Puoi chiedergli: "ricorda che..." oppure "cosa ricordi di me?".
Puoi anche modificare questo file a mano: ZAP lo rilegge ad ogni nuova richiesta.

---
- [2026-09-28 21:51] Imparato guardando lo schermo: Ecco l'analisi della procedura basata sullo screenshot:

**1) Cosa si vede**
*   **Sinistra:** Browser (Chrome/Edge) con una pagina di Stripchat aperta. È attivo il pannello "Strumenti per sviluppatori" (DevTools) sulla scheda "Elements", che mostra il codice HTML della pagina e i metadati del video (es. `data-video-id`).
*   **Destra:** Interfaccia di un assistente AI ("ZAP AI") che sta dialogando con l'utente per analizzare il link fornito e pianificare il download del contenuto multimediale.

**2) Passaggi per rifarlo**
1.  **Ispezione:** Aprire la pagina web contenente il video.
2.  **DevTools:** Premere `F12` (o tasto destro > "Ispeziona") per aprire gli strumenti per sviluppatori.
3.  **Analisi:** Navigare nel DOM (scheda "Elements") per individuare il tag `<video>` o i metadati associati (come l'ID del video o l'URL sorgente).
4.  **Estrazione:** Copiare l'URL o l'ID e fornirlo all'assistente AI.
5.  **Esecuzione:** L'AI analizza il link, verifica se il contenuto è pubblico o protetto e, se possibile, utilizza strumenti come `yt-dlp` per scaricare il file.

**3) Programmi o percorsi usati**
*   **Browser:** Google Chrome o Microsoft Edge (con DevTools integrato).
*   **Strumento di analisi:** Pannello "Elements" dei DevTools per l'ispezione del codice sorgente.
*   **Strumento di download (ipotizzato dall'AI):** `yt-dlp` (libreria a riga di comando per il download di contenuti multimediali).
