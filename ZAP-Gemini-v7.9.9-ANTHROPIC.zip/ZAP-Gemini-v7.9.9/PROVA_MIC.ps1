﻿# PROVA_MIC.ps1 -- Dice ESATTAMENTE quale motore vocale funziona e perché il microfono non ti sente.
# Uso:  powershell -NoProfile -ExecutionPolicy Bypass -File .\PROVA_MIC.ps1
param([int]$Secondi = 8)

$ErrorActionPreference = 'Continue'

# Usa le STESSE funzioni di ZAP: cosi' la prova dice davvero se ZAP potra' funzionare.
$base = $PSScriptRoot
. (Join-Path $base 'voice\stt.ps1')

function Riga($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }

Riga ''
Riga '=== ZAP! Prova microfono (v6.1) ===' 'Yellow'
Riga ('Windows    : ' + [System.Environment]::OSVersion.VersionString)
Riga ('PowerShell : ' + $PSVersionTable.PSVersion)
Riga ''

# --- 1. Motore MODERNO di Windows ---
Riga '1) Motore MODERNO di Windows (Windows.Media.SpeechRecognition)' 'Cyan'
$winrtOk = $false
if (Initialize-VoceWinRT) {
    $r = New-VoceWinRT 'it-IT'
    if ($r) {
        $winrtOk = $true
        Riga '   OK: riuscito a creare il riconoscitore.' 'Green'
        try { Riga ('   lingua usata: ' + [string]$r.CurrentLanguage.LanguageTag) } catch { }
        try { $r.Dispose() } catch { }
    } else {
        Riga '   NON disponibile: non riesco a creare il riconoscitore per l italiano.' 'Yellow'
        Riga '   Vuol dire che manca il pacchetto lingua italiano con il riconoscimento vocale.' 'Yellow'
    }
} else {
    Riga ('   NON caricabile: ' + $script:VoceWinRTErrore) 'Yellow'
}
Riga ''

# --- 2. Motore STORICO di Windows ---
Riga '2) Motore STORICO di Windows (System.Speech, quello vecchio)' 'Cyan'
$recs = @()
try { $recs = @([System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()) } catch { }
if ($recs.Count -eq 0) {
    Riga '   nessun riconoscitore elencato dal sistema'
} else {
    foreach ($x in $recs) { Riga ('   elencato: ' + $x.Culture.Name + '  ' + $x.Description) }
}
$leg = New-VoceLegacy 'it-IT'
if ($leg.Engine) {
    Riga ('   costruzione del motore: OK (' + $leg.Modo + ')') 'Green'
    try { $leg.Engine.Dispose() } catch { }
} else {
    Riga '   costruzione del motore: FALLITA' 'Red'
    if ($leg.Errore) { Riga ('      -> ' + $leg.Errore) 'Red' }
    if ($recs.Count -gt 0) {
        Riga '   Nota: i riconoscitori sono ELENCATI ma il motore non si crea. Su Windows 11 il' 'Yellow'
        Riga '   vecchio riconoscimento vocale di Windows e stato ritirato: e un limite di Windows.' 'Yellow'
    }
}
Riga ''

if (-not $winrtOk -and -not $leg.Engine) {
    Riga 'ESITO: nessuno dei due motori vocali e utilizzabile su questo PC.' 'Red'
    Riga 'Senza un motore vocale Windows, ZAP non puo ascoltarti: usa la tastiera.' 'Red'
    Riga ''
    Riga (Get-SpeechDiagnostica)
    exit 1
}
if ($winrtOk) { Riga 'ZAP usera il motore MODERNO.' 'Green' } else { Riga 'ZAP usera il motore STORICO (vecchio).' 'Yellow' }
Riga ''

# --- 3. Prova dal vivo ---
Riga ("3) Prova dal vivo: PARLA ORA per $Secondi secondi!") 'Yellow'
Riga '   (con il motore moderno la barretta del livello non si muove: guarda lo stato a destra)' 'Gray'
$sync = [hashtable]::Synchronized(@{})
$sync.Listening = $true
Start-Listen -sync $sync -Culture 'it-IT' -TimeoutSec $Secondi
$fine = (Get-Date).AddSeconds($Secondi + 10)
$testo = ''
$errore = ''
$livMax = 0
while ((Get-Date) -lt $fine) {
    $lv = 0
    try { $lv = [int]$sync.ListenLivello } catch { }
    if ($lv -gt $livMax) { $livMax = $lv }
    $bar = ('#' * [int]($lv / 4))
    $st = ''
    try { $st = [string]$sync.ListenStato } catch { }
    Write-Host ("`r   livello: {0,3}  {1,-25}  {2,-40}" -f $lv, $bar, $st) -NoNewline
    $r = $null
    try { $r = Update-Listen $sync } catch { }
    if ($r) { $testo = [string]$r.Testo; $errore = [string]$r.Errore; break }
    Start-Sleep -Milliseconds 100
}
Write-Host ''
Stop-Listen $sync
Riga ''
Riga ('Livello massimo registrato: ' + $livMax + ' / 100  (0 = motore moderno o nessun suono)')

# --- 4. Verdetto ---
if ($testo) {
    Riga ('TESTO RICONOSCIUTO: "' + $testo + '"') 'Green'
    Riga 'ESITO: la voce FUNZIONA. In ZAP premi PARLA e parla dopo che compare "TI ASCOLTO".' 'Green'
    exit 0
}
if ($errore) { Riga ('Dettaglio dall ultimo tentativo: ' + $errore) 'Yellow' }
if ($errore -like '!AUDIO*' -or $errore -like '!WINRT*') {
    Riga 'ESITO: il motore vocale risponde ma l ascolto non parte (permessi o microfono).' 'Red'
    Riga 'RIMEDIO: Impostazioni -> Privacy e sicurezza -> Microfono: attiva "Microfono" e' 'Red'
    Riga '         "Consenti alle app desktop di accedere al microfono", poi riprova.' 'Red'
    exit 2
}
if ($livMax -le 2) {
    Riga 'ESITO: nessuna parola riconosciuta (o nessun suono arrivato).' 'Yellow'
    Riga 'RIMEDIO: controlla il microfono fisico, il muto e il volume di ingresso; poi riprova.' 'Yellow'
    exit 3
}
Riga 'ESITO: dal microfono arriva suono, ma Windows non riconosce le parole.' 'Yellow'
Riga 'RIMEDIO: parla piu vicino al microfono; verifica il pacchetto lingua Italiano (punto 1).' 'Yellow'
exit 3
