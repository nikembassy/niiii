﻿# stt.ps1 -- Riconoscimento vocale (v6.1) -- usa il motore MODERNO di Windows.
#
# PERCHE' E' STATO RISCRITTO
# Il vecchio "System.Speech" (riconoscimento vocale desktop di Windows) su Windows 11 e'
# stato ritirato da Microsoft (sostituito da "Accesso vocale" a partire dalla 22H2, set 2024).
# I riconoscitori restano ELENCATI nel registro, ma il motore non si riesce piu' a creare:
# e' esattamente l'errore "Impossibile trovare un riconoscimento con l'ID richiesto".
# Ora ZAP prova PRIMA il motore moderno (Windows.Media.SpeechRecognition, lo stesso usato
# dalla dettatura di Windows) e solo se non e' disponibile ripiega su quello storico.
#
# Contratto usato dall'interfaccia (invariato):
#   Test-SpeechAvailable                       -> bool
#   Get-SpeechDiagnostica                      -> testo della diagnosi
#   Start-Listen -sync -Culture -TimeoutSec    -> avvia l'ascolto (NON blocca)
#   Update-Listen -sync                        -> $null mentre ascolta, altrimenti @{Testo;Errore}
#   Stop-Listen -sync                          -> ferma e libera il microfono
#   Get-ListenResult -sync                     -> compatibilita': risultato pronto (o $null)
#
# Marcatori di errore: !NESSUN_MIC, !AUDIO:<dettaglio>, !WINRT:<dettaglio>, !ERRORE:<dettaglio>,
#                      !NESSUN_PARLATO

Add-Type -AssemblyName System.Speech -ErrorAction SilentlyContinue

$script:VoceWinRTTestato = $false
$script:VoceWinRTOk      = $false
$script:VoceWinRTErrore  = ''

function Initialize-VoceWinRT {
    # Carica i tipi WinRT del motore moderno. Si prova una volta sola.
    if ($script:VoceWinRTTestato) { return $script:VoceWinRTOk }
    $script:VoceWinRTTestato = $true
    $script:VoceWinRTErrore = ''
    try {
        $null = [Windows.Media.SpeechRecognition.SpeechRecognizer, Windows.Media.SpeechRecognition, ContentType=WindowsRuntime]
        $null = [Windows.Media.SpeechRecognition.SpeechRecognitionResult, Windows.Media.SpeechRecognition, ContentType=WindowsRuntime]
        $null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
        $script:VoceWinRTOk = $true
    } catch {
        $script:VoceWinRTOk = $false
        $script:VoceWinRTErrore = $_.Exception.Message
    }
    return $script:VoceWinRTOk
}

function New-VoceWinRT {
    # Crea il riconoscitore moderno. Prima per lingua, poi quello predefinito.
    param([string]$Culture = 'it-IT')
    if (-not (Initialize-VoceWinRT)) { return $null }
    $lingua = $null
    try { $lingua = [Windows.Globalization.Language]::new($Culture) } catch { $lingua = $null }
    if ($lingua) {
        try { return [Windows.Media.SpeechRecognition.SpeechRecognizer]::new($lingua) } catch { }
    }
    try { return [Windows.Media.SpeechRecognition.SpeechRecognizer]::new() } catch { }
    return $null
}

function New-VoceLegacy {
    # Motore storico. Prova i tre costruttori disponibili: su alcuni PC solo uno funziona.
    param([string]$Culture = 'it-IT')
    $tentativi = @()
    try {
        $c = [System.Globalization.CultureInfo]::GetCultureInfo($Culture)
        $e = New-Object System.Speech.Recognition.SpeechRecognitionEngine($c)
        return @{ Engine = $e; Modo = ('lingua ' + $Culture); Errore = '' }
    } catch { $tentativi += ('per lingua: ' + $_.Exception.Message) }
    try {
        $recs = @([System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers())
        if ($recs.Count -gt 0) {
            $pref = ([string]$Culture).Split('-')[0]
            $scelto = $null
            foreach ($r in $recs) { if ($r.Culture.Name -eq $Culture) { $scelto = $r; break } }
            if (-not $scelto) { foreach ($r in $recs) { if ($r.Culture.Name -like ($pref + '*')) { $scelto = $r; break } } }
            if (-not $scelto) { $scelto = $recs[0] }
            $e = New-Object System.Speech.Recognition.SpeechRecognitionEngine($scelto)
            return @{ Engine = $e; Modo = ('riconoscitore ' + $scelto.Culture.Name); Errore = '' }
        }
        $tentativi += 'nessun riconoscitore elencato dal sistema'
    } catch { $tentativi += ('dal riconoscitore elencato: ' + $_.Exception.Message) }
    try {
        $e = New-Object System.Speech.Recognition.SpeechRecognitionEngine
        return @{ Engine = $e; Modo = 'predefinito'; Errore = '' }
    } catch { $tentativi += ('predefinito: ' + $_.Exception.Message) }
    return @{ Engine = $null; Modo = ''; Errore = ($tentativi -join ' | ') }
}

function Get-RiconoscitoreMigliore {
    param([string]$Culture = 'it-IT')
    try {
        $recs = @([System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers())
        if ($recs.Count -eq 0) { return $null }
        $pref = ([string]$Culture).Split('-')[0]
        foreach ($r in $recs) { if ($r.Culture.Name -eq $Culture) { return $r } }
        foreach ($r in $recs) { if ($r.Culture.Name -like ($pref + '*')) { return $r } }
        return $recs[0]
    } catch { return $null }
}

function Test-SpeechAvailable {
    # Vero solo se ALMENO uno dei due motori si riesce davvero a creare.
    try {
        $r = New-VoceWinRT 'it-IT'
        if ($r) { try { $r.Dispose() } catch { }; return $true }
    } catch { }
    $leg = New-VoceLegacy 'it-IT'
    if ($leg.Engine) { try { $leg.Engine.Dispose() } catch { }; return $true }
    return $false
}

function Get-SpeechDiagnostica {
    $righe = @()
    $righe += 'DIAGNOSI MICROFONO'
    $righe += ('Windows   : ' + [System.Environment]::OSVersion.VersionString)
    $righe += ('PowerShell: ' + $PSVersionTable.PSVersion)
    $righe += ''
    $righe += '1) Motore MODERNO di Windows (Windows.Media.SpeechRecognition)'
    if (Initialize-VoceWinRT) {
        $r = New-VoceWinRT 'it-IT'
        if ($r) {
            $righe += '   disponibile: SI (e questo il motore che ZAP usa)'
            try { $righe += ('   lingua usata: ' + [string]$r.CurrentLanguage.LanguageTag) } catch { }
            try { $righe += ('   lingua vocale del sistema: ' + [string][Windows.Media.SpeechRecognition.SpeechRecognizer]::SystemSpeechLanguage.LanguageTag) } catch { }
            try { $r.Dispose() } catch { }
        } else {
            $righe += '   disponibile: NO (non riesco a creare il riconoscitore per questa lingua)'
        }
    } else {
        $righe += ('   non caricabile: ' + $script:VoceWinRTErrore)
        $righe += '   (su Windows 10/11 con .NET Framework aggiornato e disponibile)'
    }
    $righe += ''
    $righe += '2) Motore STORICO di Windows (System.Speech)'
    try {
        $recs = @([System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers())
        if ($recs.Count -eq 0) {
            $righe += '   nessun riconoscitore elencato'
        } else {
            foreach ($x in $recs) { $righe += ('   elencato: ' + $x.Culture.Name + '  ' + $x.Description) }
        }
    } catch { $righe += ('   non leggibile: ' + $_.Exception.Message) }
    $leg = New-VoceLegacy 'it-IT'
    if ($leg.Engine) {
        $righe += ('   costruzione del motore: OK (' + $leg.Modo + ')')
        try { $leg.Engine.Dispose() } catch { }
    } else {
        $righe += ('   costruzione del motore: FALLITA -> ' + $leg.Errore)
    }
    $righe += ''
    $righe += '3) Cosa fare (in ordine)'
    $righe += '   a) Impostazioni -> Privacy e sicurezza -> Microfono: attiva "Microfono" e'
    $righe += '      "Consenti alle app desktop di accedere al microfono".'
    $righe += '   b) Impostazioni -> Data e ora e lingua -> Lingua e area: nella lingua Italiano'
    $righe += '      aggiungi il pacchetto "Riconoscimento vocale" (Scarica opzioni lingua).'
    $righe += '   c) Su Windows 11 il vecchio riconoscimento vocale di Windows e ritirato: ZAP usa'
    $righe += '      il motore moderno. Se anche questo non e disponibile, manca il pacchetto lingua.'
    $righe += '   d) Prova completa con livello del microfono: PROVA_MIC.bat'
    return ($righe -join "`n")
}

function Stop-Listen {
    param($sync)
    if (-not $sync) { return }
    try { $sync.ListenStop = $true } catch { }
    # motore storico: eventi e motore
    foreach ($nome in @('MicSidLevel', 'MicSidDet', 'MicSidRec')) {
        try {
            $sid = [string]$sync.$nome
            if ($sid) { Unregister-Event -SourceIdentifier $sid -ErrorAction SilentlyContinue }
            $sync.$nome = ''
        } catch { }
    }
    try { $sync.MicModo = 'spento' } catch { }
    try {
        if ($sync.MicEngine) {
            if ($sync.MicOperazione) { try { $null = $sync.MicEngine.StopRecognitionAsync() } catch { } }
            try { $sync.MicEngine.RecognizeAsyncCancel() } catch { }
            try { $sync.MicEngine.Dispose() } catch { }
        }
    } catch { }
    try { $sync.MicEngine = $null } catch { }
    try { $sync.MicOperazione = $null } catch { }
    try { $sync.MicAttivo = $false } catch { }
    try { $sync.MicTesto = '' } catch { }
    try { $sync.ListenLivello = 0 } catch { }
    try { $sync.ListenStato = 'spento' } catch { }
}

function Start-Listen {
    # Avvia l'ascolto senza bloccare l'interfaccia. Il lavoro vero lo segue Update-Listen,
    # chiamata dal timer della finestra.
    param($sync, [string]$Culture = 'it-IT', [int]$TimeoutSec = 12)

    Stop-Listen $sync
    try {
        $sync.ListenStop    = $false
        $sync.ListenResult  = $null
        $sync.ListenLivello = 0
        $sync.MicTesto      = ''
        $sync.MicAttivo     = $false
        $sync.MicModo       = 'spento'
        $sync.MicFase       = ''
        $sync.MicOperazione = $null
        $sync.MicErrWinRT   = ''
        $sync.MicErrLegacy  = ''
        $sync.MicTimeout    = [int]$TimeoutSec
        $sync.MicInizio     = Get-Date
        $sync.MicUltimoSuono = Get-Date
    } catch { }

    # ----- 1) motore MODERNO di Windows (scelta preferita) -----
    $rec = $null
    try { $rec = New-VoceWinRT $Culture } catch { }
    if ($rec) {
        try {
            try {
                $rec.Timeouts.InitialSilenceTimeout = [TimeSpan]::FromSeconds(6)
                $rec.Timeouts.EndSilenceTimeout     = [TimeSpan]::FromSeconds(1)
                $rec.Timeouts.BabbleTimeout         = [TimeSpan]::FromSeconds(0)
            } catch { }
            $sync.MicEngine     = $rec
            $sync.MicModo       = 'winrt'
            $sync.MicFase       = 'compila'
            $sync.MicOperazione = $rec.CompileConstraintsAsync()
            $sync.MicAttivo     = $true
            $sync.ListenStato   = 'in ascolto (motore moderno di Windows)'
            return
        } catch {
            try { $sync.MicErrWinRT = $_.Exception.Message } catch { }
            try { $rec.Dispose() } catch { }
            try { $sync.MicEngine = $null; $sync.MicModo = 'spento'; $sync.MicAttivo = $false } catch { }
        }
    }

    # ----- 2) motore STORICO di Windows -----
    $leg = New-VoceLegacy $Culture
    if ($leg.Engine) {
        try {
            $leg.Engine.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
            $leg.Engine.SetInputToDefaultAudioDevice()
            $guid = [guid]::NewGuid().ToString('N')
            $sync.MicSidLevel = 'ZapMicLevel_' + $guid
            $sync.MicSidDet   = 'ZapMicDet_'   + $guid
            $sync.MicSidRec   = 'ZapMicRec_'   + $guid
            [void](Register-ObjectEvent -InputObject $leg.Engine -EventName AudioLevelUpdated -SourceIdentifier $sync.MicSidLevel)
            [void](Register-ObjectEvent -InputObject $leg.Engine -EventName SpeechDetected     -SourceIdentifier $sync.MicSidDet)
            [void](Register-ObjectEvent -InputObject $leg.Engine -EventName SpeechRecognized   -SourceIdentifier $sync.MicSidRec)
            $leg.Engine.RecognizeAsync([System.Speech.Recognition.RecognizeMode]::Multiple)
            $sync.MicEngine   = $leg.Engine
            $sync.MicModo     = 'storico'
            $sync.MicAttivo   = $true
            $sync.ListenStato = ('in ascolto (' + $leg.Modo + ')')
            return
        } catch {
            try { $sync.MicErrLegacy = $_.Exception.Message } catch { }
            try { $leg.Engine.Dispose() } catch { }
            try { $sync.MicEngine = $null; $sync.MicModo = 'spento'; $sync.MicAttivo = $false } catch { }
        }
    } else {
        try { $sync.MicErrLegacy = $leg.Errore } catch { }
    }

    # ----- 3) nessun motore utilizzabile -----
    try {
        $sync.ListenStato  = 'nessun riconoscitore vocale utilizzabile'
        $sync.ListenResult = @{ Testo = ''; Errore = '!NESSUN_MIC' }
    } catch { }
}

function Update-ListenWinRT {
    # Segue le due operazioni asincrone del motore moderno dal timer:
    # prima la compilazione, poi il riconoscimento. Nessun blocco, nessun thread.
    param($sync)
    $op = $sync.MicOperazione
    if (-not $op) {
        $r = @{ Testo = ''; Errore = '!ERRORE:operazione vocale assente' }
        Stop-Listen $sync
        return $r
    }

    $stato = ''
    try { $stato = [string]$op.Status } catch { $stato = 'Error' }

    if ($stato -eq 'Started') {
        if (((Get-Date) - $sync.MicInizio).TotalSeconds -gt ([int]$sync.MicTimeout + 10)) {
            Stop-Listen $sync
            return @{ Testo = ''; Errore = '!NESSUN_PARLATO' }
        }
        return $null
    }

    if ($stato -eq 'Error') {
        $msg = 'errore non specificato'
        try { if ($op.ErrorCode -and $op.ErrorCode.Message) { $msg = [string]$op.ErrorCode.Message } } catch { }
        try { if ($msg -eq 'errore non specificato') { $msg = [string]$op.ErrorCode } } catch { }
        Stop-Listen $sync
        return @{ Testo = ''; Errore = ('!AUDIO:' + $msg) }
    }

    # Completed / Canceled
    $res = $null
    try { $res = $op.GetResults() } catch { }

    if ($sync.MicFase -eq 'compila') {
        $esito = ''
        try { $esito = [string]$res.Status } catch { }
        if ($esito -ne 'Success') {
            Stop-Listen $sync
            return @{ Testo = ''; Errore = ('!WINRT:preparazione non riuscita (' + $esito + ')') }
        }
        try {
            $sync.MicOperazione = $sync.MicEngine.RecognizeAsync()
            $sync.MicFase       = 'ascolta'
            $sync.MicInizio     = Get-Date
            $sync.ListenStato   = 'TI ASCOLTO: parla pure'
            return $null
        } catch {
            $msg = $_.Exception.Message
            Stop-Listen $sync
            return @{ Testo = ''; Errore = ('!AUDIO:' + $msg) }
        }
    }

    # fase 'ascolta' completata
    $testo = ''
    $esito = ''
    try { $testo = [string]$res.Text } catch { }
    try { $esito = [string]$res.Status } catch { }
    Stop-Listen $sync
    if ($testo.Trim()) { return @{ Testo = $testo.Trim(); Errore = '' } }
    if ($esito -eq 'MicrophoneUnavailable') {
        return @{ Testo = ''; Errore = '!AUDIO:il microfono non e disponibile o ZAP non ha il permesso di usarlo' }
    }
    if ($esito -eq 'NetworkFailure') {
        return @{ Testo = ''; Errore = '!AUDIO:serve la connessione a internet per il riconoscimento vocale' }
    }
    return @{ Testo = ''; Errore = '!NESSUN_PARLATO' }
}

function Update-Listen {
    param($sync)
    if (-not $sync) { return $null }

    if (-not $sync.MicAttivo) {
        $r = $null
        try { $r = $sync.ListenResult } catch { return $null }
        if ($null -eq $r) { return $null }
        try { $sync.ListenResult = $null } catch { }
        return $r
    }

    if ($sync.MicModo -eq 'winrt') { return (Update-ListenWinRT $sync) }

    # --- motore storico: svuota la coda degli eventi di questo runspace ---
    $sidL = [string]$sync.MicSidLevel
    $sidD = [string]$sync.MicSidDet
    $sidR = [string]$sync.MicSidRec
    $finito = $false

    foreach ($ev in @(Get-Event -ErrorAction SilentlyContinue)) {
        $sid = [string]$ev.SourceIdentifier
        if ($sid -ne $sidL -and $sid -ne $sidD -and $sid -ne $sidR) { continue }
        try {
            if ($sid -eq $sidL) {
                $sync.ListenLivello = [int]$ev.SourceEventArgs.AudioLevel
            } elseif ($sid -eq $sidD) {
                $sync.MicUltimoSuono = Get-Date
                $sync.ListenStato = 'ti ho sentito, continua...'
            } elseif ($sid -eq $sidR) {
                $rr = $ev.SourceEventArgs.Result
                $testo = ''
                try { $testo = [string]$rr.Text } catch { }
                if ($testo.Trim()) {
                    if ([string]$sync.MicTesto) { $sync.MicTesto = ([string]$sync.MicTesto) + ' ' + $testo.Trim() }
                    else { $sync.MicTesto = $testo.Trim() }
                    $sync.MicUltimoSuono = Get-Date
                }
            }
        } catch { }
        Remove-Event -EventIdentifier $ev.EventIdentifier -ErrorAction SilentlyContinue
    }

    if ([string]$sync.MicTesto) {
        if (((Get-Date) - $sync.MicUltimoSuono).TotalSeconds -gt 2) { $finito = $true }
    }
    if (-not $finito) {
        if ($sync.ListenStop) { $finito = $true }
        elseif (((Get-Date) - $sync.MicInizio).TotalSeconds -gt [int]$sync.MicTimeout) { $finito = $true }
        elseif (((Get-Date) - $sync.MicUltimoSuono).TotalSeconds -gt 6) { $finito = $true }
    }
    if (-not $finito) { return $null }

    $testo = [string]$sync.MicTesto
    $annullato = [bool]$sync.ListenStop
    Stop-Listen $sync
    if ($testo) { return @{ Testo = $testo; Errore = '' } }
    if ($annullato) { return $null }
    return @{ Testo = ''; Errore = '!NESSUN_PARLATO' }
}

function Get-ListenResult {
    # Compatibilita' con il vecchio nome.
    param($sync)
    if (-not $sync) { return $null }
    if ($sync.MicAttivo) { return $null }
    $r = $null
    try { $r = $sync.ListenResult } catch { return $null }
    if ($null -eq $r) { return $null }
    try { $sync.ListenResult = $null } catch { }
    return $r
}
