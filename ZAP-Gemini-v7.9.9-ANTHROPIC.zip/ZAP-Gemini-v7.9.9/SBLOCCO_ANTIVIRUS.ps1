﻿# SBLOCCO_ANTIVIRUS.ps1 -- ZAP viene bloccato dall'antivirus: lo sblocchiamo.
# Uso: tasto destro sul file -> "Esegui con PowerShell"
#      oppure:  powershell -NoProfile -ExecutionPolicy Bypass -File .\SBLOCCO_ANTIVIRUS.ps1
#
# PERCHE' SUCCEDE (falso positivo, non un virus)
#   ZAP e' un assistente che scrive ed esegue comandi PowerShell per te: e' la sua
#   funzione principale. Alcuni antivirus vedono "uno script che esegue altri script"
#   e lo marcano per prudenza. Il file segnalato contiene solo il motore di ZAP.
#
# COSA FA QUESTO SCRIPT
#   1) sblocca i file scaricati (toglie il "blocco" di Windows, Mark-of-the-Web);
#   2) mostra se la cartella di ZAP e' gia' fra le esclusioni;
#   3) propone di aggiungerla (serve essere amministratore: lo chiede da solo).

param(
    [switch]$Rimuovi,          # toglie l'esclusione creata in precedenza
    [switch]$SoloControllo     # mostra la situazione e non cambia nulla
)

$ErrorActionPreference = 'Continue'
$base = $PSScriptRoot

function Riga($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Titolo($t) { Write-Host ''; Write-Host ('=== ' + $t + ' ===') -ForegroundColor Yellow }

Titolo 'ZAP - Sblocco dall antivirus (falso positivo)'
Riga ('Cartella ZAP: ' + $base)
Riga ''

# --- 1) togliere il blocco dei file scaricati -----------------------------
Titolo '1. Blocco dei file scaricati (Mark-of-the-Web)'
try {
    Get-ChildItem -Path $base -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    Riga '   Fatto: i file non sono piu marcati come "scaricati da internet".' 'Green'
} catch {
    Riga ('   Non riuscito: ' + $_.Exception.Message) 'Yellow'
}

# --- 2) situazione delle esclusioni --------------------------------------
Titolo '2. Windows Defender'
$defenderAttivo = $false
try {
    $st = Get-MpComputerStatus -ErrorAction Stop
    $defenderAttivo = $true
    Riga ('   Defender presente. Protezione in tempo reale: ' + $st.RealTimeProtectionEnabled)
    $pref = Get-MpPreference
    $escluso = $false
    foreach ($p in @($pref.ExclusionPath)) {
        if ($p) {
            try { if ($base.TrimEnd('\') -like ($p.TrimEnd('\') + '*')) { $escluso = $true } } catch { }
        }
    }
    if ($escluso) { Riga ('   La cartella di ZAP e GIA esclusa: ' + $base) 'Green' }
    else          { Riga  '   La cartella di ZAP NON e esclusa.' 'Yellow' }
} catch {
    $defenderAttivo = $false
    Riga '   Windows Defender non risponde: probabilmente hai un antivirus diverso.' 'Yellow'
    Riga ('   Dettaglio: ' + $_.Exception.Message)
}
Riga ''

# --- 3) azione ------------------------------------------------------------
if ($SoloControllo) {
    Riga 'Modalita solo controllo: non cambio nulla.' 'Cyan'
    Read-Host 'Premi Invio per chiudere'
    return
}

if (-not $defenderAttivo) {
    Titolo 'Cosa fare col tuo antivirus'
    Riga '   Il tuo antivirus non e Windows Defender: non posso agire da qui.' 'Yellow'
    Riga '   Fai cosi, nel pannello del TUO antivirus:'
    Riga '     - cerca "Esclusioni" / "Esclusioni cartelle" / "Aggiungi eccezione"'
    Riga ('     - aggiungi la cartella:  ' + $base) 'Cyan'
    Riga '     - se chiede anche il processo, aggiungi: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
    Riga ''
    Riga '   In alternativa (o in aggiunta) segnala il falso positivo al produttore,'
    Riga '   allegando il file brain\tools.ps1: e il modo definitivo per risolverlo.'
    Read-Host 'Premi Invio per chiudere'
    return
}

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($Rimuovi) {
    if (-not $admin) {
        Riga 'Per togliere l esclusione servono i permessi di amministratore: riapro io.' 'Yellow'
        try { Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File', $PSCommandPath, '-Rimuovi') } catch { }
        return
    }
    try {
        Remove-MpPreference -ExclusionPath $base -ErrorAction Stop
        Riga ('   Esclusione rimossa per: ' + $base) 'Green'
    } catch { Riga ('   Non riuscito: ' + $_.Exception.Message) 'Red' }
    Read-Host 'Premi Invio per chiudere'
    return
}

if (-not $admin) {
    Titolo '3. Servono i permessi di amministratore'
    Riga '   Windows chiede il consenso (UAC): confermo io e riapro questo script.' 'Yellow'
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File', $PSCommandPath)
    } catch {
        Riga ('   Non sono riuscito a chiedere i permessi: ' + $_.Exception.Message) 'Red'
        Riga '   Fallo a mano: apri PowerShell come AMMINISTRATORE e lancia:'
        Riga ('     Add-MpPreference -ExclusionPath "' + $base + '"') 'Cyan'
        Read-Host 'Premi Invio per chiudere'
    }
    return
}

Titolo '3. Aggiungo la cartella di ZAP alle esclusioni di Defender'
try {
    Add-MpPreference -ExclusionPath $base -ErrorAction Stop
    Riga ('   Fatto: da ora Defender non blocca piu: ' + $base) 'Green'
    Riga '   (l esclusione vale SOLO per questa cartella, non per tutto il PC)' 'Cyan'
} catch {
    Riga ('   Non riuscito: ' + $_.Exception.Message) 'Red'
    Riga ('   Fallback: Add-MpPreference -ExclusionPath "' + $base + '"') 'Cyan'
}

# --- 4) verifica finale ---------------------------------------------------
Titolo '4. Verifica: ZAP riesce a caricare il suo motore?'
$motore = Join-Path $base 'brain\tools.ps1'
if (Test-Path $motore) {
    try {
        . $motore
        if (Get-Command Get-AgentTools -ErrorAction SilentlyContinue) {
            $n = @(Get-AgentTools).Count
            Riga ('   OK! Il motore di ZAP si carica. Strumenti disponibili: ' + $n) 'Green'
            Riga '   Adesso puoi usare AVVIA.bat e lanciare TEST_V5.bat.' 'Green'
        } else {
            Riga '   Il file si carica ma le funzioni non rispondono: rifai DIAGNOSTICA.bat.' 'Yellow'
        }
    } catch {
        Riga ('   ANCORA BLOCCATO: ' + $_.Exception.Message) 'Red'
        Riga '   L antivirus continua a fermarlo. In questo caso:' 'Yellow'
        Riga '     1) avvia PowerShell come AMMINISTRATORE e lancia:'
        Riga ('        Add-MpPreference -ExclusionPath "' + $base + '"') 'Cyan'
        Riga '     2) oppure aggiungi a mano la cartella in Sicurezza di Windows ->'
        Riga '        Protezione da virus e minacce -> Esclusioni -> Aggiungi cartella.'
        Riga '     3) se non basta: segnala il falso positivo al produttore dell antivirus.'
    }
} else {
    Riga ('   Non trovo ' + $motore + ': esegui questo script DENTRO la cartella di ZAP.') 'Red'
}

Riga ''
Riga 'NOTA DI SICUREZZA: un esclusione dice al antivirus di non controllare quella' 'Cyan'
Riga 'cartella. Vale solo per ZAP: non escludere Desktop o Download interi.' 'Cyan'
Read-Host 'Premi Invio per chiudere'
