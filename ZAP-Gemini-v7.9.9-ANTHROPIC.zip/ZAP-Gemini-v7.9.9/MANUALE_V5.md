﻿# ZAP v5 — Manuale delle funzioni nuove

Questo file spiega **cosa fa** ogni funzione della v5, **come si usa** e **cosa non e' verificabile**
in laboratorio. Per l'avvio rapido vedi `ISTRUZIONI.txt`; per i comandi vedi `ISTRUZIONI.txt`.

---

## 1. Le cinque modalita'

Il pulsante **MODALITA'** (in alto a destra) le fa girare in cerchio:

| Modalita' | Comportamento |
|---|---|
| **PRUDENTE** | Chiede conferma prima di **ogni** comando sul PC. |
| **SMART** *(predefinita)* | Chiede conferma solo per i comandi pericolosi. |
| **LIBERO** | Esegue tutto senza chiedere. |
| **SVILUPPATORE** | Autonomia piena + riformulazione sui rifiuti + ricerca web autonoma. |

Comandi equivalenti: `/mode` (gira fra le quattro modalita), `/sviluppatore`.

---

## 2. Novita della v6.2 (cosa e cambiato)

- La vecchia MODALITA PROGRAMMATORI (didattica) e stata **RIMOSSA**: restano quattro
  modalita (PRUDENTE, SMART, LIBERA, SVILUPPATORE). Sono spariti anche il pulsante
  DIDATTICA e il pannello del docente, insieme ai comandi `/programmatori`, `/livello`,
  `/linguaggio`, `/materia`, `/regole`, `/esercizio`, `/soluzione`, `/didattica`.
- **Nuova grafica** scura con accenti oro (ripresa dalla foto di riferimento), al posto
  del fumetto. Il selettore di tema non serve piu: la grafica e una sola.
- **Nuovi pulsanti ALLEGATI e FOTO**: si allega un file di qualunque tipo; ZAP lo
  guarda (le immagini passano dalla vista) e lo elabora insieme al messaggio.

## 3. Modalita' SVILUPPATORE (autonomia)

Pensata per te, non per gli studenti. Tre differenze rispetto a LIBERO:

1. **Se una risposta e' un rifiuto**, ZAP lo riconosce, **riformula la richiesta** e riprova
   (fino a 2 tentativi automatici). Lo vedi nella chat come `autonomia: rifiuto rilevato -> riprovo`.
2. **Se ancora non arriva**, NON si arrende: gli viene detto di procurarsi i dati da solo con
   `web_search`, `read_webpage` e `run_powershell`, e di costruire la risposta.
3. **Chiude sempre con un RESOCONTO RAPIDO**: 3-6 righe con la soluzione, i passi e i link.

Il browser usato e' **il tuo** (`thorium` di default, modificabile in Impostazioni) e il motore di
ricerca e' quello che hai scelto. Nessuna forzatura, nessun aggiramento di protezioni: e' scritto
esplicitamente anche nel prompt.

---

## 4. Sezione PROGRAMMI

- La cartella e' **`programmi\`** accanto a `AVVIA.bat` (modificabile in `config.json`).
- Metti dentro i tuoi file: `.ps1 .bat .cmd .exe .lnk .py .vbs .ahk .jar .msc`.
- Pulsante **PROGRAMMI**: elenco, menu a tendina, **LANCIA**, **AGGIORNA**, **APRI CARTELLA**.
- A voce o per scritto: *"lancia il mio backup"*, *"quali programmi ho"*, `/programmi`.
- **Come vengono lanciati**: `.ps1` con `powershell -File`, `.bat/.cmd` con `cmd /c`,
  `.py` con `python.exe`, `.exe/.lnk` direttamente. (E' verificato dai test.)

---

## 5. Microfono

La versione precedente usava un solo tentativo di riconoscimento e, se non capiva, **non diceva
niente**: da qui la sensazione "non mi sente". Adesso:

- **riconoscimento continuo**: puoi parlare con calma, ZAP raccoglie la frase e la usa;
- **misuratore di livello** nella finestra (barretta accanto ai pulsanti): vedi se il microfono
  riceve suono;
- **stop automatico**: dopo 6 secondi di silenzio smette da solo, non resta appeso;
- **messaggi chiari**: *nessun riconoscitore vocale*, *nessun dispositivo audio di ingresso*,
  *non ho sentito parlare*, *errore nel microfono*;
- **`PROVA_MIC.bat`**: la prova che dice **esattamente** cosa manca, con livello in tempo reale e
  un verdetto finale (0 = funziona, 1 = manca il riconoscitore, 2 = manca l'audio o non entra suono,
  3 = entra suono ma Windows non capisce le parole);
- comando `/mic` per la diagnosi rapida dentro la chat.

**Importante:** se Windows non ha il **riconoscitore vocale italiano** installato, nessun codice
puo' rimediare: `PROVA_MIC.bat` te lo dice con precisione e ti indica la voce esatta da attivare
(Impostazioni -> Lingua -> Italiano -> Opzioni -> Riconoscimento vocale).

---

## 6. Controllo del PC "come un essere umano"

Frasi capite **subito**, senza passare dall'intelligenza artificiale (quindi anche se internet
non funziona):

| Cosa dici | Cosa fa |
|---|---|
| "chiudi questa pagina" / "chiudimi questa finestra" | Chiude la finestra o la scheda in primo piano. |
| "chiudi la finestra di youtube" | Chiude la finestra che contiene "youtube". |
| "elenca le finestre aperte" | Elenca titolo e programma di ogni finestra. |
| "aprimi al volo un nuovo blocco note" | Apre il Blocco note (funziona anche senza "al volo"/"un nuovo"). |
| "aprimi whatsapp e scrivi a Mario: ci vediamo alle 8" | Apre WhatsApp Web e prepara il messaggio per Mario. |
| "manda un messaggio a Luca su whatsapp, domani non ci sono" | Variante equivalente. |
| "apri www.repubblica.it" | Apre il sito nel tuo browser. |
| "cerca ricette di pizza" | Cerca col tuo motore di ricerca. |
| "lancia il mio backup" | Avvia quel programma dalla cartella `programmi`. |
| "scrivi ciao mondo" | Scrive quel testo nella finestra attiva. |
| "minimizza" / "massimizza" | Riduce o ingrandisce la finestra. |

**Programmi conosciuti per nome**: blocco note, calcolatrice, paint, esplora file, prompt dei
comandi, powershell, terminale, task manager, impostazioni, word, excel, powerpoint, outlook,
visual studio code, chrome, edge, firefox, thorium, yandex, youtube, gmail, whatsapp.
Se un nome non e' in elenco, ZAP prova prima la cartella `programmi` e poi le app installate di
Windows (`Get-StartApps`) — nessun elenco inventato a mano.

### WhatsApp: come funziona davvero
- Se dai un **numero**, ZAP apre direttamente la chat giusta con il messaggio gia' pronto.
- Se dai un **nome**, apre WhatsApp Web, mette il messaggio negli **appunti** e ti dice di cercare
  la persona e premere `Ctrl+V`.
- **L'invio finale lo confermi tu.** Nessun invio automatico di massa e nessun trucco
  anti-rilevamento: automatizzare gli invii violerebbe i termini d'uso di WhatsApp.

---

## 7. Dove sono i log (e perche' sono sicuri)

| File | Contenuto |
|---|---|
| `logs\avvio.log` | Trascrizione della sessione di ZAP. |
| `logs\avvio_bat.log` | Output di `AVVIA.bat`. |
| `logs\installazione.log` | Output di `INSTALLA.ps1`. |
| `logs\test_v5.log` | Output dei test (`TEST_V5.bat`). |
| `logs\errore.log` | Errori gravi. |
| `logs\transcript.jsonl` | Domanda/risposta della chat. |

**Nessun log contiene la chiave API.** Ogni riga scritta passa da `Protect-LogText`, e a ogni
avvio/chiusura di ZAP e dell'installer i log vengono ripuliti con `Protect-LogFile`.
Questo comportamento e' verificato dai test (`tests/test_v5.ps1`, sezione "log senza segreti").

---

## 7-bis. Se l'antivirus blocca ZAP (falso positivo)

Messaggio tipico di Windows Defender:

```
In ...\brain\tools.ps1:1 car:1
Questo script include contenuto dannoso ed e' stato bloccato dal software antivirus.
    + FullyQualifiedErrorId : ScriptContainedMaliciousContent
```

**Non e' un virus.** ZAP e' un assistente che scrive ed esegue comandi PowerShell: e' la sua
funzione. Alcuni antivirus vedono "uno script che esegue altri script" e per prudenza lo
fermano. Il controllo AMSI di Defender analizza il **testo** dello script e questo e' un
falso positivo noto per gli strumenti di automazione.

**Soluzione immediata:** esegui `SBLOCCO_ANTIVIRUS.ps1` (tasto destro -> *Esegui con PowerShell*).
Fa tre cose:
1. toglie il "blocco dei file scaricati" (Mark-of-the-Web) da tutta la cartella;
2. controlla se la cartella di ZAP e' gia' fra le esclusioni;
3. se serve, chiede i permessi di amministratore e aggiunge **solo quella cartella** alle
   esclusioni di Windows Defender, poi **verifica** che il motore di ZAP si carichi.

Parametri utili: `-SoloControllo` (non cambia nulla), `-Rimuovi` (toglie l'esclusione).

**Nella v5 il problema e' stato anche ridotto alla radice.** Due costrutti di `tools.ps1`
assomigliavano a quelli di un malware e sono stati eliminati:

| Prima | Adesso |
|---|---|
| una lunga lista di comandi di sistema scritta dentro lo script | vive in `brain\\comandi_pericolosi.txt`, un **file di dati**, e lo script lo legge |
| caricamento **dinamico** dei moduli (un ciclo che dot-sourcava una lista di file) | caricamento **esplicito**, un file per file, in ordine |

**Se usi un antivirus diverso da Defender** (Avast, Kaspersky, ESET, Norton, AVG...):
lo script non puo' agire al posto tuo, ma ti dice cosa fare. Aggiungi la cartella di ZAP alle
esclusioni del tuo antivirus. In alternativa disattiva solo per quella cartella il
"controllo degli script".

**La soluzione definitiva** e' segnalare il falso positivo al produttore dell'antivirus
(allegando `brain\\tools.ps1`), cosi' aggiorna le firme. Per Microsoft:
`https://www.microsoft.com/en-us/wdsi/filesubmission`.

**Nota di sicurezza, onesta:** un'esclusione dice all'antivirus di non controllare quella
cartella. Vale la pena farlo solo per la cartella di ZAP (non per Download o Desktop interi),
e solo perche' il contenuto e' tuo e lo hai ricevuto da una fonte che conosci.

---

## 8. Cosa NON e' stato possibile verificare (dichiarato)

Sviluppo e test sono stati fatti in un ambiente **Linux, senza interfaccia grafica Windows**.
Di conseguenza:

- **verificato con prove reali**: sintassi di tutti gli script (parser ufficiale di PowerShell),
  logica di ogni funzione pura (167 asserzioni), struttura del progetto, XAML ben formato,
  coerenza fra i nomi dei controlli dell'interfaccia e il codice, `.bat` (CRLF, percorsi quotati,
  controllo prerequisiti, assenza di segreti), chiamate reali all'API Gemini;
- **NON verificabile in laboratorio** (va provato sul tuo PC): la finestra WPF, la voce sintetica,
  il riconoscimento vocale reale, gli screenshot, l'apertura del browser e l'esecuzione dei `.bat`.

## 12. Intelligenze AI (v6) - piu' servizi, scelta automatica

ZAP puo' usare **piu' cervelli** insieme. Il pulsante **INTELLIGENZE AI** apre un pannello
dove, per ogni servizio, incolli la tua chiave e scrivi il nome del modello.

- **Servizi**: Google Gemini, OpenAI (ChatGPT), Anthropic (Claude), Alibaba Qwen, OpenRouter,
  Groq, Mistral, DeepSeek, xAI Grok, Together, Perplexity, Cerebras, Fireworks e Ollama
  (quest'ultimo gira **sul tuo PC**, senza chiave).
- **Scelta automatica (AUTOMATICO)**: ZAP legge la richiesta e capisce se serve **visione**
  (foto/schermo), **ricerca** web, **codice**, **testo** lungo o risposta **veloce**, poi usa
  il primo servizio pronto per quel lavoro.
- **Comandi**: `/ai auto`, `/ai stato`, `/ai <servizio>` (es. `/ai openai`).
- **Chiavi**: restano solo nel tuo `config.json`; nei log vengono sempre cancellate.
- **NON verificabile in laboratorio**: le chiamate reali ai servizi richiedono la tua chiave.

## 13. Copia-incolla (v6)

Le risposte di ZAP ora si possono **selezionare e copiare** (Ctrl+C oppure tasto destro ->
Copia). Nel campo dove scrivi ci sono Ctrl+C / Ctrl+V e il menu col tasto destro
(Taglia / Copia / Incolla / Seleziona tutto).

## 14. Microfono: quale motore vocale usa ZAP (v6.1)

ZAP prova prima il motore **moderno** di Windows (`Windows.Media.SpeechRecognition`, lo
stesso della dettatura di Windows) e, solo se non e' disponibile, ripiega su quello
**storico** (`System.Speech`). Microsoft ha ritirato il riconoscimento vocale desktop su
Windows 11 (22H2, settembre 2024): il solo motore storico non e' piu' affidabile.

- Durante l'ascolto, con il motore moderno la **barretta del livello resta a zero** (l'API
  non lo espone): si legge lo stato scritto accanto. Il riconoscimento funziona lo stesso.
- `PROVA_MIC.bat` prova **entrambi** i motori e dice quale funziona e cosa manca.
- Permessi utili: Impostazioni -> Privacy e sicurezza -> Microfono (attiva anche per le app
  desktop) e Impostazioni -> Lingua -> Italiano -> Opzioni -> Riconoscimento vocale.
