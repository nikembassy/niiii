# ZAP — Installare Kali Linux (WSL2) — GUIDA RAPIDA

## Perche' prima non funzionava
Su Windows, Kali Linux gira dentro **WSL2**. Il comando `wsl --install` che installa
Kali **richiede i permessi di AMMINISTRATORE**.

## ⚠️ Se NON compare la finestra di Windows (UAC)
Dalla diagnostica del tuo PC risulta:
```
Amministratore adesso? SI        (sei amministratore ✔)
EnableLUA = 1                    (UAC attivo)
ConsentPromptBehaviorAdmin = 0   ← "eleva SENZA chiedere"
```
Con `ConsentPromptBehaviorAdmin = 0` Windows **non mostra MAI** la finestra UAC:
eleva i programmi **in silenzio**. Quindi **l'assenza della richiesta è normale**
e non è il guasto. Il punto è se il comando di installazione di Kali va a termine.

### Cosa fare, in ordine
1. **Diagnostica** — doppio clic su `DIAGNOSTICA_KALI.bat` (non serve essere admin).
   Scrive un report in `logs\diagnostica_kali.txt`.
2. **Metodo che funziona sempre** — apri **PowerShell come amministratore**
   (tasti **Windows + X** → "Terminale (amministratore)" / "Windows PowerShell (amministratore)")
   e digita:
   ```
   wsl --install -d kali-linux
   ```
   Se chiede il riavvio: riavvia e ripeti. Poi `wsl -l -v` deve mostrare `kali-linux` `VERSION 2`.
   (Dettagli anche in `INSTALLA_KALI_MANUALE.txt`.)
3. **Dal file** — tasto destro su `INSTALLA_KALI.bat` → **"Esegui come amministratore"**.
4. **Dal pulsante** — apri ZAP → **KALI** → **INSTALLA KALI** (sul tuo PC non comparirà la
   finestra UAC: è normale, l'elevazione è silenziosa). Alla fine leggi il messaggio in fondo
   o il file `logs\kali_install.log`.

---

## Cosa serve
- Windows 10 (2004+) o Windows 11.
- Virtualizzazione attiva nel BIOS/UEFI.
- Connessione a internet.
- Account Windows **amministratore** (il tuo lo è).

## Se Windows chiede un RIAVVIO
Alcuni componenti (WSL + Piattaforma Macchina Virtuale) richiedono un riavvio la PRIMA
volta. È normale: **riavvia il PC** e ripeti l'installazione.

## Dopo l'installazione
- L'agente crea un utente di comodo: **`kali` / `kali`**, impostato come predefinito
  (così la console funziona subito, senza il blocco del "primo avvio").
- **Cambia la password** quando vuoi: nella console Kali digita `passwd`.
- Lo stato si vede nella console Kali: "Kali pronto" + i 15 strumenti con
  `[INSTALLATO]` / `[NON INSTALLATO]`.

## Nota d'uso
Gli strumenti inclusi (nmap, metasploit, sqlmap, hydra, ...) sono per uso **lecito**:
solo su sistemi **tuoi** o per cui hai **autorizzazione scritta**.
