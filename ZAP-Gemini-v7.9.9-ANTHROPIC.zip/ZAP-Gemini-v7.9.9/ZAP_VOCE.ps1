﻿<#
=======================================================================
 VOCE per ZAP  -  TELECOMANDO VOCALE (oro e argento)          v2.0
=======================================================================
 Un telecomando PICCOLO, sempre in primo piano, accanto a ZAP.
 Sola DETTATURA di Windows (Win+H): premi PARLA, parli, il testo entra
 nella casella di ZAP, poi premi INVIA e il messaggio parte.

 BOTTONI
   PARLA   (Ctrl+Alt+Z)  avvia la dettatura di Windows dentro ZAP
   INVIA   (Ctrl+Alt+I)  clicca davvero il bottone INVIA di ZAP
   CONTROLLA ZAP         verifica che ZAP sia raggiungibile

 Sotto c'e' la mini-chat: ogni conferma viene scritta li'.

 PERCHE' SERVE
   Dentro ZAP il microfono non parte: ZAP gira in un processo
   PowerShell/WPF non "pacchettizzato" e Windows gli annulla la
   preparazione del motore moderno ("!WINRT:preparazione non riuscita ()").
   La dettatura di Windows invece e' un'app firmata: i permessi li ha.

 AVVIO
   Doppio clic su  AVVIA_ZAP_VOCE.bat
 DIAGNOSTICA (senza finestra)
   powershell -NoProfile -ExecutionPolicy Bypass -File ZAP_VOCE.ps1 -Diagnostica
=======================================================================
#>
param([switch]$Diagnostica, [string]$ZapHwnd = '', [int]$ZapPid = 0)

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

foreach ($asm in 'System.Windows.Forms', 'System.Drawing', 'System.Speech') {
    try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch { }
}

$Base = $PSScriptRoot
if (-not $Base) { $Base = (Get-Location).Path }

$ID_CASELLA = 'InputBox'     # x:Name della casella di scrittura di ZAP
$ID_INVIA   = 'BtnInvia'     # x:Name del bottone INVIA di ZAP

# v2.1: se ZAP ci passa la SUA finestra la usiamo direttamente. Cosi' il telecomando
# funziona anche quando i TITOLI delle finestre non sono leggibili per via dei
# privilegi diversi (UAC): e' la causa del "non mi trova ZAP".
$script:ZapH = [IntPtr]::Zero
if ($ZapHwnd) { try { $script:ZapH = [IntPtr][int64]$ZapHwnd } catch { $script:ZapH = [IntPtr]::Zero } }

# ---------------------------------------------------------------------
# Palette ORO e ARGENTO
# ---------------------------------------------------------------------
$C_ORO1   = [System.Drawing.Color]::FromArgb(242, 208, 107)   # oro chiaro
$C_ORO2   = [System.Drawing.Color]::FromArgb(201, 162, 39)    # oro medio
$C_ORO3   = [System.Drawing.Color]::FromArgb(150, 118, 30)    # oro scuro
$C_FONDO  = [System.Drawing.Color]::FromArgb(74, 58, 14)      # fondo oro scuro
$C_BTN    = [System.Drawing.Color]::FromArgb(156, 122, 34)
$C_BTNHOV = [System.Drawing.Color]::FromArgb(190, 152, 50)
$C_BTNDWN = [System.Drawing.Color]::FromArgb(118, 92, 24)
$C_ARG    = [System.Drawing.Color]::FromArgb(233, 233, 233)   # argento
$C_ARG2   = [System.Drawing.Color]::FromArgb(201, 201, 201)   # argento spento
$C_CHAT   = [System.Drawing.Color]::FromArgb(38, 30, 8)       # fondo mini-chat

# ---------------------------------------------------------------------
# Win32
# ---------------------------------------------------------------------
$srcWin = @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class ZvWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);

  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte sc, uint flags, IntPtr extra);
  [DllImport("user32.dll")] public static extern bool ReleaseCapture();
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr wp, IntPtr lp);

  public static List<IntPtr> FindTitles(string part) {
    List<IntPtr> res = new List<IntPtr>();
    EnumWindows(delegate(IntPtr h, IntPtr l) {
      if (!IsWindowVisible(h)) return true;
      int n = GetWindowTextLength(h);
      if (n <= 0) return true;
      StringBuilder sb = new StringBuilder(n + 2);
      GetWindowText(h, sb, sb.Capacity);
      string t = sb.ToString();
      if (t.IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0) res.Add(h);
      return true;
    }, IntPtr.Zero);
    return res;
  }

  public static string TitleOf(IntPtr h) {
    int n = GetWindowTextLength(h);
    if (n <= 0) return "";
    StringBuilder sb = new StringBuilder(n + 2);
    GetWindowText(h, sb, sb.Capacity);
    return sb.ToString();
  }
}
'@
try { Add-Type -TypeDefinition $srcWin -ErrorAction Stop } catch { }

$srcHot = @'
using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

public class ZvHotKeyForm : Form {
  [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
  [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
  public Action<int> OnHotKey;
  public bool Reg(int id, uint mod, uint vk) { return RegisterHotKey(this.Handle, id, mod, vk); }
  public void Unreg(int id) { UnregisterHotKey(this.Handle, id); }
  protected override void WndProc(ref Message m) {
    if (m.Msg == 0x0312 && OnHotKey != null) { try { OnHotKey(m.WParam.ToInt32()); } catch { } }
    base.WndProc(ref m);
  }
}
'@
$hotOk = $true
try { Add-Type -TypeDefinition $srcHot -ReferencedAssemblies 'System.Windows.Forms', 'System.Drawing' -ErrorAction Stop } catch { $hotOk = $false }

$uiaOk = $true
try {
    Add-Type -AssemblyName UIAutomationClient -ErrorAction Stop
    Add-Type -AssemblyName UIAutomationTypes -ErrorAction Stop
} catch { $uiaOk = $false }

# ---------------------------------------------------------------------
# Costanti
# ---------------------------------------------------------------------
$VK_LWIN  = 0x5B
$VK_H     = 0x48
$KEYUP    = 0x0002
$MOD_ALT  = 0x0001
$MOD_CTRL = 0x0002
$VK_Z     = 0x5A
$VK_I     = 0x49
$script:HK_PARLA = 1
$script:HK_INVIA = 2
$script:form = $null
$script:lblStato = $null
$script:txtChat = $null
$script:Diagnostica = [bool]$Diagnostica

# ---------------------------------------------------------------------
# Mini-chat delle conferme
# ---------------------------------------------------------------------
function Write-Chat {
    param([string]$Testo)
    $ora = Get-Date -Format 'HH:mm'
    if ($script:Diagnostica) { Write-Host ('[' + $ora + '] ' + $Testo) }
    if ($script:txtChat) {
        try {
            $script:txtChat.SelectionStart = $script:txtChat.TextLength
            $script:txtChat.SelectionColor = $C_ARG
            $script:txtChat.AppendText(('[' + $ora + '] ' + $Testo + "`r`n"))
            $script:txtChat.ScrollToCaret()
        } catch { }
    }
}

function Write-ChatTitolo {
    param([string]$Testo)
    if ($script:txtChat) {
        try {
            $script:txtChat.SelectionStart = $script:txtChat.TextLength
            $script:txtChat.SelectionColor = $C_ORO1
            $script:txtChat.AppendText(($Testo + "`r`n"))
            $script:txtChat.ScrollToCaret()
        } catch { }
    }
}

function Set-Stato {
    param([string]$Testo)
    try {
        $script:lblStato.Text = $Testo
        $script:form.Refresh()
    } catch { }
}

# ---------------------------------------------------------------------
# Finestre di ZAP
# ---------------------------------------------------------------------
function Get-FinestreZap {
    param([string]$Filtro = 'ZAP')
    if (-not $Filtro) { $Filtro = 'ZAP' }
    $out = @()
    try {
        foreach ($h in @([ZvWin]::FindTitles($Filtro))) {
            $procid = 0
            [void][ZvWin]::GetWindowThreadProcessId($h, [ref]$procid)
            if ($procid -eq $PID) { continue }
            $t = [ZvWin]::TitleOf($h)
            if ($t -like '*VOCE*' -or $t -like '*Microfono*') { continue }
            $out += $h
        }
        $pref = @($out | Where-Object { [ZvWin]::TitleOf($_) -like 'ZAP*' })
        if (@($pref).Count -gt 0) { return $pref }
        return $out
    } catch { return @() }
}

function Attiva-Finestra {
    param([IntPtr]$H)
    try {
        if ([ZvWin]::IsIconic($H)) {
            [void][ZvWin]::ShowWindow($H, 9)   # SW_RESTORE
            for ($i = 0; $i -lt 25; $i++) { if (-not [ZvWin]::IsIconic($H)) { break }; Start-Sleep -Milliseconds 60 }
        }
        $fg = [ZvWin]::GetForegroundWindow()
        if ($fg -ne $H) {
            $procid = 0
            $thFg = [ZvWin]::GetWindowThreadProcessId($fg, [ref]$procid)
            $thMe = [ZvWin]::GetCurrentThreadId()
            [void][ZvWin]::AttachThreadInput($thMe, $thFg, $true)
            [void][ZvWin]::BringWindowToTop($H)
            [void][ZvWin]::SetForegroundWindow($H)
            try { [ZvWin]::keybd_event(0x12, 0, 0, [IntPtr]::Zero); Start-Sleep -Milliseconds 30; [ZvWin]::keybd_event(0x12, 0, 2, [IntPtr]::Zero) } catch { }
            [void][ZvWin]::AttachThreadInput($thMe, $thFg, $false)
        }
        for ($i = 0; $i -lt 25; $i++) {
            if ([ZvWin]::GetForegroundWindow() -eq $H) { return $true }
            Start-Sleep -Milliseconds 60
        }
        return $true
    } catch { return $false }
}

# ---------------------------------------------------------------------
# UI Automation: la casella giusta e il bottone INVIA di ZAP
# ---------------------------------------------------------------------
function Get-RadiceZap {
    param([IntPtr]$H)
    if (-not $uiaOk) { return $null }
    try { return [System.Windows.Automation.AutomationElement]::FromHandle($H) } catch { return $null }
}

function Trova-PerId {
    param($Radice, [string]$Id)
    if (-not $Radice) { return $null }
    try {
        $cond = New-Object System.Windows.Automation.PropertyCondition(
            [System.Windows.Automation.AutomationElement]::AutomationIdProperty, $Id)
        return $Radice.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $cond)
    } catch { return $null }
}

function Attiva-Zap {
    param([switch]$Silenzioso)
    # 1) finestra REGALATA da ZAP (la piu' affidabile, funziona anche con privilegi diversi)
    $hw = @()
    try { if ($script:ZapH -and $script:ZapH -ne [IntPtr]::Zero -and [ZvWin]::IsWindow($script:ZapH)) { $hw = @($script:ZapH) } } catch { }
    # 2) altrimenti la cerco per titolo
    if (@($hw).Count -eq 0) { $hw = Get-FinestreZap 'ZAP' }
    if (-not $hw -or @($hw).Count -eq 0) {
        if (-not $Silenzioso) {
            Write-Chat 'ZAP non trovato: aprilo (o lascialo aperto) e riprova.'
            Write-Chat 'Se ZAP e aperto ma non lo trovo: avvia il telecomando CON GLI STESSI PRIVILEGI di ZAP (o lascia che sia ZAP ad aprirlo).'
            Set-Stato 'ZAP non trovato'
        }
        return $null
    }
    $h = @($hw)[0]
    [void](Attiva-Finestra $h)
    for ($i = 0; $i -lt 12; $i++) { if (-not [ZvWin]::IsIconic($h)) { break }; Start-Sleep -Milliseconds 100 }
    Start-Sleep -Milliseconds 250
    $radice = Get-RadiceZap $h
    $casella = $null
    $btn = $null
    for ($i = 0; $i -lt 8; $i++) {
        if (-not $casella) { $casella = Trova-PerId $radice $ID_CASELLA }
        if (-not $btn)     { $btn     = Trova-PerId $radice $ID_INVIA }
        if ($casella -and $btn) { break }
        Start-Sleep -Milliseconds 200
        $radice = Get-RadiceZap $h
    }
    if (-not $Silenzioso) {
        Write-Chat ('ZAP: "' + [ZvWin]::TitleOf($h) + '"')
        Write-Chat ('casella di scrittura: ' + $(if ($casella) { 'TROVATA' } else { 'NON trovata' }))
        Write-Chat ('bottone INVIA: ' + $(if ($btn) { 'TROVATO' } else { 'NON trovato' }))
    }
    return @{ Hwnd = $h; Radice = $radice; Casella = $casella; Bottone = $btn }
}

function Invia-WinH {
    [ZvWin]::keybd_event($VK_LWIN, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 70
    [ZvWin]::keybd_event($VK_H, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 70
    [ZvWin]::keybd_event($VK_H, 0, $KEYUP, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 70
    [ZvWin]::keybd_event($VK_LWIN, 0, $KEYUP, [IntPtr]::Zero)
}

function Clicca-Invia {
    param($Z)
    if (-not $Z -or -not $Z.Radice) { return $null }
    if ($Z.Bottone) {
        try {
            $ip = $Z.Bottone.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
            if ($ip) { $ip.Invoke(); return ('bottone ' + $ID_INVIA) }
        } catch { }
    }
    if ($Z.Casella) {
        try {
            $Z.Casella.SetFocus()
            Start-Sleep -Milliseconds 150
            [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
            return 'tasto Invio'
        } catch { }
    }
    return $null
}

function Avvia-Parla {
    Write-ChatTitolo '--- ASCOLTO ---'
    $z = Attiva-Zap
    if (-not $z) { return }
    try { if ($z.Casella) { $z.Casella.SetFocus(); Start-Sleep -Milliseconds 200 } } catch { }
    Invia-WinH
    Set-Stato 'PARLA ORA... poi premi INVIA'
    Write-Chat 'Dettatura di Windows avviata: parla adesso.'
}

function Invia-Ora {
    $z = Attiva-Zap -Silenzioso
    if (-not $z) { Write-Chat 'ZAP non trovato: non posso inviare.'; Set-Stato 'ZAP non trovato'; return }
    $come = Clicca-Invia $z
    if ($come) {
        Write-Chat ('Messaggio inviato (INVIA premuto con: ' + $come + ').')
        Set-Stato 'Inviato.'
    }
    else {
        Write-Chat 'Non sono riuscito a premere INVIA: cliccalo tu.'
        Set-Stato 'Premi INVIA a mano.'
    }
}

function Controlla-Zap {
    Write-ChatTitolo '--- CONTROLLO ZAP ---'
    $z = Attiva-Zap
    if ($z) { Set-Stato 'ZAP controllato: vedi conferme.' }
}

# ---------------------------------------------------------------------
# DIAGNOSTICA da console
# ---------------------------------------------------------------------
function Get-RiconoscitoreModerno {
    param([string]$Lingua = 'it-IT')
    [void][Windows.Media.SpeechRecognition.SpeechRecognizer, Windows.Media.SpeechRecognition, ContentType=WindowsRuntime]
    [void][Windows.Media.SpeechRecognition.SpeechRecognitionTopicConstraint, Windows.Media.SpeechRecognition, ContentType=WindowsRuntime]
    [void][Windows.Media.SpeechRecognition.SpeechRecognitionScenario, Windows.Media.SpeechRecognition, ContentType=WindowsRuntime]
    [void][Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
    $rec = $null
    try {
        $lang = [Windows.Globalization.Language]::new($Lingua)
        $rec = [Windows.Media.SpeechRecognition.SpeechRecognizer]::new($lang)
    } catch {
        try { $rec = [Windows.Media.SpeechRecognition.SpeechRecognizer]::new() } catch { $rec = $null }
    }
    if (-not $rec) { return $null }
    # LA CONSTRAINT CHE A ZAP MANCA
    $scen = [Windows.Media.SpeechRecognition.SpeechRecognitionScenario]::Dictation
    $cons = [Windows.Media.SpeechRecognition.SpeechRecognitionTopicConstraint]::new($scen, 'dettatura')
    [void]$rec.Constraints.Add($cons)
    return $rec
}

function Attendi-Operazione {
    param($Operazione, [int]$MaxSec = 30)
    $t0 = Get-Date
    while ($true) {
        $st = 'Error'
        try { $st = [string]$Operazione.Status } catch { $st = 'Error' }
        if ($st -ne 'Started') { return $st }
        if (((Get-Date) - $t0).TotalSeconds -gt $MaxSec) { return 'Timeout' }
        try { [System.Windows.Forms.Application]::DoEvents() } catch { }
        Start-Sleep -Milliseconds 60
    }
}

if ($Diagnostica) {
    Write-Host ''
    Write-Host '=== VOCE per ZAP v2.0 - diagnostica ===' -ForegroundColor Yellow
    Write-Host ('Windows    : ' + [System.Environment]::OSVersion.VersionString)
    Write-Host ('PowerShell : ' + $PSVersionTable.PSVersion)
    Write-Host ''
    Write-Host '1) Finestre con "ZAP" nel titolo:' -ForegroundColor Cyan
    $hw = @(Get-FinestreZap 'ZAP')
    if ($hw.Count -eq 0) { Write-Host '   nessuna (ZAP non e aperto?)' -ForegroundColor Yellow }
    else {
        foreach ($h in $hw) {
            Write-Host ('   "' + [ZvWin]::TitleOf($h) + '"') -ForegroundColor Green
            $r = Get-RadiceZap $h
            $cs = Trova-PerId $r $ID_CASELLA
            $bt = Trova-PerId $r $ID_INVIA
            Write-Host ('      casella "' + $ID_CASELLA + '": ' + $(if ($cs) { 'TROVATA' } else { 'non trovata' })) -ForegroundColor Green
            Write-Host ('      bottone "' + $ID_INVIA + '": ' + $(if ($bt) { 'TROVATO' } else { 'non trovato' })) -ForegroundColor Green
        }
    }
    Write-Host ''
    Write-Host '2) Riconoscitori storici:' -ForegroundColor Cyan
    try {
        $recs = @([System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers())
        if ($recs.Count -eq 0) { Write-Host '   nessuno' -ForegroundColor Yellow }
        else { foreach ($r in $recs) { Write-Host ('   ' + $r.Culture.Name + '  ' + $r.Description) } }
    } catch { Write-Host ('   errore: ' + $_.Exception.Message) -ForegroundColor Red }
    Write-Host ''
    Write-Host '3) Motore MODERNO con la constraint Dictation (prova):' -ForegroundColor Cyan
    try {
        $rec = Get-RiconoscitoreModerno 'it-IT'
        if (-not $rec) { Write-Host '   non riesco a creare il riconoscitore.' -ForegroundColor Red }
        else {
            Write-Host ('   creato. lingua: ' + [string]$rec.CurrentLanguage.LanguageTag) -ForegroundColor Green
            $op = $rec.CompileConstraintsAsync()
            $st = Attendi-Operazione $op 30
            $esito = ''
            $err = ''
            try { $esito = [string]$op.GetResults().Status } catch {
                $err = [string]$_.Exception.Message
                try { if ($_.Exception.HResult) { $err += ('  0x{0:X8}' -f $_.Exception.HResult) } } catch { }
            }
            Write-Host ('   stato: ' + $st + '   risultato: ' + $esito) -ForegroundColor Green
            if ($err) { Write-Host ('   errore vero: ' + $err) -ForegroundColor Red }
            if ($esito -eq 'Success') { Write-Host '   => il motore moderno FUNZIONA con la constraint.' -ForegroundColor Green }
            else { Write-Host '   => usa la dettatura di Windows (Win+H).' -ForegroundColor Yellow }
            try { $rec.Dispose() } catch { }
        }
    } catch { Write-Host ('   errore: ' + $_.Exception.Message) -ForegroundColor Red }
    Write-Host ''
    return
}

# ---------------------------------------------------------------------
# INTERFACCIA - telecomando oro/argento
# ---------------------------------------------------------------------
$apartment = 'Unknown'
try { $apartment = [string][System.Threading.Thread]::CurrentThread.GetApartmentState() } catch { }
if ($apartment -ne 'STA') {
    try {
        [System.Windows.Forms.MessageBox]::Show(
            "Avvia questa app con AVVIA_ZAP_VOCE.bat (serve la modalita' STA).",
            'VOCE per ZAP', 'OK', 'Warning') | Out-Null
    } catch { }
    return
}

$W = 306
$form = New-Object System.Windows.Forms.Form
$form.Text = 'VOCE per ZAP'
$form.ClientSize = New-Object System.Drawing.Size($W, 348)
$form.FormBorderStyle = 'None'
$form.MaximizeBox = $false
$form.TopMost = $true
$form.BackColor = $C_FONDO
$form.ForeColor = $C_ARG
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$form.StartPosition = 'Manual'
try {
    $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $x = $wa.Right - ($W + 16)
    $y = $wa.Bottom - 372
    if ($x -lt 0) { $x = 16 }
    if ($y -lt 0) { $y = 16 }
    $form.Location = New-Object System.Drawing.Point($x, $y)
} catch { $form.StartPosition = 'CenterScreen' }

# bordo sottile dorato attorno a tutto il telecomando
$form.Add_Paint({
    param($s, $e)
    $pen = New-Object System.Drawing.Pen($C_ORO1, 1)
    $e.Graphics.DrawRectangle($pen, 0, 0, ($s.ClientSize.Width - 1), ($s.ClientSize.Height - 1))
    $pen.Dispose()
})

# --- intestazione dorata, trascinabile ---
$pnlTop = New-Object System.Windows.Forms.Panel
$pnlTop.Location = New-Object System.Drawing.Point(1, 1)
$pnlTop.Size = New-Object System.Drawing.Size(($W - 2), 30)
$pnlTop.Add_Paint({
    param($s, $e)
    $rect = New-Object System.Drawing.Rectangle(0, 0, $s.ClientSize.Width, $s.ClientSize.Height)
    $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $C_ORO1, $C_ORO2, 22.0)
    $e.Graphics.FillRectangle($br, $rect)
    $br.Dispose()
})
$form.Controls.Add($pnlTop)

$lblTitolo = New-Object System.Windows.Forms.Label
$lblTitolo.Text = 'VOCE per ZAP'
$lblTitolo.Location = New-Object System.Drawing.Point(10, 6)
$lblTitolo.Size = New-Object System.Drawing.Size(220, 20)
$lblTitolo.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
$lblTitolo.ForeColor = $C_ARG
$lblTitolo.BackColor = [System.Drawing.Color]::Transparent
$pnlTop.Controls.Add($lblTitolo)

$btnChiudi = New-Object System.Windows.Forms.Button
$btnChiudi.Text = 'X'
$btnChiudi.Location = New-Object System.Drawing.Point((($W - 2) - 30), 3)
$btnChiudi.Size = New-Object System.Drawing.Size(26, 24)
$btnChiudi.FlatStyle = 'Flat'
$btnChiudi.FlatAppearance.BorderSize = 0
$btnChiudi.BackColor = $C_ORO2
$btnChiudi.ForeColor = $C_ARG
$btnChiudi.TabStop = $false
$pnlTop.Controls.Add($btnChiudi)

$drag = {
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
        [void][ZvWin]::ReleaseCapture()
        [void][ZvWin]::SendMessage($script:form.Handle, 0xA1, [IntPtr]0x2, [IntPtr]::Zero)
    }
}
$pnlTop.Add_MouseDown($drag)
$lblTitolo.Add_MouseDown($drag)

# --- utile per creare i bottoni dorati ---
function Nuovo-Bottone {
    param([string]$Testo, [int]$X, [int]$Y, [int]$L, [int]$A, [int]$Size = 10, [bool]$Bold = $true)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Testo
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Size = New-Object System.Drawing.Size($L, $A)
    $st = if ($Bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    $b.Font = New-Object System.Drawing.Font('Segoe UI', $Size, $st)
    $b.FlatStyle = 'Flat'
    $b.BackColor = $C_BTN
    $b.ForeColor = $C_ARG
    $b.FlatAppearance.BorderSize = 1
    $b.FlatAppearance.BorderColor = $C_ORO1
    $b.FlatAppearance.MouseOverBackColor = $C_BTNHOV
    $b.FlatAppearance.MouseDownBackColor = $C_BTNDWN
    return $b
}

$btnParla = Nuovo-Bottone 'PARLA   (Ctrl+Alt+Z)' 12 40 282 52 13 $true
$form.Controls.Add($btnParla)

$btnInvia = Nuovo-Bottone 'INVIA' 12 98 138 34 10 $true
$form.Controls.Add($btnInvia)

$btnControlla = Nuovo-Bottone 'CONTROLLA ZAP' 156 98 138 34 9 $true
$form.Controls.Add($btnControlla)

$lblStato = New-Object System.Windows.Forms.Label
$lblStato.Text = 'Pronto.'
$lblStato.Location = New-Object System.Drawing.Point(12, 138)
$lblStato.Size = New-Object System.Drawing.Size(282, 30)
$lblStato.Font = New-Object System.Drawing.Font('Segoe UI', 9.5, [System.Drawing.FontStyle]::Bold)
$lblStato.ForeColor = $C_ARG
$form.Controls.Add($lblStato)

$lblChat = New-Object System.Windows.Forms.Label
$lblChat.Text = 'conferme'
$lblChat.Location = New-Object System.Drawing.Point(12, 172)
$lblChat.Size = New-Object System.Drawing.Size(282, 16)
$lblChat.Font = New-Object System.Drawing.Font('Segoe UI', 7.5, [System.Drawing.FontStyle]::Regular)
$lblChat.ForeColor = $C_ARG2
$form.Controls.Add($lblChat)

# cornice dorata attorno alla mini-chat
$pnlChat = New-Object System.Windows.Forms.Panel
$pnlChat.Location = New-Object System.Drawing.Point(12, 190)
$pnlChat.Size = New-Object System.Drawing.Size(282, 146)
$pnlChat.BackColor = $C_ORO3
$pnlChat.Padding = New-Object System.Windows.Forms.Padding(1)
$form.Controls.Add($pnlChat)

$txtChat = New-Object System.Windows.Forms.RichTextBox
$txtChat.Dock = 'Fill'
$txtChat.ReadOnly = $true
$txtChat.BorderStyle = 'None'
$txtChat.BackColor = $C_CHAT
$txtChat.ForeColor = $C_ARG
$txtChat.Font = New-Object System.Drawing.Font('Consolas', 8)
$txtChat.ScrollBars = 'Vertical'
$pnlChat.Controls.Add($txtChat)

$script:form = $form
$script:lblStato = $lblStato
$script:txtChat = $txtChat

$btnParla.Add_Click({ Avvia-Parla })
$btnInvia.Add_Click({ Invia-Ora })
$btnControlla.Add_Click({ Controlla-Zap })
$btnChiudi.Add_Click({ $form.Close() })

$form.Add_KeyDown({
    param($s, $e)
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) { $form.WindowState = 'Minimized' }
})

# --- comandi rapidi globali ---
$hk = $null
if ($hotOk) {
    try {
        $hk = New-Object ZvHotKeyForm
        $hk.FormBorderStyle = 'None'
        $hk.ShowInTaskbar = $false
        $hk.Opacity = 0
        $hk.Size = New-Object System.Drawing.Size(2, 2)
        $hk.StartPosition = 'Manual'
        $hk.Location = New-Object System.Drawing.Point(-2000, -2000)
        $hk.Show()
        $hk.OnHotKey = [Action[int]]{
            param($id)
            if ($id -eq $script:HK_PARLA) { Avvia-Parla }
            elseif ($id -eq $script:HK_INVIA) { Invia-Ora }
        }
        $ok1 = $hk.Reg($script:HK_PARLA, ($MOD_CTRL -bor $MOD_ALT), $VK_Z)
        $ok2 = $hk.Reg($script:HK_INVIA, ($MOD_CTRL -bor $MOD_ALT), $VK_I)
        if (-not $ok1 -or -not $ok2) { Write-Chat 'Comandi rapidi non attivi (forse gia in uso).' }
    } catch { Write-Chat ('Comandi rapidi non disponibili: ' + $_.Exception.Message) }
}

$form.Add_FormClosing({
    try { if ($hk) { $hk.Unreg($script:HK_PARLA); $hk.Unreg($script:HK_INVIA); $hk.Close() } } catch { }
})

$form.Add_Shown({
    Write-ChatTitolo '--- VOCE per ZAP v2.0 ---'
    Write-Chat 'Telecomando pronto.'
    if (-not $uiaOk) { Write-Chat 'Avviso: UI Automation non disponibile.' }
    $z = Attiva-Zap -Silenzioso
    if ($z) {
        Write-Chat ('ZAP collegato: ' + [ZvWin]::TitleOf($z.Hwnd))
        Write-Chat ('casella di scrittura: ' + $(if ($z.Casella) { 'TROVATA' } else { 'NON trovata' }))
        Write-Chat ('bottone INVIA: ' + $(if ($z.Bottone) { 'TROVATO' } else { 'NON trovato' }))
        Set-Stato 'ZAP collegato. Premi PARLA.'
    }
    else {
        Write-Chat 'ZAP non e aperto: aprilo e premi CONTROLLA ZAP.'
        Set-Stato 'ZAP non trovato.'
    }
    Write-Chat 'Comandi: Ctrl+Alt+Z = PARLA, Ctrl+Alt+I = INVIA.'
})

[void]$form.ShowDialog()
try { if ($hk) { $hk.Unreg($script:HK_PARLA); $hk.Unreg($script:HK_INVIA) } } catch { }
