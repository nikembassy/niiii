@echo off
setlocal
cd /d "%~dp0"
title ZAP - Installazione
where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo.
  pause
  exit /b 1
)
if not exist "%~dp0INSTALLA.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca INSTALLA.ps1 accanto a questo .bat (cartella: %~dp0^)
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA.ps1"
echo.
echo  Installazione terminata.  Log in logs\installazione.log
pause
endlocal
