﻿# Come ottenere le chiavi API (ZAP - INTELLIGENZE AI)

**ZAP non puo' procurarti le chiavi.** Sono credenziali personali: ogni servizio le
rilascia dopo che ti sei registrato, e l'uso e' a tuo carico (molti hanno un piano
gratuito o credito iniziale). Non esistono chiavi "da trovare" dentro il programma:
metterle io sarebbe impossibile e sbagliato. Qui sotto c'e' il link ufficiale di ognuno.

## Come si usa (2 minuti, una volta sola per servizio)

1. Doppio clic su **AVVIA.bat**.
2. Premi **INTELLIGENZE AI** (in alto a destra).
3. Per ogni servizio che vuoi usare: incolla la **chiave** e scrivi il **nome del modello**.
4. Premi **SALVA QUESTO SERVIZIO** (oppure **SALVA TUTTO**).
5. Lascia il selettore su **AUTOMATICO**: ZAP sceglie da solo il servizio adatto al lavoro
   (visione, ricerca, codice, testo, veloce). Per fissarne uno a mano: `/ai openai` (esempio).

Finche' un servizio non ha **chiave E modello** resta `[ ]` e non viene mai scelto.
Il campo **modello** e' vuoto di proposito: i nomi dei modelli cambiano spesso. Il nome
esatto lo trovi nella pagina del servizio; per quelli gia' presenti (es. Gemini) ZAP usa
il modello che avevi configurato.

## Le pagine ufficiali dove prendere la chiave

| Servizio | Pagina (copia la chiave qui) |
|---|---|
| Google Gemini | https://aistudio.google.com/app/apikey |
| OpenAI (ChatGPT) | https://platform.openai.com/api-keys |
| Anthropic (Claude) | https://console.anthropic.com/settings/keys |
| Alibaba Qwen (DashScope / Model Studio) | https://modelstudio.console.alibabacloud.com/ |
| OpenRouter | https://openrouter.ai/keys |
| Groq | https://console.groq.com/keys |
| Mistral | https://console.mistral.ai/api-keys |
| DeepSeek | https://platform.deepseek.com/api_keys |
| xAI Grok | https://console.x.ai |
| Together AI | https://api.together.ai/settings/api-keys |
| Perplexity | https://www.perplexity.ai/settings/api |
| Cerebras | https://cloud.cerebras.ai |
| Fireworks AI | https://fireworks.ai/account/api-keys |
| **Ollama (sul TUO PC)** | https://ollama.com/download — **qui NON serve una chiave** |

## ATTENZIONE: chi usa la "RAM" (il calcolo)

- **Ollama** gira **sul tuo PC**: usa la tua RAM e il tuo processore. Non serve nessuna chiave.
- **Google, OpenAI, Anthropic, Qwen, OpenRouter, Groq, Mistral, DeepSeek, xAI, Together,
  Perplexity, Cerebras, Fireworks** girano **nei loro data center** (cloud): usano la LORO
  potenza di calcolo, non la tua. Per ognuno di questi serve la tua chiave personale.

## Sicurezza (importante)

- Le chiavi restano **solo** nel tuo `config.json`, nella sezione `provider_ai`.
- Nei log ZAP le cancella sempre (formati `AQ.`, `AIza`, `sk-`, `gsk_`, `xai-`, `pplx-`,
  `csk-`, `fw_`, `hf_`, `Bearer ...`, `x-api-key: ...`, `chiave=...`).
- **Se hai condiviso lo ZIP con qualcuno, rigenera le chiavi** dai link qui sopra: anche se
  non finiscono nei log, il file `config.json` le contiene. Incollale di nuovo dopo la
  rigenerazione (Gemini in particolare: https://aistudio.google.com/app/apikey).

## Se un servizio non risponde

1. Controlla di avere scritto **chiave** *e* **modello** (il pannello mostra `[PRONTO]` solo allora).
2. Verifica il **nome del modello**: e' il motivo piu' comune di errore (un nome sbagliato da' errore 400/404).
3. Controlla la **chiave**: se il servizio dice 401/403, la chiave e' sbagliata, scaduta o senza credito.
4. Per vedere lo stato usa il comando `/ai stato`. Per tornare alla scelta automatica: `/ai auto`.
