﻿# ZAP! v6.6 - Assistente Desktop (Gemini in cloud + Llama locale, grafica personalizzabile)

ZAP! e' un assistente AI per Windows: finestra nativa (PowerShell + WPF), **zero installazioni**.
Il "cervello" e' **in cloud (Google Gemini)** oppure, per le domande semplici, **in locale (Llama)**.

## Novita' della v6.6

- **Basta caccia ai modelli**: la chat usa **UN solo modello** (parte da `gemini-3.1-flash-lite`
  verificato e veloce), con **UN solo ripiego**. Solo se entrambi falliscono cerca un modello
  disponibile **una volta** e lo **ricorda** (`memory\modello_scelto.txt`).
- **Nuova chiave Gemini** inserita e **verificata** (chat + visione funzionanti).

Dalla v6.5: Llama locale (Ollama), pannello **INTELLIGENZE AI** leggibile in oro, pannello
**CAMBIA TEMA E COLORI**, menu senza sovrapposizioni. Dalla v6.4: modalita' **ENTERPRISE**,
`AVVIA_ADMIN.bat`, **appunti**, apprendimento dallo schermo. Dalla v6.3: grafica **AURA**,
upload **foto/video/PDF**, pannello **INSEGNA**.

## Requisiti
- **Windows 10/11**, connessione a internet e una **chiave API Google Gemini** (gia' presente).
- Facoltativo per Llama locale: **Ollama** (https://ollama.com/download) + `ollama pull llama3.1`.

## Avvio
1. Tasto destro su `INSTALLA.ps1` -> "Esegui con PowerShell".
2. Doppio clic su `AVVIA.bat` (oppure `AVVIA_ADMIN.bat` per i pieni permessi).

## Le 5 modalita'
| Modalita' | Comportamento |
|---|---|
| PRUDENTE | chiede sempre prima di agire |
| SMART | fa da solo le cose sicure, chiede per quelle rischiose |
| LIBERA | fa tutto senza chiedere |
| SVILUPPATORE | autonomia piena + riformula/riprova + ricerca web |
| **ENTERPRISE** | autonomia totale, nessun rifiuto, pensiero laterale, impara dallo schermo, si auto-migliora. **Non cancella mai senza conferma** |

## Tema e colori
Pulsante **TEMA** (o `/tema`): temi pronti **AURA / NOTTE / SMERALDO / VIOLA / CHIARO**; oppure
singoli colori e carattere/dimensione. APPLICA = dal vivo + salvato.

## Modelli e velocita'
- Un solo modello per volta: `gemini-3.1-flash-lite` -> un ripiego -> (solo se serve) ricerca
  automatica di un modello disponibile, che viene ricordato.
- In barra: "SCRIVO CON &lt;modello&gt;...".

## Comandi
`/aiuto` `/mode` `/tema` `/appunti` `/impara-schermo` `/migliorati` `/admin` `/skills` `/insegna`
`/allegati` `/foto` `/video` `/allegati-vuota` `/programmi` `/mic` `/ai` `/ferma` `/vuota`

## Note oneste
- **"Senza filtri"**: ZAP non rifiuta mai e usa il pensiero laterale (regola nel prompt). I filtri
  dei **server di Google** non si possono disattivare dal programma.
- **Amministratore**: con `AVVIA_ADMIN.bat` ZAP puo' eseguire qualunque comando; la cancellazione
  resta sempre soggetta alla tua conferma.
- **Grafica WPF**: verificata come struttura/sintassi (non eseguibile fuori da Windows).


## Aggiornamento v6.6.1 (correzioni)
- **Streaming**: la risposta compare mentre arriva (`:streamGenerateContent?alt=sse`), con ripiego
  automatico sulla chiamata classica se lo streaming non riesce.
- **Segreti separati**: le chiavi stanno in `config.local.json` (ignorato da git); `config.json`
  non contiene segreti e non ha piu' il BOM.
- **Niente dirottamento**: `api_base` e' vuoto; se non c'e' nessun servizio pronto il messaggio
  d'errore e' chiaro invece di puntare a un endpoint sbagliato.
- **Meno servizi nel giro**: restano attivi solo Gemini (ricerca/visione/veloce) e OpenAI
  (codice/testo); gli altri si accendono quando c'e' la chiave.
- **Piu' veloce**: timeout ridotti e sonda Ollama piu' paziente (1500 ms) con cache breve.
- **Avatar distinti**: `robot.png`, `robot_parla.png`, `robot_pensa.png` ora sono tre immagini
  diverse (prima erano lo stesso file).
