# Patch ZAP v7.9.9 - Anthropic (Claude) con scelta automatica del modello

Questa patch abilita Anthropic (Claude) nel router multi-servizio di ZAP e fa
scegliere da solo il modello Claude giusto in base al lavoro.

## Cosa cambia
1. config.json: modalita_ai = "auto"; provider_ai.anthropic abilitato
   (modello claude-sonnet-5-5, priorita 80, mappa "modelli");
   gemini.priorita = 60, openai.priorita = 50.
2. config.local.json: aggiunta la chiave anthropic (file privato).
3. brain/provider_ai.ps1: i servizi espongono "priorita"; Resolve-AiProvider
   sceglie il servizio pronto con priorita piu' alta per quel tipo di lavoro.
4. brain/llm.ps1: Invoke-ChatAnthropic usa Get-AnthropicModello e, se Claude
   fallisce, la chat passa al servizio successivo invece di bloccarsi.

## Scelta del modello (in automatico)
| Lavoro | Modello |
|---|---|
| richiesta breve e leggera | claude-haiku-4-5 |
| testo / analisi | claude-sonnet-5-5 |
| programmazione | claude-sonnet-5-5 |
| discorso lungo / complesso | claude-opus-5-5 |

Come funziona: codice e testo vanno a Claude; visione/ricerca/domande rapide
restano su Gemini. Dentro Claude, il modello dipende dal "peso" del discorso
(breve -> Haiku, normale -> Sonnet, lungo/complesso -> Opus).
Cambiare i nomi: config.json -> provider_ai.anthropic.modelli.

## Uso
1. Sostituisci la cartella ZAP-Gemini-v7.9.9 con quella di questo ZIP.
2. Doppio clic su AVVIA.bat.
3. Nel pannello INTELLIGENZE AI lascia il selettore su AUTOMATICO.
4. Se Claude da' errore 401 la chiave non e' valida: rigenerala su
   https://console.anthropic.com/settings/keys (deve iniziare con sk-ant-api03-).

> Sicurezza: config.local.json contiene le tue chiavi. Non condividerlo.
