﻿# tests/test_ai.ps1 -- Test del registro servizi IA, del router e della ripulitura chiavi.
# Funzioni pure: girano su Windows e su Linux (PowerShell 7).
# Nota: le "chiavi finte" qui sotto sono costruite a pezzi di proposito, cosi' il file
# NON contiene mai un valore che sembri una chiave vera (controllo 11-bis).
$ErrorActionPreference = 'Stop'

$base = Split-Path -Parent $PSScriptRoot
. (Join-Path $base 'brain\provider_ai.ps1')
. (Join-Path $base 'brain\log.ps1')

$script:pass = 0
$script:fail = 0
function Assert($cond, $name) {
    if ($cond) { $script:pass++; Write-Host "PASS: $name" -ForegroundColor Green }
    else       { $script:fail++; Write-Host "FAIL: $name" -ForegroundColor Red }
}

Write-Host ''
Write-Host '=== TEST INTELLIGENZE AI (registro + router + chiavi nei log) ===' -ForegroundColor Yellow

# --- registro ---
$reg = @(Get-ProviderRegistry)
Assert ($reg.Count -ge 14) ('Registro servizi presente (' + $reg.Count + ' servizi)')
$ids = @($reg | ForEach-Object { [string]$_.id })
Assert ((@($ids | Sort-Object -Unique).Count) -eq $ids.Count) 'ID dei servizi tutti diversi'
foreach ($atteso in @('gemini','openai','anthropic','qwen','ollama','openrouter','groq','mistral','deepseek','xai','together','perplexity','cerebras','fireworks')) {
    Assert ($ids -contains $atteso) ('Servizio presente: ' + $atteso)
}
foreach ($r in $reg) {
    Assert (([string]$r.endpoint) -like 'http*') ('Endpoint con schema http(s): ' + $r.id)
    Assert ((([string]$r.nome).Trim()).Length -gt 0) ('Nome non vuoto: ' + $r.id)
    Assert (([string]$r.keyurl) -match '^https') ('Pagina della chiave indicata: ' + $r.id)
}

# --- endpoint ufficiali dei servizi richiesti ---
$g = Get-ProviderById 'gemini'
$o = Get-ProviderById 'openai'
$a = Get-ProviderById 'anthropic'
$q = Get-ProviderById 'qwen'
$ol = Get-ProviderById 'ollama'
Assert ((([string]$g.endpoint) -like '*generativelanguage.googleapis.com*')) 'Endpoint Gemini (Google) ufficiale'
Assert ((([string]$o.endpoint) -eq 'https://api.openai.com/v1/chat/completions')) 'Endpoint OpenAI (ChatGPT) ufficiale'
Assert ((([string]$a.endpoint) -eq 'https://api.anthropic.com/v1/messages')) 'Endpoint Anthropic (Claude) ufficiale'
Assert ((([string]$q.endpoint) -like '*dashscope-intl.aliyuncs.com/compatible-mode/v1*')) 'Endpoint Qwen (DashScope OpenAI-compatibile)'
Assert ((([string]$ol.endpoint) -like 'http://localhost:11434/*')) 'Endpoint Ollama (locale, sul tuo PC)'

# --- funzioni di supporto ---
Assert ((Get-ProviderById 'OPENAI') -ne $null) 'Get-ProviderById non distingue maiuscole/minuscole'
Assert ((Get-ProviderById 'inesistente') -eq $null) 'Get-ProviderById: sconosciuto -> null'
$def = Get-DefaultProviderAi
Assert ($def.Count -eq $reg.Count) ('Configurazione di default per tutti i servizi (' + $def.Count + ')')
foreach ($id in $ids) { Assert ($def.ContainsKey($id)) ('Default presente: ' + $id) }

# --- classificazione del lavoro ---
Assert ((Get-AiTaskType 'guarda questa foto dello schermo') -eq 'visione') 'Tipo lavoro: visione'
Assert ((Get-AiTaskType 'cercami su internet le notizie di oggi') -eq 'ricerca') 'Tipo lavoro: ricerca'
Assert ((Get-AiTaskType 'scrivimi uno script powershell che rinomina i file') -eq 'codice') 'Tipo lavoro: codice'
Assert ((Get-AiTaskType 'ciao come stai') -eq 'veloce') 'Tipo lavoro: veloce'
Assert ((Get-AiTaskType ('a' * 700)) -eq 'testo') 'Tipo lavoro: testo (richiesta lunga)'

# --- router con una configurazione finta ---
$sync = [hashtable]::Synchronized(@{})
$sync.Config = @{
    provider = 'gemini'; api_base = ''; api_key = ''; modello = ''
    modalita_ai = 'auto'
    provider_ai = (Get-DefaultProviderAi)
}
Assert ((@(Get-AiPronti $sync).Count) -eq 0) 'Router: nessun servizio pronto senza chiave/modello'
Assert ((Resolve-AiProvider -sync $sync -TaskType 'veloce') -eq $null) 'Router: nessuna scelta se nessuno e pronto'
Assert ((Get-ProviderStato $sync 'openai') -like '*non pronto*') 'Stato: openai non pronto senza chiave'

$sync.Config.provider_ai['openai']['chiave'] = 'chiave-di-prova'
$sync.Config.provider_ai['openai']['modello'] = 'modello-di-prova'
Assert ((@(Get-AiPronti $sync)) -contains 'openai') 'Router: openai pronto con chiave e modello'
$scelto = Resolve-AiProvider -sync $sync -TaskType 'codice'
Assert ($scelto -and ([string]$scelto.id -eq 'openai')) 'Router: sceglie openai per il codice'

$sync.Config.modalita_ai = 'ollama'
$sync.Config.provider_ai['ollama']['modello'] = 'llama3.1'
# v6.5: Ollama conta come pronto SOLO se il programma locale gira: lo simuliamo acceso
$script:OllamaUpCache = $true; $script:OllamaUpQuando = Get-Date
$scelto2 = Resolve-AiProvider -sync $sync -TaskType 'codice'
Assert ($scelto2 -and ([string]$scelto2.id -eq 'ollama')) 'Router: rispetta il servizio fissato a mano'
Assert ($scelto2 -and ([string]$scelto2.chiave -eq '')) 'Router: Ollama non richiede chiave'
$sync.Config.modalita_ai = 'auto'
# v6.5: con Ollama acceso le domande SEMPLICI vanno in locale (Llama)
$vloc = Resolve-AiProvider -sync $sync -TaskType 'veloce'
Assert ($vloc -and ([string]$vloc.id -eq 'ollama')) 'Router: domande semplici -> Llama locale (acceso)'
# v6.5: con Ollama SPENTO non viene scelto (non ci si blocca su un servizio spento)
$script:OllamaUpCache = $false; $script:OllamaUpQuando = Get-Date
Assert (-not (Test-ProviderReady $sync 'ollama')) 'Router: Ollama spento NON e pronto'
$scelto2b = Resolve-AiProvider -sync $sync -TaskType 'veloce'
Assert ($scelto2b -and ([string]$scelto2b.id -ne 'ollama')) 'Router: con Ollama spento usa il cloud'

$sync.Config.provider_ai['gemini']['chiave'] = 'chiave-di-prova'
$sync.Config.provider_ai['gemini']['modello'] = 'gemini-di-prova'
$v = Resolve-AiProvider -sync $sync -TaskType 'visione'
Assert ($v -and ([string]$v.id -eq 'gemini')) 'Router: per la visione sceglie gemini'
$alt = Get-ProviderAlternativo -sync $sync -Escludi 'gemini'
Assert ($alt -and ([string]$alt.id -eq 'openai')) 'Router: se Gemini non risponde si ripiega su un altro servizio pronto'

# --- le chiavi non finiscono nei log (valori costruiti a pezzi: nessun segreto nel sorgente) ---
$kSk = 'sk-' + 'ABCDEFGHIJKLMNOP' + '0123456789'
$kG  = 'gsk_' + 'ABCDEFGHIJKLMNOP0123456789'
$kH  = 'hf_' + 'ABCDEFGHIJKLMNOP0123456789'
$kAq = 'AQ.' + 'chiaveFintaDiProva123456'
$sporca = ('chiave=' + $kSk + ' e ' + $kG + ' e ' + $kH + ' e ' + $kAq)
$pulita = Protect-LogText $sporca
Assert (-not $pulita.Contains($kSk)) 'Log: rimuove le chiavi sk-...'
Assert (-not $pulita.Contains($kG)) 'Log: rimuove le chiavi gsk_...'
Assert (-not $pulita.Contains($kH)) 'Log: rimuove le chiavi hf_...'
Assert (-not $pulita.Contains($kAq)) 'Log: rimuove le chiavi Gemini AQ.'
$tok = 'abcdefgh' + '12345678'
$pulita2 = Protect-LogText ('Authorization: Bearer ' + $tok + ' e x-api-key: ' + $tok)
Assert (-not $pulita2.Contains($tok)) 'Log: rimuove il token Bearer e x-api-key'

Write-Host ''
Write-Host ("RISULTATO AI: $script:pass passati, $script:fail falliti") -ForegroundColor $(if ($script:fail -eq 0) { 'Green' } else { 'Red' })
if ($script:fail -gt 0) { exit 1 } else { exit 0 }
