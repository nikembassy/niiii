﻿# Prova RAPIDA del cervello Gemini. Nessuna finestra, nessun modello locale.
$ErrorActionPreference = 'Continue'
$base = Split-Path -Parent $PSScriptRoot

Write-Host ''
Write-Host '=== Test cervello Gemini ===' -ForegroundColor Yellow
Write-Host ('PowerShell : ' + $PSVersionTable.PSVersion)

$cfgPath = Join-Path $base 'config.json'
if (-not (Test-Path $cfgPath)) { Write-Host ('config.json NON TROVATO in ' + $base) -ForegroundColor Red; return }
$cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$k = [string]$cfg.api_key
$m = [string]$cfg.modello
if (-not $m) { $m = 'gemini-3.6-flash' }
Write-Host ('provider   : ' + [string]$cfg.provider)
Write-Host ('modello    : ' + $m)
if (-not $k) { Write-Host 'chiave     : MANCANTE in config.json' -ForegroundColor Red; return }
Write-Host ('chiave     : presente (' + $k.Length + ' caratteri) - NON stampata per sicurezza')

# usa lo stesso serializzatore di ZAP (evita il bug delle liste di 1 elemento di PS 5.1)
. (Join-Path $base 'brain\llm.ps1')

$body = @{ contents = @( @{ role = 'user'; parts = @( @{ text = 'Rispondi solo: OK, ti sento!' } ) } ) }
$json = ConvertTo-JsonText $body
Write-Host ''
Write-Host ('JSON inviato: ' + $json)
Write-Host ''

try {
    $uri = 'https://generativelanguage.googleapis.com/v1beta/models/' + $m + ':generateContent'
    $r = Invoke-RestMethod -Uri $uri -Method Post -Headers @{ 'x-goog-api-key' = $k } `
        -ContentType 'application/json; charset=utf-8' `
        -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 40
    Write-Host 'RISPOSTA DI GEMINI:' -ForegroundColor Green
    Write-Host ($r.candidates[0].content.parts[0].text) -ForegroundColor Green
    Write-Host ''
    Write-Host '=> IL CERVELLO FUNZIONA!' -ForegroundColor Green
} catch {
    Write-Host 'ERRORE:' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    $detail = ''
    try {
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $detail = $_.ErrorDetails.Message }
        elseif ($_.Exception.Response) {
            $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $detail = $sr.ReadToEnd(); $sr.Close()
        }
    } catch { }
    if ($detail) { Write-Host ''; Write-Host 'DETTAGLIO DAL SERVER:' -ForegroundColor Red; Write-Host $detail -ForegroundColor Red }
    Write-Host ''
    Write-Host '=> Problema di RETE, CHIAVE o formato richiesta.' -ForegroundColor Yellow
}
