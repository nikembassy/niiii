﻿# tests/test_v5.ps1 -- Test della v5: autonomia, programmi, controllo PC, tema, log.
# Guardia: se un comando non esiste (o un errore non viene gestito) i test si
# FERMANO subito, invece di stampare "0 falliti" come se fosse tutto a posto.
# E' esattamente il difetto che nascondeva il blocco di AVVIA.bat.
$ErrorActionPreference = 'Stop'

$base = Split-Path -Parent $PSScriptRoot
foreach ($m in @('brain\log.ps1', 'brain\tema.ps1', 'brain\modalita.ps1', 'brain\autonomia.ps1', 'brain\programmi.ps1', 'brain\pc_controllo.ps1')) {
    . (Join-Path $base $m)
}

$script:pass = 0
$script:fail = 0
function Assert($cond, $name) {
    if ($cond) { $script:pass++; Write-Host "PASS: $name" -ForegroundColor Green }
    else       { $script:fail++; Write-Host "FAIL: $name" -ForegroundColor Red }
}

Write-Host ''
Write-Host '=== TEST v5: autonomia, programmi, controllo PC, tema, log ===' -ForegroundColor Yellow

# ------------------------------------------------------------------ AUTONOMIA
Write-Host '-- autonomia (modalita sviluppatore)' -ForegroundColor Cyan
Assert ((Test-RispostaRifiuto 'Mi dispiace, ma non posso aiutarti con questa richiesta.')) 'Rifiuto: riconosce un rifiuto'
Assert ((Test-RispostaRifiuto "I can't help with that.")) 'Rifiuto: riconosce un rifiuto in inglese'
Assert ((Test-RispostaRifiuto 'Non posso fornire istruzioni di quel tipo.')) 'Rifiuto: riconosce "non posso fornire"'
Assert ((Test-RispostaRifiuto 'Ecco come si fa: apri il terminale e digita...') -eq $false) 'Rifiuto: una risposta vera NON e un rifiuto'
Assert ((Test-RispostaRifiuto '') -eq $false) 'Rifiuto: testo vuoto non e un rifiuto'
Assert ((Test-RispostaRifiuto 'ok') -eq $false) 'Rifiuto: testo troppo corto non e un rifiuto'

$rp1 = Get-RiprovaPrompt 'come apro una porta' 1
Assert ($rp1 -like '*Riformula*') 'Riprova 1: chiede di riformulare'
Assert ($rp1 -like '*come apro una porta*') 'Riprova 1: contiene la richiesta originale'
$rp2 = Get-RiprovaPrompt 'come apro una porta' 2
Assert ($rp2 -like '*SVILUPPATORE*') 'Riprova 2: invoca la modalita sviluppatore'
Assert ($rp2 -like '*web_search*') 'Riprova 2: indica gli strumenti di ricerca'

Assert ((Get-RicercaAutonomaQuery 'dimmi come si fa a stampare') -eq 'stampare') 'Query: toglie "dimmi come si fa a"'
Assert ((Get-RicercaAutonomaQuery 'Come si fa a stampare in rete?') -eq 'stampare in rete') 'Query: toglie l interrogativo finale'
Assert ((Get-RicercaAutonomaQuery '   ') -eq '') 'Query: testo vuoto resta vuoto'
$lungo = ('x' * 400)
Assert ((Get-RicercaAutonomaQuery $lungo).Length -le 140) 'Query: tronca le richieste lunghissime'

$rap = Get-RapportoRicerca 'il mio problema' 'soluzione trovata'
Assert ($rap -like '*RESOCONTO RAPIDO*') 'Rapporto: ha il titolo richiesto'
Assert ($rap -like '*il mio problema*') 'Rapporto: riporta la richiesta'
$testoLungo = ('a' * 5000)
Assert ((Get-RapportoRicerca 'q' $testoLungo 200).Length -le 260) 'Rapporto: accorcia i testi lunghi'

$promptSvil = Get-SviluppatorePrompt -sync @{ Config = @{ browser = 'thorium'; motore_ricerca = 'yandex'; sicurezza = 'sviluppatore' } } -Nome 'ZAP'
Assert ($promptSvil -like '*MODALITA* SVILUPPATORE*') 'Prompt sviluppatore: modalita dichiarata'
Assert ($promptSvil -like '*thorium*') 'Prompt sviluppatore: usa il browser scelto'
Assert ($promptSvil -like '*yandex*') 'Prompt sviluppatore: usa il motore scelto'
Assert ($promptSvil -like '*RESOCONTO RAPIDO*') 'Prompt sviluppatore: chiede il resoconto'
Assert ($promptSvil -like '*RIFORMULA e riprova*') 'Prompt sviluppatore: riformula sui rifiuti'
Assert ($promptSvil -like '*anti-bot*') 'Prompt sviluppatore: NON aggira l anti-bot'

# ------------------------------------------------------------------ PROGRAMMI
Write-Host '-- programmi (cartella reale temporanea)' -ForegroundColor Cyan
$dir = Join-Path ([System.IO.Path]::GetTempPath()) ('zapv5-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $dir | Out-Null
foreach ($f in @('alfa.ps1', 'beta.bat', 'gamma.txt', 'delta.exe', 'epsilon.lnk', 'zeta.py', 'eta.ahk')) {
    Set-Content -Path (Join-Path $dir $f) -Value '# prova' -Encoding UTF8
}
$fakeSync = @{ Base = $dir; Config = @{ programmi = @{ cartella = '.' } } }

Assert ((Get-ProgrammiConfig $fakeSync).cartella -eq '.') 'Programmi: legge la cartella configurata'
Assert ((Get-ProgrammiConfig @{ Config = @{} }).cartella -eq 'programmi') 'Programmi: cartella predefinita'
$voci = @(Get-ProgrammiScansionati $dir)
Assert ($voci.Count -eq 6) 'Programmi: conta solo le estensioni utili (6 su 7)'
Assert (@($voci | Where-Object { $_.file -eq 'gamma.txt' }).Count -eq 0) 'Programmi: i .txt vengono ignorati'

$c1 = Get-ProgrammaComando 'C:\mio\script.ps1'
Assert ($c1.file -eq 'powershell.exe' -and ($c1.argomenti -contains '-File')) 'Comando: .ps1 con powershell -File'
$c2 = Get-ProgrammaComando 'C:\mio\avvio.bat'
Assert ($c2.file -eq 'cmd.exe' -and ($c2.argomenti -contains '/c')) 'Comando: .bat con cmd /c'
$c3 = Get-ProgrammaComando 'C:\mio\script.py'
Assert ($c3.file -eq 'python.exe') 'Comando: .py con python'
$c4 = Get-ProgrammaComando 'C:\mio\app.exe'
Assert ($c4.file -eq 'C:\mio\app.exe' -and $c4.argomenti.Count -eq 0) 'Comando: .exe diretto'

Assert ((Resolve-ProgrammaDaNome $fakeSync 'alfa').nome -eq 'alfa') 'Programmi: trova per nome esatto'
Assert ((Resolve-ProgrammaDaNome $fakeSync 'ALFA').nome -eq 'alfa') 'Programmi: ignora le maiuscole'
Assert ((Resolve-ProgrammaDaNome $fakeSync 'del').nome -eq 'delta') 'Programmi: trova per contenuto'
Assert ($null -eq (Resolve-ProgrammaDaNome $fakeSync 'inesistente')) 'Programmi: nome assente -> null'

$elenco = Format-ProgrammiElenco $fakeSync
Assert ($elenco -like '*Trovati 6 programmi*') 'Elenco: numero corretto'
Assert ($elenco -like '*alfa*') 'Elenco: elenca i nomi'
Assert ($elenco -like '*lancia*') 'Elenco: spiega come lanciare'

$dirVuota = Join-Path ([System.IO.Path]::GetTempPath()) ('zapv5b-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $dirVuota | Out-Null
$svuota = @{ Base = $dirVuota; Config = @{ programmi = @{ cartella = '.' } } }
Assert ((Format-ProgrammiElenco $svuota) -like '*Nessun programma trovato*') 'Elenco: cartella vuota spiegata'

$absProva = [System.IO.Path]::GetFullPath('zap_prova_assoluta')
$ass = Get-ProgrammiDir @{ Base = 'X'; Config = @{ programmi = @{ cartella = $absProva } } }
Assert ($ass -eq $absProva) 'Percorso: cartella assoluta rispettata'
$rel = Get-ProgrammiDir @{ Base = $dir; Config = @{ programmi = @{ cartella = 'programmi' } } }
Assert ($rel -like ($dir + '*')) 'Percorso: cartella relativa agganciata alla base'

# ------------------------------------------------------------------ CONTROLLO PC
Write-Host '-- controllo PC (parser dei comandi)' -ForegroundColor Cyan
$r = Resolve-ComandoDiretto $fakeSync 'chiudimi questa pagina'
Assert ($r.Azione -eq 'chiudi_finestra') 'PC: "chiudimi questa pagina"'
Assert ($r.Filtro -eq '') 'PC: chiude la finestra attiva senza filtro'
$r = Resolve-ComandoDiretto $fakeSync 'chiudi la finestra di youtube'
Assert ($r.Azione -eq 'chiudi_finestra' -and $r.Filtro -eq 'youtube') 'PC: chiude una finestra specifica'
$r = Resolve-ComandoDiretto $fakeSync 'aprimi al volo un nuovo blocco note'
Assert ($r.Azione -eq 'apri_programma' -and $r.Nome -eq 'blocco note') 'PC: "aprimi al volo un nuovo blocco note"'
$r = Resolve-ComandoDiretto $fakeSync 'apri whatsapp e scrivi a Mario: ci vediamo alle 8'
Assert ($r.Azione -eq 'whatsapp') 'PC: WhatsApp riconosciuto'
Assert ($r.Destinatario -eq 'Mario') 'PC: destinatario estratto'
Assert ($r.Messaggio -eq 'ci vediamo alle 8') 'PC: messaggio estratto'
$r = Resolve-ComandoDiretto $fakeSync 'manda un messaggio a Luca su whatsapp, domani non ci sono'
Assert ($r.Azione -eq 'whatsapp' -and $r.Destinatario -eq 'Luca') 'PC: variante "manda ... su whatsapp"'
$r = Resolve-ComandoDiretto $fakeSync 'apri www.repubblica.it'
Assert ($r.Azione -eq 'apri_sito' -and $r.Url -eq 'www.repubblica.it') 'PC: apre un sito'
$r = Resolve-ComandoDiretto $fakeSync 'elenca le finestre aperte'
Assert ($r.Azione -eq 'elenca_finestre') 'PC: elenca le finestre'
$r = Resolve-ComandoDiretto $fakeSync 'quali programmi ho'
Assert ($r.Azione -eq 'elenca_programmi') 'PC: elenca i programmi'
$r = Resolve-ComandoDiretto $fakeSync 'lancia il mio backup'
Assert ($r.Azione -eq 'lancia_programma' -and $r.Nome -eq 'backup') 'PC: lancia un mio programma'
$r = Resolve-ComandoDiretto $fakeSync 'scrivi ciao mondo'
Assert ($r.Azione -eq 'scrivi_testo' -and $r.Testo -eq 'ciao mondo') 'PC: scrive testo'
$r = Resolve-ComandoDiretto $fakeSync 'cerca ricette di pizza'
Assert ($r.Azione -eq 'cerca' -and $r.Query -eq 'ricette di pizza') 'PC: cerca sul web'
$r = Resolve-ComandoDiretto $fakeSync 'minimizza'
Assert ($r.Azione -eq 'minimizza_finestra') 'PC: minimizza'
$r = Resolve-ComandoDiretto $fakeSync 'ciao, come stai?'
Assert ($r.Azione -eq '') 'PC: una frase normale NON e un comando diretto'
$r = Resolve-ComandoDiretto $fakeSync 'apri il programma alfa'
Assert ($r.Azione -eq 'lancia_programma' -and $r.Nome -eq 'alfa') 'PC: "apri il programma alfa" trova il mio programma'

Assert ((Remove-ArticoliIniziali 'il blocco note') -eq 'blocco note') 'PC: toglie l articolo'
Assert ((Test-SembraIndirizzo 'https://x.it') -and (Test-SembraIndirizzo 'www.x.it') -and (Test-SembraIndirizzo 'x.com')) 'PC: riconosce gli indirizzi'
Assert ((Test-SembraIndirizzo 'blocco note') -eq $false) 'PC: "blocco note" non e un indirizzo'
Assert ((Get-AppNoti)['blocco note'] -eq 'notepad') 'PC: mappa delle app nota'

# v6.2: nessun blocco didattico; un comando riconosciuto viene gestito
$syncOk = @{ Base = $dir; Config = @{ sicurezza = 'smart'; programmi = @{ cartella = '.' } } }
$dc = Invoke-ComandoDiretto $syncOk 'chiudimi questa pagina'
Assert ($dc.Gestito -eq $true) 'PC: il comando riconosciuto viene gestito'
# comando di sola lettura eseguito davvero (su questo sistema non e Windows -> messaggio chiaro)
$dc2 = Invoke-ComandoDiretto $syncOk 'elenca le finestre aperte'
Assert ($dc2.Gestito -eq $true) 'PC: comando di sola lettura gestito'
Assert ([string]$dc2.Messaggio -like '*finestr*') 'PC: risposta leggibile sul sistema attuale'
$dc3 = Invoke-ComandoDiretto $syncOk 'quali programmi ho'
Assert ([string]$dc3.Messaggio -like '*alfa*') 'PC: elenco programmi reale eseguito'

# ------------------------------------------------------------------ TEMA
Write-Host '-- tema' -ForegroundColor Cyan
$fumetto = "<Window Background='#FFFDF3D6' FontFamily='Comic Sans MS'><Setter Property='Foreground' Value='Black'/></Window>"
Assert (((Get-TemaXaml $fumetto 'oro')) -like '*#0E1116*') 'Tema: la nuova grafica si applica'
$fut = Get-TemaXaml $fumetto 'oro'
Assert ($fut -notlike '*#FFFDF3D6*') 'Tema: lo sfondo chiaro viene sostituito'
Assert ($fut -like '*#0E1116*') 'Tema: entra lo sfondo scuro'
Assert ($fut -notlike '*Comic Sans MS*') 'Tema: cambia anche il font'
Assert ((Get-TemaXaml 'x#FFFFD54Fy' 'oro') -eq 'x#D4AF37y') 'Tema: entra l accento oro'

$xamlReale = Get-Content (Join-Path $base 'ui\window.xaml') -Raw -Encoding UTF8
$xamlFut = Get-TemaXaml $xamlReale 'oro'
$residui = @()
foreach ($c in (Get-TemaColoriChiari)) { if ($xamlFut -like ('*' + $c + '*')) { $residui += $c } }
Assert ($residui.Count -eq 0) ('Tema: nessun colore chiaro residuo sul file vero' + $(if ($residui) { ' -> ' + ($residui -join ',') } else { '' }))
Assert ($xamlFut -notlike '*Comic Sans MS*') 'Tema: nessun Comic Sans residuo sul file vero'

# ------------------------------------------------------------------ LOG SENZA SEGRETI
Write-Host '-- log senza segreti' -ForegroundColor Cyan
$chiaveFinta = ('AQ.' + 'Ab8RN6KJfGl7LYbtMwLaYVOggmlhsysIQ9wqWTQWluFbqXuHUQ')
$chiaveAi    = ('AIza' + 'SyDabcdefghijklmnopqrstuvwxyz012345')
$testo = ('chiave = ' + $chiaveFinta + "`n" + 'Authorization: Bearer abcdef0123456789' + "`n" + '{"api_key": "' + $chiaveAi + '"}' + "`n" + '?key=' + $chiaveFinta)
$pulito = Protect-LogText $testo
Assert ($pulito -notlike ('*' + $chiaveFinta + '*')) 'Log: la chiave AQ sparisce'
Assert ($pulito -notlike ('*' + $chiaveAi + '*')) 'Log: la chiave AIza sparisce'
Assert ($pulito -like '*RIMOSSA*') 'Log: il posto della chiave e marcato'
Assert ($pulito -notlike '*abcdef0123456789*') 'Log: il token Bearer sparisce'
Assert ((Protect-LogText 'nessun segreto qui') -eq 'nessun segreto qui') 'Log: il testo normale non viene toccato'
Assert ((Test-ContieneSegreti $chiaveFinta)) 'Log: rileva un segreto'
Assert ((Test-ContieneSegreti 'testo pulito') -eq $false) 'Log: non segnala falsi positivi'

$fLog = Join-Path $dir 'prova.log'
Set-Content -Path $fLog -Value ('api_key=' + $chiaveFinta) -Encoding UTF8
$cambiato = Protect-LogFile $fLog
$contenuto = Get-Content $fLog -Raw -Encoding UTF8
Assert ($cambiato -eq $true) 'Log: il file viene ripulito'
Assert ($contenuto -notlike ('*' + $chiaveFinta + '*')) 'Log: nel file non resta la chiave'

$fLog2 = Join-Path $dir 'prova2.log'
Add-LogLine $fLog2 ('chiave usata: ' + $chiaveFinta)
Assert ((Get-Content $fLog2 -Raw -Encoding UTF8) -notlike ('*' + $chiaveFinta + '*')) 'Log: Add-LogLine non scrive segreti'

# --- Pulizia ---
try { Remove-Item $dir -Recurse -Force } catch { }
try { Remove-Item $dirVuota -Recurse -Force } catch { }

Write-Host ''
Write-Host "RISULTATO v5: $script:pass passati, $script:fail falliti" -ForegroundColor $(if ($script:fail -eq 0) { 'Green' } else { 'Red' })
if ($script:fail -gt 0) { exit 1 } else { exit 0 }
