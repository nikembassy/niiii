﻿# tests/test_voce.ps1 -- Test del modulo voce (stt.ps1): scelta del motore e stati di errore.
# Gira anche su Linux: qui NON esistono i motori vocali di Windows, quindi si verifica che il
# modulo non si rompa e restituisca i marcatori giusti (e' il caso peggiore, utile come prova).
$ErrorActionPreference = 'Stop'

$base = Split-Path -Parent $PSScriptRoot
. (Join-Path $base 'voice\stt.ps1')

$script:pass = 0
$script:fail = 0
function Assert($cond, $name) {
    if ($cond) { $script:pass++; Write-Host "PASS: $name" -ForegroundColor Green }
    else       { $script:fail++; Write-Host "FAIL: $name" -ForegroundColor Red }
}

Write-Host ''
Write-Host '=== TEST VOCE (stt.ps1: motore moderno/storico + stati di errore) ===' -ForegroundColor Yellow

foreach ($f in @('Test-SpeechAvailable','Get-SpeechDiagnostica','Start-Listen','Update-Listen','Stop-Listen','Get-ListenResult','Initialize-VoceWinRT','New-VoceWinRT','New-VoceLegacy')) {
    Assert ([bool](Get-Command $f -ErrorAction SilentlyContinue)) ('Funzione presente: ' + $f)
}

$w = $false
try { $w = [bool](Initialize-VoceWinRT) } catch { }
Assert ($w -eq $false -or $w -eq $true) 'Initialize-VoceWinRT risponde si/no senza eccezioni'

$r = $null
try { $r = New-VoceWinRT 'it-IT' } catch { }
Assert ($null -eq $r) 'New-VoceWinRT senza motore moderno restituisce $null (nessuna eccezione)'

$leg = $null
try { $leg = New-VoceLegacy 'it-IT' } catch { }
Assert ($leg -ne $null) 'New-VoceLegacy restituisce un esito (non lancia eccezioni)'
Assert ($leg.ContainsKey('Engine') -and $leg.ContainsKey('Modo') -and $leg.ContainsKey('Errore')) 'New-VoceLegacy: esito con Engine/Modo/Errore'
if (-not $leg.Engine) {
    Assert (([string]$leg.Errore).Length -gt 0) 'Senza motore storico, New-VoceLegacy spiega il motivo'
}

$att = $false
try { $att = [bool](Test-SpeechAvailable) } catch { }
Assert ($att -eq $false -or $att -eq $true) 'Test-SpeechAvailable risponde si/no senza eccezioni'

# Senza nessun motore: Start-Listen non deve bloccare e Update-Listen deve consegnare !NESSUN_MIC.
$sync = [hashtable]::Synchronized(@{})
$sync.Config = @{}
$sync.Listening = $true
Start-Listen -sync $sync -Culture 'it-IT' -TimeoutSec 1
Assert ((@('spento','winrt','storico') -contains [string]$sync.MicModo)) 'Start-Listen imposta MicModo'
if (-not $sync.MicAttivo) {
    $ris = Update-Listen -sync $sync
    Assert ($null -ne $ris) 'Update-Listen consegna subito il risultato quando non c e motore'
    Assert (([string]$ris.Errore) -like '!NESSUN_MIC*') 'Senza motore il marcatore e !NESSUN_MIC'
} else {
    Assert $true 'Motore vocale presente su questo sistema (prova su Windows)'
}
Stop-Listen -sync $sync
Assert ($sync.MicAttivo -eq $false) 'Stop-Listen spegne MicAttivo'
Assert ([string]$sync.MicModo -eq 'spento') 'Stop-Listen riporta MicModo a spento'

$dg = ''
try { $dg = [string](Get-SpeechDiagnostica) } catch { }
Assert ($dg -like '*DIAGNOSI MICROFONO*') 'Get-SpeechDiagnostica produce la diagnosi'
Assert ($dg -like '*Motore MODERNO*') 'La diagnosi nomina il motore moderno'
Assert ($dg -like '*Motore STORICO*') 'La diagnosi nomina il motore storico'
Assert ($dg -like '*Permesso*' -or $dg -like '*Privacy*' -or $dg -like '*Microfono*') 'La diagnosi spiega i permessi/microfono'

Write-Host ''
Write-Host ("RISULTATO VOCE: $script:pass passati, $script:fail falliti") -ForegroundColor $(if ($script:fail -eq 0) { 'Green' } else { 'Red' })
if ($script:fail -gt 0) { exit 1 } else { exit 0 }
