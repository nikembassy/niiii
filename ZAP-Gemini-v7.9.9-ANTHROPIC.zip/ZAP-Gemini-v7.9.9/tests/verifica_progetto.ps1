﻿# tests/verifica_progetto.ps1 -- Controlla l'intero progetto: file, sintassi, BOM,
# CRLF dei .bat, prerequisiti nei .bat, JSON, XAML, coerenza fra interfaccia e codice,
# strumenti vs dispatcher, segnaposto, segreti nei log. Gira anche senza Windows.

# Guardia: se un comando non esiste (o un errore non viene gestito) i test si
# FERMANO subito, invece di stampare "0 falliti" come se fosse tutto a posto.
# E' esattamente il difetto che nascondeva il blocco di AVVIA.bat.
$ErrorActionPreference = 'Stop'

$base = Split-Path -Parent $PSScriptRoot
$script:pass = 0
$script:fail = 0
function Assert($cond, $name) {
    if ($cond) { $script:pass++; Write-Host "PASS: $name" -ForegroundColor Green }
    else       { $script:fail++; Write-Host "FAIL: $name" -ForegroundColor Red }
}

Write-Host ''
Write-Host '=== VERIFICA INTEGRITA DEL PROGETTO ===' -ForegroundColor Yellow

# --- 1. File attesi ---
$attesi = @(
    'AVVIA.ps1', 'AVVIA.bat', 'INSTALLA.ps1', 'INSTALLA.bat', 'DIAGNOSTICA.bat',
    'TEST_V5.bat', 'PROVA_MIC.ps1', 'PROVA_MIC.bat', 'TEST_GEMINI.bat', 'AVVIA_DEBUG.bat', 'AVVIA_ADMIN.bat',
    'config.json', 'README.md', 'ISTRUZIONI.txt', 'MANUALE_V5.md',
    'SBLOCCO_ANTIVIRUS.ps1', 'brain\comandi_pericolosi.txt',
    'brain\agent.ps1', 'brain\llm.ps1', 'brain\tools.ps1', 'brain\modalita.ps1',
    'brain\autonomia.ps1', 'brain\programmi.ps1', 'brain\pc_controllo.ps1', 'brain\tema.ps1', 'brain\log.ps1',
    'brain\provider_ai.ps1',
    'ui\window.xaml', 'ui\avatar\robot.png', 'voice\tts.ps1', 'voice\stt.ps1',
    'tests\selftest.ps1', 'tests\test_gemini.ps1', 
    'tests\test_v5.ps1', 'tests\test_ai.ps1', 'tests\test_voce.ps1', 'tests\verifica_progetto.ps1',
    'skills\registry.json', 'skills\riepilogo_pc.ps1', 'memory\notes.md', 'ISTRUZIONI_API_KEY.md'
)
$mancanti = @()
foreach ($f in $attesi) { if (-not (Test-Path (Join-Path $base $f))) { $mancanti += $f } }
Assert ($mancanti.Count -eq 0) ('File attesi presenti (' + $attesi.Count + ')' + $(if ($mancanti) { ' MANCANTI: ' + ($mancanti -join ', ') } else { '' }))

# --- 2. Sintassi di tutti gli .ps1 ---
$ps1 = @(Get-ChildItem -Path $base -Recurse -Filter *.ps1 | Sort-Object FullName)
$errori = @()
foreach ($f in $ps1) {
    $e = $null; $t = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$t, [ref]$e)
    if ($e -and $e.Count -gt 0) { $errori += ($f.Name + ': ' + $e[0].Message) }
}
Assert ($errori.Count -eq 0) ('Sintassi di ' + $ps1.Count + ' script .ps1' + $(if ($errori) { ' ERRORI: ' + ($errori -join ' | ') } else { '' }))

# --- 3. BOM su tutti i .ps1 (serve a Windows PowerShell 5.1 per leggere gli accenti) ---
$senzaBom = @()
foreach ($f in $ps1) {
    $b = [System.IO.File]::ReadAllBytes($f.FullName)
    if (-not ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF)) { $senzaBom += $f.Name }
}
Assert ($senzaBom.Count -eq 0) ('BOM UTF-8 presente in tutti i .ps1' + $(if ($senzaBom) { ' SENZA: ' + ($senzaBom -join ', ') } else { '' }))

# --- 4. .bat: CRLF, senza BOM, avvio dalla propria cartella, prerequisiti, percorsi quotati ---
$bats = @(Get-ChildItem -Path $base -Filter *.bat | Sort-Object Name)
Assert ($bats.Count -ge 6) ('File .bat presenti (' + $bats.Count + ')')
foreach ($f in $bats) {
    $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
    $testo = [System.Text.Encoding]::ASCII.GetString($bytes)
    $crlf = 0; $lfTot = 0
    for ($i = 0; $i -lt $bytes.Length; $i++) { if ($bytes[$i] -eq 10) { $lfTot++; if ($i -gt 0 -and $bytes[$i - 1] -eq 13) { $crlf++ } } }
    Assert (($lfTot -eq $crlf) -and ($lfTot -gt 0)) ($f.Name + ': righe tutte CRLF')
    Assert (-not ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)) ($f.Name + ': nessun BOM (cmd non lo digerisce)')
    Assert ($testo.Contains('cd /d "%~dp0"')) ($f.Name + ': si avvia dalla propria cartella')
    Assert ($testo.Contains('where powershell')) ($f.Name + ': controlla il prerequisito PowerShell')
    Assert ($testo.Contains('"%~dp0')) ($f.Name + ': percorsi quotati')
}

# --- 5. config.json ---
$cfgOk = $false; $cfgObj = $null
try { $cfgObj = Get-Content (Join-Path $base 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json; $cfgOk = $true } catch { }
Assert $cfgOk 'config.json e JSON valido'
if ($cfgOk) {
    foreach ($k in @('nome', 'provider', 'api_key', 'modello', 'sicurezza', 'browser', 'motore_ricerca', 'voce', 'programmi', 'provider_ai', 'modalita_ai')) {
        Assert (($cfgObj.PSObject.Properties.Name -contains $k)) ('config.json: chiave ' + $k)
    }
    $modiValidi = @('prudente', 'smart', 'libera', 'sviluppatore', 'enterprise')
    Assert ($modiValidi -contains [string]$cfgObj.sicurezza) 'config.json: la modalita salvata e valida'
}

# --- 6. registro skill ---
$regOk = $false
try { $null = Get-Content (Join-Path $base 'skills\registry.json') -Raw -Encoding UTF8 | ConvertFrom-Json; $regOk = $true } catch { }
Assert $regOk 'skills/registry.json e JSON valido'

# --- 7. window.xaml: XML ben formato + x:Name unici ---
$xamlTxt = Get-Content (Join-Path $base 'ui\window.xaml') -Raw -Encoding UTF8
$xmlOk = $false
try { $null = [xml]$xamlTxt; $xmlOk = $true } catch { }
Assert $xmlOk 'window.xaml e XML ben formato'
$nomi = @([regex]::Matches($xamlTxt, 'x:Name="([^"]+)"') | ForEach-Object { $_.Groups[1].Value })
Assert ($nomi.Count -gt 0) ('window.xaml: controlli nominati (' + $nomi.Count + ')')
Assert ((@($nomi | Sort-Object -Unique).Count) -eq $nomi.Count) 'window.xaml: tutti i nomi dei controlli sono diversi'

# --- 8. ogni controllo usato dal codice esiste nella finestra ---
$avviaSrc = Get-Content (Join-Path $base 'AVVIA.ps1') -Raw -Encoding UTF8
$cercati = @([regex]::Matches($avviaSrc, "FindName\('([^']+)'\)") | ForEach-Object { $_.Groups[1].Value })
$nonTrovati = @()
foreach ($c in $cercati) { if ($nomi -notcontains $c) { $nonTrovati += $c } }
Assert ($nonTrovati.Count -eq 0) ('Ogni controllo usato da AVVIA.ps1 esiste nella finestra (' + $cercati.Count + ')' + $(if ($nonTrovati) { ' SENZA: ' + ($nonTrovati -join ', ') } else { '' }))

# --- 9. strumenti vs dispatcher ---
. (Join-Path $base 'brain\tools.ps1')
$nomiTool = @((Get-AgentTools) | ForEach-Object { $_.function.name } | Sort-Object)
$srcTools = Get-Content (Join-Path $base 'brain\tools.ps1') -Raw -Encoding UTF8
$i0 = $srcTools.IndexOf('function Invoke-AgentTool')
$blocco = $srcTools.Substring($i0)
$iEnd = $blocco.IndexOf("`nfunction ", 10)
if ($iEnd -gt 0) { $blocco = $blocco.Substring(0, $iEnd) }
$casi = @([regex]::Matches($blocco, "(?m)^ {8}'([a-z_]+)'\s*\{") | ForEach-Object { $_.Groups[1].Value } | Sort-Object)
Assert ($nomiTool.Count -ge 16) ('Strumenti dichiarati: ' + $nomiTool.Count)
Assert ((Compare-Object $nomiTool $casi).Count -eq 0) ('Ogni strumento ha il suo caso nel dispatcher (dichiarati ' + $nomiTool.Count + ', gestiti ' + $casi.Count + ')')

# --- 10. i moduli nuovi sono caricati automaticamente ---
foreach ($m in @('log.ps1', 'tema.ps1', 'modalita.ps1', 'autonomia.ps1', 'programmi.ps1', 'pc_controllo.ps1')) {
    Assert ($srcTools -like ('*' + $m + '*')) ('tools.ps1 carica ' + $m)
}

# --- 11. nessun segnaposto ---
$sospetti = @()
foreach ($f in @(Get-ChildItem -Path $base -Recurse -File | Where-Object { $_.Extension -in @('.ps1', '.bat', '.cmd', '.xaml', '.md', '.txt', '.json') })) {
    # questo file contiene per forza i termini da cercare: si esclude da solo
    if ($f.Name -eq 'verifica_progetto.ps1') { continue }
    $t = Get-Content $f.FullName -Raw -Encoding UTF8
    foreach ($tok in @('TODO', 'FIXME', 'PLACEHOLDER', 'SEGNAPOSTO', 'DA COMPLETARE', 'LOREM IPSUM')) {
        if ($t -and [regex]::IsMatch($t, ('\b' + [regex]::Escape($tok) + '\b'), 'IgnoreCase')) { $sospetti += ($f.Name + '->' + $tok) }
    }
}
Assert ($sospetti.Count -eq 0) ('Nessun segnaposto nei sorgenti' + $(if ($sospetti) { ': ' + ($sospetti -join ', ') } else { '' }))

# --- 11-bis. nessun sorgente contiene un valore che SEMBRA una chiave API ---
# Serve a evitare che un test (o una svista) metta una chiave dentro uno script:
# oltre a essere pericoloso, farebbe scattare il controllo "segreti nei log"
# appena quella riga finisse in un messaggio di errore.
$finte = @()
foreach ($f in @(Get-ChildItem -Path $base -Recurse -Filter *.ps1)) {
    if ($f.Name -eq 'verifica_progetto.ps1') { continue }
    $t = Get-Content $f.FullName -Raw -Encoding UTF8
    if ($t -match 'AQ\.[A-Za-z0-9_\-]{10,}' -or $t -match 'AIza[0-9A-Za-z_\-]{20,}') { $finte += $f.Name }
}
Assert ($finte.Count -eq 0) ('Nessuna chiave API scritta dentro gli script' + $(if ($finte) { ': ' + ($finte -join ', ') } else { '' }))

# --- 12. nessun segreto nei log ---
. (Join-Path $base 'brain\log.ps1')
$logDir = Join-Path $base 'logs'
if (Test-Path $logDir) {
    $sporchi = @()
    foreach ($f in @(Get-ChildItem -Path $logDir -File)) {
        $t = Get-Content $f.FullName -Raw -Encoding UTF8
        if (Test-ContieneSegreti $t) { $sporchi += $f.Name }
    }
    Assert ($sporchi.Count -eq 0) ('Nessun segreto nei log' + $(if ($sporchi) { ': ' + ($sporchi -join ', ') } else { '' }))
} else {
    Assert $true 'Cartella logs assente: nessun segreto da controllare'
}

# --- 13. nessun residuo della versione precedente ---
Assert (-not ($avviaSrc -like '*# v5: Get-TemaXaml ora vive*Get-TemaXaml {*')) 'AVVIA.ps1 non ridefinisce piu Get-TemaXaml'
Assert ($avviaSrc -notlike '*Send-Green-Text*') 'AVVIA.ps1: funzione morta rimossa'
Assert (-not (Test-Path (Join-Path $base 'tests\_tmp'))) 'Nessuna cartella temporanea lasciata nei test'

# --- 13-bis. falso positivo antivirus: nessun elenco di comandi di sistema negli script ---
# Queste espressioni, se stanno DENTRO uno script, fanno segnalare lo script come
# "contenuto dannoso" (AMSI). Devono vivere solo nel file di dati comandi_pericolosi.txt.
$firme = @('vssadmin', 'bcdedit', 'diskpart', 'takeown', 'icacls', 'netsh', 'taskkill', 'net\s+user')
$colpevoli = @()
foreach ($f in @(Get-ChildItem -Path $base -Recurse -Filter *.ps1)) {
    if ($f.Name -eq 'verifica_progetto.ps1') { continue }
    $t = Get-Content $f.FullName -Raw -Encoding UTF8
    foreach ($s in $firme) { if ($t -match $s) { $colpevoli += ($f.Name + '->' + $s) } }
}
Assert ($colpevoli.Count -eq 0) ('Nessun elenco di comandi di sistema dentro gli script' + $(if ($colpevoli) { ': ' + ($colpevoli -join ', ') } else { '' }))
Assert ((Test-Path (Join-Path $base 'brain\comandi_pericolosi.txt'))) 'Elenco dei comandi da confermare presente come file di dati'

# --- 14. nessun file estraneo ---
$estranei = @(Get-ChildItem -Path $base -Recurse -File | Where-Object { $_.Extension -in @('.py', '.tmp', '.bak', '.orig') })
Assert ($estranei.Count -eq 0) ('Nessun file estraneo (.py/.tmp/.bak)' + $(if ($estranei) { ': ' + (($estranei | ForEach-Object { $_.Name }) -join ', ') } else { '' }))

Write-Host ''
# --- 15. ogni comando chiamato esiste davvero (funzione del progetto o cmdlet) ---
# Blocca la classe di difetto che impediva l'avvio di ZAP: funzioni usate nei
# sorgenti ma mai definite (Get-ModalitaEtichetta / Colore / Descrizione).
$tuttiPs1 = @(Get-ChildItem -Path $base -Recurse -Filter *.ps1 -File)
$definite = @{}
foreach ($f in $tuttiPs1) {
    $tf = $null; $ef = $null
    $astf = [System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tf, [ref]$ef)
    foreach ($fn in $astf.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)) {
        $definite[$fn.Name.ToLower()] = $true
    }
}
# Cmdlet presenti solo su Windows + programmi esterni lanciati di proposito.
$soloWindows = @('add-mppreference', 'get-mpcomputerstatus', 'get-mppreference', 'remove-mppreference',
                 'unblock-file', 'get-startapps', 'restart-computer', 'stop-computer',
                 'get-event', 'register-objectevent', 'unregister-event', 'get-ciminstance')
$programmiEsterni = @('ollama', 'winget')
$cacheCmd = @{}
$nonRisolti = @()
foreach ($f in $tuttiPs1) {
    $tf = $null; $ef = $null
    $astf = [System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tf, [ref]$ef)
    foreach ($c in $astf.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)) {
        $nm = $c.GetCommandName()
        if (-not $nm) { continue }
        $k = $nm.ToLower()
        if ($k -match '^[\.\\/]') { continue }
        if ($definite.ContainsKey($k) -or $soloWindows -contains $k -or $programmiEsterni -contains $k) { continue }
        if (-not $cacheCmd.ContainsKey($k)) { $cacheCmd[$k] = [bool](Get-Command -Name $nm -ErrorAction SilentlyContinue) }
        if (-not $cacheCmd[$k]) { $nonRisolti += ($f.Name + ' -> ' + $nm) }
    }
}
$nonRisolti = @($nonRisolti | Select-Object -Unique)
Assert ($nonRisolti.Count -eq 0) ('Ogni comando chiamato esiste (funzione del progetto o cmdlet)' + $(if ($nonRisolti) { ': ' + ($nonRisolti -join '; ') } else { '' }))

Write-Host "RISULTATO VERIFICA: $script:pass passati, $script:fail falliti" -ForegroundColor $(if ($script:fail -eq 0) { 'Green' } else { 'Red' })
if ($script:fail -gt 0) { exit 1 } else { exit 0 }
