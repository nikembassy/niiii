﻿# tests/selftest.ps1 — Verifica rapida di ZAP (funzioni pure, senza interfaccia)
# Uso: powershell -NoProfile -File .\tests\selftest.ps1

# Guardia: se un comando non esiste (o un errore non viene gestito) i test si
# FERMANO subito, invece di stampare "0 falliti" come se fosse tutto a posto.
# E' esattamente il difetto che nascondeva il blocco di AVVIA.bat.
$ErrorActionPreference = 'Stop'

$base = Split-Path -Parent $PSScriptRoot
. (Join-Path $base 'brain\tools.ps1')
. (Join-Path $base 'brain\llm.ps1')

# carica anche le funzioni pure di agent.ps1 (Normalize-ToolCalls, Trim-History)
$agentSrc = Get-Content (Join-Path $base 'brain\agent.ps1') -Raw
$agentSrc = $agentSrc -replace '(?m)^\. \(Join-Path \$base .*$', ''
$agentSrc = $agentSrc -replace '(?s)# -{10,}.*$', ''
Invoke-Expression $agentSrc

$script:pass = 0
$script:fail = 0
function Assert($cond, $name) {
    if ($cond) { $script:pass++; Write-Host "PASS: $name" -ForegroundColor Green }
    else       { $script:fail++; Write-Host "FAIL: $name" -ForegroundColor Red }
}

# --- Tool schema ---
$toolsJson = Get-AgentTools | ConvertTo-Json -Depth 30 -Compress
try {
    $parsed = @($toolsJson | ConvertFrom-Json)
    Assert ($parsed.Count -ge 16) ("tool schema: JSON valido con " + $parsed.Count + " strumenti")
    $nomiTool = @($parsed | ForEach-Object { $_.function.name })
    Assert ((@($nomiTool | Sort-Object -Unique).Count) -eq $nomiTool.Count) 'tool schema: nomi degli strumenti tutti diversi'
} catch {
    Assert $false "tool schema: JSON valido"
}

# --- ConvertTo-PlainString ---
Assert ((ConvertTo-PlainString 'ciao') -eq 'ciao') 'PlainString: stringa'
Assert ((ConvertTo-PlainString $null) -eq '') 'PlainString: null'
$arr = @(@{ text = 'a' }, @{ text = 'b' })
Assert ((ConvertTo-PlainString $arr) -eq "a`nb") 'PlainString: array di parti'

# --- Normalize-ToolCalls ---
$tc1 = [PSCustomObject]@{
    id = '1'; type = 'function'
    function = [PSCustomObject]@{ name = 'run_powershell'; arguments = '{"code":"Get-Date"}' }
}
$tc2 = [PSCustomObject]@{
    id = '2'; type = 'function'
    function = [PSCustomObject]@{ name = 'web_search'; arguments = [PSCustomObject]@{ query = 'milano' } }
}
$norm = @(Normalize-ToolCalls @($tc1, $tc2))
Assert ($norm.Count -eq 2) 'Normalize: 2 tool calls'
Assert ($norm[0].function.arguments -is [string]) 'Normalize: arguments stringa (tc1)'
Assert ($norm[1].function.arguments -is [string]) 'Normalize: arguments oggetto->stringa (tc2)'
try {
    $a = $norm[0].function.arguments | ConvertFrom-Json
    Assert ($a.code -eq 'Get-Date') 'Normalize: JSON arguments ricostruibile'
} catch { Assert $false 'Normalize: JSON arguments ricostruibile' }

# --- Storico in stile OpenAI serializza correttamente ---
$msgs = @(
    @{ role = 'system'; content = 'sei ZAP' },
    @{ role = 'user'; content = 'apri il browser' },
    @{ role = 'assistant'; content = $null; tool_calls = $norm },
    @{ role = 'tool'; tool_call_id = '1'; content = '(eseguito)' },
    @{ role = 'assistant'; content = 'fatto!' }
)
try {
    $body = @{ model = 'test'; messages = $msgs } | ConvertTo-Json -Depth 30
    $back = $body | ConvertFrom-Json
    Assert ($back.messages.Count -eq 5) 'Storico: serializzazione JSON integra'
    Assert ($null -ne $back.messages[2].tool_calls) 'Storico: tool_calls preservati'
} catch {
    Assert $false 'Storico: serializzazione JSON integra'
}

# --- Trim-History ---
$big = New-Object System.Collections.ArrayList
[void]$big.Add(@{ role = 'system'; content = 'sei ZAP' })
for ($i = 0; $i -lt 40; $i++) {
    if ($i % 4 -eq 0)      { [void]$big.Add(@{ role = 'user'; content = "u$i" }) }
    elseif ($i % 4 -eq 1)  { [void]$big.Add(@{ role = 'assistant'; content = $null; tool_calls = @(@{ id = "t$i"; type = 'function'; function = @{ name = 'x'; arguments = '{}' } }) }) }
    elseif ($i % 4 -eq 2)  { [void]$big.Add(@{ role = 'tool'; tool_call_id = "t$($i-1)"; content = 'ok' }) }
    else                   { [void]$big.Add(@{ role = 'assistant'; content = "a$i" }) }
}
$trimmed = Trim-History $big
Assert ($trimmed.Count -le 30) 'Trim: storico ridotto'
Assert ($trimmed[0].role -eq 'system') 'Trim: system preservato'
Assert ($trimmed[1].role -eq 'user') 'Trim: inizia con un messaggio user pulito'

# --- Test-RiskyCode ---
Assert (Test-RiskyCode 'Remove-Item C:\x -Recurse -Force') 'Rischio: Remove-Item rilevato'
Assert (Test-RiskyCode 'Stop-Computer -Force') 'Rischio: Stop-Computer rilevato'
Assert (-not (Test-RiskyCode 'Get-ChildItem $env:USERPROFILE')) 'Rischio: Get-ChildItem sicuro'
Assert (-not (Test-RiskyCode 'New-Item -ItemType Directory -Path .\lavoro')) 'Rischio: New-Item cartelle sicuro'

# --- Skill slug / salvataggio ---
Assert ((ConvertTo-SkillSlug 'Backup Documenti!') -eq 'backup-documenti') 'Slug: normalizzazione'

$fakeSync = @{
    Base = (Join-Path ([System.IO.Path]::GetTempPath()) ("zapselftest-" + [guid]::NewGuid().ToString('N')))
    Config = @{ cartella_lavoro = '' }
}
New-Item -ItemType Directory -Path (Join-Path $fakeSync.Base 'skills') | Out-Null
New-Item -ItemType Directory -Path (Join-Path $fakeSync.Base 'memory') | Out-Null

$res = Save-Skill $fakeSync 'prova_skill' 'skill di test' 'quando serve provare' 'param($x); "ciao $x"'
$res2 = Save-Skill $fakeSync 'prova_skill' 'skill di test v2' 'quando serve provare v2' 'param($x); "ciao2 $x"'
Assert ($res -like "*prova_skill*") 'Skill: salvataggio'
Assert ((Get-SkillList $fakeSync).Count -eq 1) 'Skill: nessun doppione nel registro'
Assert ((Get-ChildItem (Join-Path $fakeSync.Base 'skills') -Filter 'prova_skill.ps1').Count -eq 1) 'Skill: file creato'

# --- Memoria ---
Add-Memory $fakeSync 'nota di prova' | Out-Null
Assert ((Get-MemoryText $fakeSync) -like '*nota di prova*') 'Memoria: scrittura e lettura'

# --- Web helpers ---
Assert ((ConvertTo-PlainText '<p>Ciao <b>mondo</b></p>') -eq 'Ciao mondo') 'PlainText: strip tag HTML'
Assert ((ConvertFrom-DdgUrl '//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fx&rut=x') -eq 'https://example.com/x') 'DuckDuckGo: decode URL'
Assert ((ConvertFrom-DdgUrl 'https://esempio.it') -eq 'https://esempio.it') 'DuckDuckGo: URL diretto'

# --- Voce: pulizia testo (solo regex, niente audio) ---
$voiceSrc = Get-Content (Join-Path $base 'voice\tts.ps1') -Raw
$voiceSrc = $voiceSrc -replace '(?m)^Add-Type.*$', ''
Invoke-Expression $voiceSrc
Assert ((ConvertTo-SpeechText 'Ciao **mondo** [link](https://x.y)') -notmatch '\*\*') 'Voce: markdown rimosso'
Assert ((ConvertTo-SpeechText '') -eq 'Fatto!') 'Voce: fallback su vuoto'

# --- antivirus: elenco comandi rischiosi letto dal file di dati ---
Assert ((Test-RiskyCode 'Remove-Item C:\tmp\x -Recurse')) 'Antivirus: un comando distruttivo viene riconosciuto'
Assert ((Test-RiskyCode 'Get-Date') -eq $false) 'Antivirus: un comando innocuo non viene segnalato'
Assert ((Get-PatternRischi).Length -gt 50) 'Antivirus: elenco dei comandi letto correttamente'

# --- v6.2: moduli, modalita (senza la vecchia didattica), comandi diretti ---
$syncProg = @{ Base = $fakeSync.Base; Config = @{ sicurezza = 'smart'; browser = 'thorium'; motore_ricerca = 'duckduckgo'; programmi = @{ cartella = 'programmi' } } }
Assert ((Get-ModalitaSequenza).Count -eq 6) 'v7.9.8: sei modalita disponibili'
Assert ((Get-ModalitaSequenza) -notcontains 'programmatori') 'v6.4: la modalita didattica non esiste piu'
Assert ((Get-ModalitaSequenza) -contains 'enterprise') 'v6.4: esiste la modalita ENTERPRISE'
Assert ((Get-ModalitaEtichetta 'enterprise') -eq 'ENTERPRISE') 'v6.4: etichetta di ENTERPRISE'
Assert ((Get-ModalitaColore 'enterprise') -like '#FF*') 'v6.4: colore di ENTERPRISE'
Assert ((Get-ModalitaDescrizione 'enterprise').Length -gt 40) 'v6.4: descrizione di ENTERPRISE'
Assert ((Test-ModalitaEnterprise @{ Config = @{ sicurezza = 'enterprise' } }) -eq $true) 'v6.4: riconosce ENTERPRISE'
Assert ((Test-ModalitaEnterprise @{ Config = @{ sicurezza = 'smart' } }) -eq $false) 'v6.4: NON confonde ENTERPRISE'
Assert ((Get-ModalitaSequenza) -contains 'hacker') 'v7.9.8: esiste la modalita HACKER'
Assert ((Get-ModalitaEtichetta 'hacker') -eq 'HACKER') 'v7.9.8: etichetta di HACKER'
Assert ((Get-ModalitaColore 'hacker') -like '#FF*') 'v7.9.8: colore di HACKER'
Assert ((Test-ModalitaHacker @{ Config = @{ sicurezza = 'hacker' } }) -eq $true) 'v7.9.8: riconosce HACKER'
Assert ((Test-ModalitaHacker @{ Config = @{ sicurezza = 'enterprise' } }) -eq $false) 'v7.9.8: NON confonde HACKER'
Assert ((Get-Command Get-HackerPrompt -ErrorAction SilentlyContinue) -ne $null) 'v7.9.8: prompt HACKER presente'
if (-not (Get-Command Get-OsintFonti -ErrorAction SilentlyContinue)) {
    $__rp = Split-Path -Parent $PSScriptRoot
    foreach ($__m in @('osint.ps1','mini_agenti.ps1')) { $__f = Join-Path $__rp ('brain\' + $__m); if (Test-Path $__f) { . $__f } }
}
Assert ((Get-Command Get-OsintFonti -ErrorAction SilentlyContinue) -ne $null) 'v7.9.8: modulo OSINT presente'
Assert ((Get-OsintFonti).Count -ge 5) 'v7.9.8: catalogo OSINT popolato'
Assert ((Get-Command Get-MiniAgentiDefault -ErrorAction SilentlyContinue) -ne $null) 'v7.9.8: modulo mini-agenti presente'
Assert ((Get-ModalitaEtichetta 'sviluppatore') -eq 'SVILUPPATORE') 'v6.2: etichetta di una modalita'
Assert ((Get-ModalitaColore 'smart') -like '#FF*') 'v6.2: colore di una modalita'
Assert ((Get-ModalitaDescrizione 'prudente').Length -gt 20) 'v6.2: descrizione di una modalita'

# --- v6.4: nuove funzioni e strumenti ---
foreach ($fn in @('Get-AppuntiText', 'Set-Appunti', 'Add-Appunto', 'Get-AppuntiPath', 'Test-Admin',
                  'Get-AdminStatus', 'Invoke-ImparaDalloSchermo', 'Invoke-ConsigliMiglioramento',
                  'Get-EnterprisePrompt', 'Get-EnterpriseStato')) {
    Assert ((Get-Command $fn -ErrorAction SilentlyContinue) -ne $null) ('v6.4: funzione presente -> ' + $fn)
}
$nomiV64 = @(Get-AgentTools | ForEach-Object { $_.function.name })
foreach ($t in @('impara_dallo_schermo', 'consigli_miglioramento', 'stato_amministratore', 'aggiungi_appunto', 'leggi_appunti')) {
    Assert ($nomiV64 -contains $t) ('v6.4: strumento presente -> ' + $t)
}
$txtPromptEnt = (Get-EnterprisePrompt -sync $fakeSync -Nome 'ZAP' -Oggi 'oggi' -Memoria 'm' -Skills 's')
Assert ($txtPromptEnt -like '*ENTERPRISE*') 'v6.4: prompt ENTERPRISE contiene la parola chiave'
Assert ($txtPromptEnt -like '*NON cancelli MAI*') 'v6.4: prompt ENTERPRISE impone di non cancellare senza conferma'
Assert ($txtPromptEnt -like '*PENSIERO LATERALE*') 'v6.4: prompt ENTERPRISE prevede il pensiero laterale'

# --- v6.5: palette (tema/colori) + modello locale ---
foreach ($fn in @('Get-PaletteDefault', 'Get-TemaPreset', 'Merge-Palette', 'Test-OllamaUp')) {
    Assert ((Get-Command $fn -ErrorAction SilentlyContinue) -ne $null) ('v6.5: funzione presente -> ' + $fn)
}
$pal = Get-PaletteDefault
foreach ($k in @('sfondo', 'superficie', 'campo', 'pill', 'accento', 'accentoChiaro', 'accentoScuro',
                 'argento', 'argentoScuro', 'testo', 'testoSuAccento', 'bordo', 'font', 'fontSize')) {
    Assert ($pal.Contains($k)) ('v6.5: la palette ha il colore -> ' + $k)
}
Assert ($pal.fontSize -gt 0) 'v6.5: la palette ha una dimensione carattere'
Assert ((Get-TemaPreset 'notte').accento -ne $pal.accento) 'v6.5: il tema NOTTE cambia i colori'
Assert ((Get-TemaPreset 'smeraldo').accento -ne $pal.accento) 'v6.5: il tema SMERALDO cambia i colori'
Assert ((Get-TemaPreset 'viola').sfondo -ne $pal.sfondo) 'v6.5: il tema VIOLA cambia lo sfondo'
Assert ((Merge-Palette @{ accento = '#123456' }).accento -eq '#123456') 'v6.5: la palette salvata ha la precedenza'
Assert ((Merge-Palette $null).accento -eq $pal.accento) 'v6.5: senza preferenze si usa AURA'

# --- v6.6: un solo modello per volta + memoria del modello che funziona ---
foreach ($fn in @('Get-GeminiModelliRapidi', 'Find-ModelloGemini', 'Set-ModelloOk', 'Get-ModelloSalvato')) {
    Assert ((Get-Command $fn -ErrorAction SilentlyContinue) -ne $null) ('v6.6: funzione presente -> ' + $fn)
}
$syncR = @{ Config = @{ modello = 'gemini-3.6-flash'; gemini_model_scelto = 'gemini-3.6-flash' }; ModelloOk = 'gemini-3.1-flash-lite' }
$rap = @(Get-GeminiModelliRapidi $syncR)
Assert ($rap.Count -le 2) ('v6.6: la chat usa al massimo 2 modelli (ora ' + $rap.Count + ')')
Assert ($rap[0] -eq 'gemini-3.1-flash-lite') 'v6.6: si parte dal modello che ha funzionato'
$syncR2 = @{ Config = @{ modello = 'gemini-3.6-flash' } }
$rap2 = @(Get-GeminiModelliRapidi $syncR2)
Assert ($rap2[0] -eq 'gemini-3.6-flash') 'v6.6: senza memoria usa il modello configurato'
Assert ($rap2 -contains 'gemini-3.1-flash-lite') 'v6.6: il ripiego affidabile e incluso'
Assert ((Resolve-ComandoDiretto $syncProg 'chiudimi questa pagina').Azione -eq 'chiudi_finestra') 'v5: capisce "chiudimi questa pagina"'
Assert ((Resolve-ComandoDiretto $syncProg 'aprimi il blocco note').Azione -eq 'apri_programma') 'v5: capisce "aprimi il blocco note"'
Assert ((Get-TemaXaml 'a#FFFDF3D6b' 'oro') -eq 'a#0E1116b') 'v6.2: nuova grafica oro/scuro applicata'
$fintaChiave = ('AQ.' + ('z' * 30))
Assert ((Protect-LogText $fintaChiave) -like '*RIMOSSA*') 'v5: log senza segreti'

# --- v6.6.1: parser dello streaming SSE (testo + chiamate strumento) ---
$sse1 = ConvertFrom-GeminiSseChunk 'data: {"candidates": [{"content": {"parts": [{"text": "Ciao "}]}}]}'
$sse2 = ConvertFrom-GeminiSseChunk 'data: {"candidates": [{"content": {"parts": [{"text": "mondo"}]}, "finishReason": "STOP"}]}'
Assert (($sse1.Testo + $sse2.Testo) -eq 'Ciao mondo') 'v6.6.1: streaming SSE si ricompone'
Assert ((ConvertFrom-GeminiSseChunk 'data: [DONE]').Testo -eq '') 'v6.6.1: [DONE] ignorato'
Assert ((ConvertFrom-GeminiSseChunk 'riga spuria').Testo -eq '') 'v6.6.1: riga non-SSE ignorata'
$sseFn = ConvertFrom-GeminiSseChunk 'data: {"candidates": [{"content": {"parts": [{"functionCall": {"name": "run_powershell", "args": {"code": "Get-Date"}}}]}}]}'
Assert ((@($sseFn.Parti).Count -eq 1) -and ([string]$sseFn.Parti[0].functionCall.name -eq 'run_powershell')) 'v6.6.1: streaming conserva la chiamata strumento'

# --- Pulizia ---
try { Remove-Item $fakeSync.Base -Recurse -Force } catch { }

Write-Host ''
Write-Host "RISULTATO: $script:pass passati, $script:fail falliti" -ForegroundColor $(if ($script:fail -eq 0) { 'Green' } else { 'Red' })
if ($script:fail -gt 0) { exit 1 } else { exit 0 }
