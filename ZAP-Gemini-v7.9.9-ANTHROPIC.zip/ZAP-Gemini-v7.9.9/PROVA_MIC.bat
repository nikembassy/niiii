@echo off
setlocal
cd /d "%~dp0"
title ZAP - Prova microfono
where powershell >nul 2>&1
if errorlevel 1 (
  echo  [ZAP] ERRORE: PowerShell non trovato.
  pause
  exit /b 1
)
if not exist "%~dp0PROVA_MIC.ps1" (
  echo  [ZAP] ERRORE: manca PROVA_MIC.ps1 (cartella: %~dp0^)
  pause
  exit /b 1
)
echo.
echo  Ti spiego io perche' il microfono non ti sente.
echo  Alla fine premere Invio per chiudere non serve: leggi l'ESITO.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PROVA_MIC.ps1"
echo.
pause
endlocal
