﻿# INSTALLA.ps1 — Setup di ZAP! (esegui una volta sola)
# Come si lancia: tasto destro su INSTALLA.ps1 -> "Esegui con PowerShell"
# oppure: powershell -ExecutionPolicy Bypass -File .\INSTALLA.ps1

$ErrorActionPreference = 'Continue'
$base = $PSScriptRoot

# v5: moduli nuovi + log leggibile senza segreti
foreach ($__m in @('brain\log.ps1', 'brain\tema.ps1', 'brain\modalita.ps1', 'brain\autonomia.ps1', 'brain\programmi.ps1', 'brain\pc_controllo.ps1')) {
    $__p = Join-Path $base $__m
    if (Test-Path $__p) { . $__p }
}
try { Protect-TuttiILog -Base $base | Out-Null } catch { }
try { Start-Transcript -Path (Join-Path $base 'logs\installazione.log') -Append | Out-Null } catch { }

# --- se qualcosa va storto, MOSTRALO (finestra + logs\errore.log) ---
trap {
    $testo = ($_ | Out-String)
    try {
        $logDir = Join-Path $PSScriptRoot 'logs'
        if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
        Add-Content -Path (Join-Path $logDir 'errore.log') -Value ((Get-Date -Format 'o') + [Environment]::NewLine + $testo) -Encoding UTF8
    } catch { }
    Write-Host $testo -ForegroundColor Red
    try { [System.Windows.MessageBox]::Show($testo, 'ZAP - errore', 'OK', 'Error') | Out-Null } catch { }
    break
}



function Titolo($t) {
    Write-Host ''
    Write-Host "=== $t ===" -ForegroundColor Yellow
}
function Ok($t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Info($t) { Write-Host "  $t" -ForegroundColor Cyan }
function Warn($t) { Write-Host "  [!] $t" -ForegroundColor Red }

Write-Host ''
Write-Host '  ______  ______  ______' -ForegroundColor Yellow
Write-Host ' |___  / |___  / |___  /   ZAP! Assistente Desktop a Fumetto' -ForegroundColor Yellow
Write-Host '    / /     / /     / /    Setup guidato' -ForegroundColor Yellow
Write-Host '   / /__   / /__   / /__' -ForegroundColor Yellow
Write-Host '  /_____| /_____| /_____|  Ciao! Ti preparo tutto in 2 minuti.' -ForegroundColor Yellow
Write-Host ''

# --- 1. Sistema -----------------------------------------------------------
Titolo '1. Controllo del sistema'
if ($env:OS -ne 'Windows_NT') {
    Warn 'Questo assistente e'' pensato per Windows 10/11.'
    exit 1
}
Ok "Windows rilevato ($([System.Environment]::OSVersion.VersionString))"
Ok "PowerShell $($PSVersionTable.PSVersion) — va benissimo (verra' usato Windows PowerShell 5.1)"

# --- 2. Cartelle ----------------------------------------------------------
Titolo '2. Cartelle del progetto'
foreach ($d in 'logs', 'memory', 'skills', 'ui\avatar') {
    $p = Join-Path $base $d
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null }
}
Ok 'Struttura cartelle pronta'

# --- 3. Cervello IA: Gemini (cloud) o Ollama (locale) ---------------------
$cfgPath = Join-Path $base 'config.json'
$cfgNow = $null
try { $cfgNow = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
$provider = 'gemini'
if ($cfgNow -and $cfgNow.provider) { $provider = [string]$cfgNow.provider }

if ($provider -eq 'gemini') {
    Titolo '3. Cervello IA: Gemini (cloud)'
    Info 'Nessun modello locale: la RAM resta libera, il PC non si appesantisce.'
    $gkey = ''
    if ($cfgNow -and $cfgNow.api_key) { $gkey = [string]$cfgNow.api_key }
    if (-not $gkey) { $gkey = $env:GEMINI_API_KEY }
    if (-not $gkey) {
        Info 'Serve una API key gratuita di Google AI Studio: https://aistudio.google.com/app/apikey'
        $gkey = Read-Host '  Incolla qui la tua GEMINI API KEY'
    }
    if ($gkey) {
        $gkey = $gkey.Trim()
        try {
            $r = Invoke-RestMethod -Uri "https://generativelanguage.googleapis.com/v1beta/models?key=$gkey" -TimeoutSec 20
            Ok ("Gemini risponde! Modelli disponibili: " + $r.models.Count)
        } catch { Warn "Chiave non valida o rete assente: $($_.Exception.Message)" }
        try {
            if (-not ($cfgNow.PSObject.Properties.Name -contains 'provider')) {
                $cfgNow | Add-Member -NotePropertyName provider -NotePropertyValue 'gemini' -Force
            }
            $cfgNow.provider = 'gemini'
            $cfgNow.api_key  = $gkey
            if (-not $cfgNow.modello) { $cfgNow.modello = 'gemini-3.6-flash' }
            ($cfgNow | ConvertTo-Json -Depth 8) | Set-Content $cfgPath -Encoding UTF8
            Ok 'config.json aggiornato (provider = gemini)'
        } catch { Warn "Non ho potuto aggiornare config.json: $($_.Exception.Message)" }
    } else {
        Warn 'Nessuna chiave: potrai inserirla in Impostazioni.'
    }
} else {
# --- 3. Ollama (il cervello locale, gratis) -------------------------------
Titolo '3. Cervello IA: Ollama (locale, gratis)'
$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
    foreach ($p in @("$env:ProgramFiles\Ollama\ollama.exe", "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe")) {
        if (Test-Path $p) { $ollama = $p; break }
    }
}

if (-not $ollama) {
    Info 'Ollama non e'' ancora installato. Serve per capire quello che dici (funziona offline).'
    $a = Read-Host '  Lo installo con winget? [S]i / [N]o'
    if ($a -match '^[Ss]') {
        Info 'Installazione in corso (un minuto circa)...'
        winget install --id Ollama.Ollama -e --accept-source-agreements --accept-package-agreements
        $env:Path += ";$env:ProgramFiles\Ollama;$env:LOCALAPPDATA\Programs\Ollama"
        $ollama = Get-Command ollama -ErrorAction SilentlyContinue
        if ($ollama) { Ok 'Ollama installato!' } else { Warn 'Installato ma serve RIAVVIARE questo script (o il PC) per completare.' }
    } else {
        Warn 'Senza Ollama (o un''altra API IA) ZAP non capira'' il linguaggio naturale.'
        Info 'Puoi anche usare OpenAI/altro: vedi README, sezione "Cervello".'
    }
} else {
    Ok 'Ollama e'' gia'' installato'
}

# --- 4. Modello IA --------------------------------------------------------
Titolo '4. Modello del cervello'
if ($ollama) {
    Info 'Modelli consigliati:'
    Info '  llama3.1     ~5 GB   (ottimo, bilanciato)  <- default'
    Info '  qwen2.5:7b   ~5 GB   (molto bravo in italiano)'
    Info '  llama3.2:3b  ~2 GB   (leggero, per PC scarsi)'
    $m = Read-Host '  Quale modello scarico? [Invio = llama3.1]'
    if (-not $m) { $m = 'llama3.1' }
    Info "Scarico '$m' (puo' richiedere diversi minuti)..."
    & $ollama pull $m
    if ($LASTEXITCODE -eq 0) {
        Ok "Modello '$m' pronto!"
        # aggiorna config.json
        try {
            $cfgPath = Join-Path $base 'config.json'
            $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json
            $cfg.modello = $m
            ($cfg | ConvertTo-Json -Depth 6) | Set-Content $cfgPath -Encoding UTF8
            Ok "config.json aggiornato con il modello '$m'"
        } catch { }
    } else {
        Warn "Qualcosa e' andato storto col download. Riprova con: ollama pull $m"
    }
}

}

# --- 5. Voce --------------------------------------------------------------
Titolo '5. Controllo microfono (per parlare con ZAP)'
Add-Type -AssemblyName System.Speech -ErrorAction SilentlyContinue
try {
    $recs = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
    if ($recs -and $recs.Count -gt 0) {
        $it = $recs | Where-Object { $_.Culture.Name -like 'it*' }
        if ($it) { Ok "Riconoscimento vocale italiano disponibile: $($it[0].Culture.Name)" }
        else {
            Warn 'Hai il microfono ma manca la lingua vocale italiana.'
            Info 'Installa: Impostazioni Windows -> Ora e lingua -> Lingua -> Italiano (spunta "Riconoscimento vocale").'
        }
    } else {
        Warn 'Nessun riconoscimento vocale installato.'
        Info 'Installa: Impostazioni Windows -> Ora e lingua -> Voce / Lingua -> Italiano.'
        Info 'Nel frattempo ZAP funziona benissimo scrivendo in chat.'
    }
} catch {
    Warn 'Non riesco a controllare la voce: funzionera'' solo la chat.'
}

# --- 5-bis. v5: didattica, programmi, microfono --------------------------
Titolo '5-bis. Novita della v5'
foreach ($d in @('logs', 'programmi')) {
    $p = Join-Path $base $d
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null; Ok ("Creata la cartella '" + $d + "'") }
    else { Ok ("Cartella '" + $d + "' gia' presente") }
}
try {
    $cfgPathV5 = Join-Path $base 'config.json'
    $cfgV5 = $null
    if (Test-Path $cfgPathV5) { $cfgV5 = Get-Content $cfgPathV5 -Raw -Encoding UTF8 | ConvertFrom-Json }
    if ($cfgV5) {
        $cambiato = $false
        if (-not ($cfgV5.PSObject.Properties.Name -contains 'programmi')) {
            $cfgV5 | Add-Member -NotePropertyName programmi -NotePropertyValue (Get-DefaultProgrammiConfig) -Force
            $cambiato = $true
        }
        if ($cambiato) {
            ($cfgV5 | ConvertTo-Json -Depth 8) | Set-Content $cfgPathV5 -Encoding UTF8
            Ok 'config.json aggiornato con i blocchi v5 (programmi)'
        } else { Ok 'config.json contiene gia i blocchi v5' }
    } else { Warn 'config.json non leggibile: apri ZAP e salva le Impostazioni.' }
} catch { Warn ("Non ho potuto aggiornare config.json: " + $_.Exception.Message) }
if (Test-SpeechAvailable) { Ok 'Microfono: riconoscimento vocale disponibile' }
else { Warn 'Microfono: NESSUN riconoscimento vocale installato. Esegui PROVA_MIC.bat per sapere cosa manca.' }
Info 'Metti i tuoi programmi nella cartella "programmi" e lanciali dal pulsante PROGRAMMI.'

# --- 6. Test del cervello -------------------------------------------------
Titolo '6. Test del cervello'
$provNow = 'gemini'
$keyNow = ''
try {
    $c = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($c.provider) { $provNow = [string]$c.provider }
    $keyNow = [string]$c.api_key
} catch { }
if ($provNow -eq 'gemini') {
    try {
        $r = Invoke-RestMethod -Uri "https://generativelanguage.googleapis.com/v1beta/models?key=$keyNow" -TimeoutSec 15
        Ok ("Gemini collegato! " + $r.models.Count + ' modelli disponibili. Nessun modello locale: RAM libera.')
    } catch { Warn "Gemini non risponde: $($_.Exception.Message) - controlla la chiave in config.json." }
} else {
    try {
        $r = Invoke-RestMethod -Uri 'http://localhost:11434/v1/models' -TimeoutSec 5
        Ok "Ollama risponde! Modelli: $(($r.data | ForEach-Object { $_.id }) -join ', ')"
    } catch {
        Warn 'Ollama non risponde ancora su http://localhost:11434'
        Info 'Se lo hai appena installato: avvia "Ollama" dal menu Start e riprova.'
    }
}

# --- 7. Scorciatoia sul Desktop -------------------------------------------
Titolo '7. Scorciatoia sul Desktop'
$a = Read-Host '  Creo la scorciatoia "ZAP" sul Desktop? [S]i / [N]o'
if ($a -match '^[Ss]') {
    try {
        $ws = New-Object -ComObject WScript.Shell
        $desk = [Environment]::GetFolderPath('Desktop')
        $lnk = $ws.CreateShortcut((Join-Path $desk 'ZAP - Assistente a Fumetto.lnk'))
        $lnk.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
        $lnk.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -File `"$base\AVVIA.ps1`""
        $lnk.WorkingDirectory = $base
        $lnk.Description = 'ZAP! Assistente Desktop a Fumetto'
        $lnk.Save()
        Ok 'Scorciatoia creata!'
    } catch {
        Warn "Non sono riuscito a crearla: $($_.Exception.Message)"
    }
}

# --- v5: chiusura log (senza segreti) -------------------------------------
try { Stop-Transcript | Out-Null } catch { }
try { Protect-TuttiILog -Base $base | Out-Null } catch { }

# --- Fatto ----------------------------------------------------------------
Titolo 'FATTO! BAM!'
Write-Host '  Per avviare ZAP:' -ForegroundColor Green
Write-Host '    - doppio click su AVVIA.bat' -ForegroundColor Green
Write-Host '    - oppure la scorciatoia sul Desktop' -ForegroundColor Green
Write-Host ''
Write-Host '  Prova a dirgli: "Apri il browser e cerca le ultime novita su Milano, poi riassumimele"' -ForegroundColor Cyan
Write-Host '  Non sa fare qualcosa? Bottone INSEGNA! e te lo insegna lui a fare per sempre.' -ForegroundColor Cyan
Write-Host ''
Read-Host '  Premi Invio per chiudere'
