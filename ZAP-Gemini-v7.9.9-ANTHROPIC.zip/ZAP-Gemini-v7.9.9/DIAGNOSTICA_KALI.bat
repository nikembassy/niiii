@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ZAP - Diagnostica Kali

if not exist "%~dp0diagnostica_kali.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca il file diagnostica_kali.ps1 accanto a questo file.
  echo.
  pause
  exit /b 1
)

echo.
echo  ============================================================
echo   ZAP - DIAGNOSTICA KALI  (non serve essere amministratore)
echo  ============================================================
echo   Controllo: amministratore? impostazioni UAC? WSL presente?
echo   distro Kali? e spiego perche' Windows puo' non chiedere nulla.
echo  ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0diagnostica_kali.ps1"

echo.
echo  Il report completo e' in  logs\diagnostica_kali.txt
echo.
pause
endlocal
