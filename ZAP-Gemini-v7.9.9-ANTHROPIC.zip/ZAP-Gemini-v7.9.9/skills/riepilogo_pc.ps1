﻿# skill: riepilogo_pc
# descrizione: Riepilogo rapido dello stato del PC: CPU, RAM, disco, uptime
# quando: l'utente chiede come va il PC, lo stato del sistema, una diagnosi rapida
param()

$os  = Get-CimInstance Win32_OperatingSystem
$cs  = Get-CimInstance Win32_ComputerSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3"

$ramTotGB  = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
$ramLibGB  = [math]::Round($os.FreePhysicalMemory * 1KB / 1GB, 1)
$uptime    = (Get-Date) - $os.LastBootUpTime

$righe = @()
$righe += "PC: $($cs.Name) — $($os.Caption)"
$righe += "CPU: $($cpu.Name) — carico $($cpu.LoadPercentage)%"
$righe += "RAM: $ramLibGB GB liberi su $ramTotGB GB"
foreach ($d in $disks) {
    $totGB = [math]::Round($d.Size / 1GB, 1)
    $libGB = [math]::Round($d.FreeSpace / 1GB, 1)
    $pct   = [math]::Round(100 * $d.FreeSpace / $d.Size, 0)
    $righe += "Disco $($d.DeviceID): $libGB GB liberi su $totGB GB ($pct% libero)"
}
$righe += "Uptime: $($uptime.Days)g $($uptime.Hours)h $($uptime.Minutes)m"

return ($righe -join [Environment]::NewLine)
