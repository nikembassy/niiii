---
name: report-web
description: Crea un report o una dashboard in un unico file HTML (CSS inline, senza dipendenze esterne). Usala quando l'utente chiede un report, una dashboard, un riepilogo visivo o una pagina con dei dati.
---

# Report web (singolo file)

Generi un file `.html` autoconsistente: tutto il CSS e' inline, nessuna risorsa esterna.

## Quando usarla
- "fammi un report", "una dashboard", "una pagina con questi dati", "riassumimi in una tabella".

## Come procedere
1. Raccogli i dati (appunti, file, o risultati di altri strumenti).
2. Costruisci una tabella o un grafico semplice usando solo HTML + CSS inline.
3. Scegli un fondo chiaro e leggibile, titoli chiari, cifre allineate.
4. Scrivi il file in `dati\report\<nome>.html`.
5. Aprilo con lo strumento `open_browser` per mostrarlo all'utente.

## Esempio di struttura
```html
<!doctype html><html lang="it"><head><meta charset="utf-8">
<title>Report</title><style>body{font-family:Segoe UI;background:#fff;color:#111}</style>
</head><body><h1>Report</h1><table>...</table></body></html>
```
