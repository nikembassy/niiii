﻿# skill: attiva_voce
# descrizione: Avvia il riconoscimento vocale che trascrive il testo e lo invia automaticamente quando pronunci 'invia'.
# quando: Quando vuoi parlarmi invece di scrivere, pronunciando 'invia' alla fine della frase.
# creato: 2026-09-28
powershell -ExecutionPolicy Bypass -File $env:TEMP\voice_input.ps1
