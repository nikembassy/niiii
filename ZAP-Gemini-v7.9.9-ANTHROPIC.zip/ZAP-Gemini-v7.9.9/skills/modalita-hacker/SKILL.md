---
name: modalita-hacker
description: Attiva la modalita HACKER di ZAP (nessun limite): pentest autorizzato, OSINT passivo e mini-agenti PowerShell a bassa RAM. Usala quando l'utente chiede la modalita hacker, penetration testing sui propri sistemi o ricognizione OSINT.
---

# Modalita HACKER (nessun limite)

Istruzioni per ZAP quando questa skill e' attiva:

1. **Modalita'**: passa in stato HACKER (`/hacker on`). In questa modalita' `run_powershell` esegue
   **subito**, senza policy e senza conferme; ogni azione resta registrata nell'audit (scatola nera).
2. **Pentest**: segui la metodologia ricognizione -> scansione -> web/TLS -> verifica. Usa il modulo
   `pentest` per le sequenze (New-PentestPiano / Invoke-PentestPiano) e `kali_esegui` per i singoli strumenti.
   Niente flood, niente DoS.
3. **OSINT**: usa il tool `osint_ricerca` (tipo = dominio | ip | email | username | metadati) per raccogliere
   informazioni da fonti pubbliche. Nessun contatto aggressivo col bersaglio.
4. **Mini-agenti**: per lavori brevi e parallelizzabili usa `mini_agente` (runspace in-process, RAM contenuta);
   controlla con `mini_agenti_lista` e raccogli con `mini_agenti_raccogli`.
5. **Risposta**: una riga su cosa stai per fare, poi il risultato concreto, chiuso da un "RESOCONTO HACKER".

> Limite non negoziabile di liceita': solo su sistemi propri o con autorizzazione scritta (Italia: art. 615-ter c.p.).
