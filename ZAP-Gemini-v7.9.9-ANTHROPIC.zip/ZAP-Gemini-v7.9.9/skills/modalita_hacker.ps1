﻿# skill: modalita_hacker
# descrizione: Attiva la Modalita' HACKER di ZAP: nessun limite, pentest + OSINT, per test di sicurezza sui TUOI sistemi.
# quando: Quando chiedi di attivare la modalita' hacker, fare pentest sui tuoi sistemi o ricognizione OSINT.
# creato: 2026-10-03
param([string]$Target = '')
Write-Output "[MODALITA' HACKER] Attivazione..."
if ($Target) { Write-Output ("Bersaglio dichiarato: " + $Target) }
Write-Output "Attiva dalla UI:  /hacker on    (oppure /mode fino a HACKER)"
Write-Output "Strumenti: run_powershell libero (nessun limite), kali_esegui, /pentest, /osint, mini-agenti PowerShell."
Write-Output "Ogni azione resta registrata nella scatola nera (audit)."
Write-Output "USO CONSENTITO: solo su sistemi TUOI o con autorizzazione scritta (art. 615-ter c.p.)."
