﻿# skill: ripara_audio
# descrizione: Disabilita i driver audio virtuali in conflitto e forza l'accesso al microfono.
# quando: Quando il microfono non funziona, ci sono conflitti audio o Windows mostra errori di permessi.
# creato: 2026-09-28
# Script per pulizia audio e ripristino microfono
$virtualDevices = @("FxSound", "CABLE", "XSplit")
foreach ($dev in $virtualDevices) {
    Get-PnpDevice | Where-Object { $_.FriendlyName -like "*$dev*" } | Disable-PnpDevice -Confirm:$false -ErrorAction SilentlyContinue
}
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone" -Name "Value" -Value "Allow"
Write-Output "Audio pulito e permessi ripristinati."
