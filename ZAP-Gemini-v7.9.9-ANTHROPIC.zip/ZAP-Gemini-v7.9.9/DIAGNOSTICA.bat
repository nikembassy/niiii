@echo off
setlocal
cd /d "%~dp0"
title ZAP - Diagnostica
echo === Cartella: %~dp0
echo.
echo === PowerShell: ==
where powershell
echo.
if not exist "%~dp0AVVIA.ps1" (
  echo  [ZAP] ERRORE: manca AVVIA.ps1 in questa cartella.
  pause
  exit /b 1
)
echo === Moduli v5 presenti? (modalita, autonomia, programmi, controllo PC, log, tema) ==
for %%M in (modalita.ps1 autonomia.ps1 programmi.ps1 pc_controllo.ps1 log.ps1 tema.ps1) do (
  if exist "%~dp0brain\%%M" (echo   [OK]  brain\%%M) else (echo   [!!]  MANCA brain\%%M)
)
echo.
echo === Prova a caricare il motore di ZAP (qui si vede il blocco antivirus) ===
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { . ('%~dp0brain\tools.ps1'); if (Get-Command Get-AgentTools -ErrorAction SilentlyContinue) { Write-Host '  [OK] motore caricato, strumenti:' (Get-AgentTools).Count -ForegroundColor Green } else { Write-Host '  [!!] motore caricato ma senza funzioni' -ForegroundColor Red } } catch { Write-Host '  [!!] BLOCCO ANTIVIRUS sul file brain\tools.ps1' -ForegroundColor Red; Write-Host '       (falso positivo: esegui SBLOCCO_ANTIVIRUS.ps1)' -ForegroundColor Yellow }"
echo.
echo === Sintassi di tutti gli script .ps1 (parser di PowerShell) ===
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r='%~dp0';$f=0;$n=0;Get-ChildItem -Path $r -Recurse -Filter *.ps1|ForEach-Object{$e=$null;$n++;[System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$null,[ref]$e)|Out-Null;if($e -and $e.Count){$f++;Write-Host ('ERRORE in '+$_.FullName+': '+($e[0].Message)) -ForegroundColor Red}};Write-Host ('Script controllati: '+$n+' - con errori: '+$f)"
echo.
echo === Verifica completa del progetto (file, XAML, .bat, segreti) ===
if exist "%~dp0tests\verifica_progetto.ps1" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tests\verifica_progetto.ps1"
) else (
  echo   [!!] manca tests\verifica_progetto.ps1
)
echo.
pause
endlocal
