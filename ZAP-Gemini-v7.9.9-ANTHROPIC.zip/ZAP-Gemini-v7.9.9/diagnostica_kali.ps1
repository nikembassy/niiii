# ============================================================================
#  diagnostica_kali.ps1 -- ZAP : perche' NON compare la richiesta di Windows?
# ----------------------------------------------------------------------------
#  Va eseguito NORMALMENTE (NON serve essere amministratore).
#  Stampa a video un report E lo salva in  logs\diagnostica_kali.txt
# ============================================================================
$ErrorActionPreference = 'Continue'

$appRoot = $PSScriptRoot
if (-not $appRoot) { $appRoot = (Get-Location).Path }
$logsDir = Join-Path $appRoot 'logs'
if (-not (Test-Path $logsDir)) { try { New-Item -ItemType Directory -Force -Path $logsDir | Out-Null } catch { } }
$reportFile = Join-Path $logsDir 'diagnostica_kali.txt'

$script:report = @()
function Aggiungi {
    param([string]$t)
    Write-Host $t
    $script:report += $t
}

function Esegui {
    param([string]$exe, [string]$argomenti, [int]$sec = 15)
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $exe
        $psi.Arguments = $argomenti
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow  = $true
        $p = [System.Diagnostics.Process]::Start($psi)
    } catch { return ('(non eseguibile: ' + $_.Exception.Message + ')') }
    $ot = $p.StandardOutput.ReadToEndAsync()
    $et = $p.StandardError.ReadToEndAsync()
    if (-not $ot.Wait($sec * 1000)) { try { $p.Kill() } catch { }; return '(timeout)' }
    [void]$p.WaitForExit(1000)
    return (([string]$ot.Result + [string]$et.Result) -replace "`0", '').Trim()
}

Aggiungi '============================================================'
Aggiungi '  ZAP - DIAGNOSTICA KALI'
Aggiungi '============================================================'
Aggiungi ('Data/ora : ' + (Get-Date))
try {
    $os = [System.Environment]::OSVersion.Version
    Aggiungi ('Windows  : ' + $os.Major + '.' + $os.Minor + ' build ' + $os.Build)
} catch { Aggiungi 'Windows  : (non rilevato)' }
Aggiungi ('Utente   : ' + $env:USERDOMAIN + '\' + $env:USERNAME)
Aggiungi ''

# --- 1) sono amministratore ADESSO? ----------------------------------------
$admin = $false
try {
    $idT = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $pr  = New-Object System.Security.Principal.WindowsPrincipal($idT)
    $admin = [bool]$pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
} catch { }
$adminTxt = 'NO'; if ($admin) { $adminTxt = 'SI' }
Aggiungi ('Amministratore adesso? ' + $adminTxt)

$grpOut = Esegui 'whoami.exe' '/groups'
$inAdminGroup = 'NO'
if ($grpOut -match 'S-1-5-32-544') { $inAdminGroup = 'SI' }
Aggiungi ('Nel gruppo Administrators? ' + $inAdminGroup + '   (se NO, l account NON puo elevare da solo)')
Aggiungi ''

# --- 2) impostazioni UAC (finestra "Consenti modifiche...") -----------------
$enableLUA = '(?)'; $consent = '(?)'; $secure = '(?)'
try {
    $k = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
    $v = Get-ItemProperty -Path $k -ErrorAction Stop
    $enableLUA = $v.EnableLUA
    $consent   = $v.ConsentPromptBehaviorAdmin
    $secure    = $v.PromptOnSecureDesktop
} catch { }
Aggiungi 'UAC (finestra di consenso di Windows):'
Aggiungi ('  EnableLUA                  = ' + $enableLUA + '   (0 = UAC DISATTIVATO)')
Aggiungi ('  ConsentPromptBehaviorAdmin = ' + $consent + '   (0 = eleva senza chiedere, 5 = chiede il consenso [default])')
Aggiungi ('  PromptOnSecureDesktop      = ' + $secure + '   (1 = schermo attenuato)')
Aggiungi ''

# --- 3) WSL presente e funzionante? ----------------------------------------
$wslPath = ''
try { $c = Get-Command wsl.exe -ErrorAction SilentlyContinue; if ($c) { $wslPath = $c.Source } } catch { }
$wslTxt = $wslPath; if (-not $wslTxt) { $wslTxt = 'NON trovato' }
Aggiungi ('wsl.exe  : ' + $wslTxt)
if ($wslPath) {
    Aggiungi 'wsl --status:'
    Aggiungi ((Esegui 'wsl.exe' '--status' 15) -replace '(?m)^', '    ')
    Aggiungi 'wsl -l -v:'
    Aggiungi ((Esegui 'wsl.exe' '-l -v' 15) -replace '(?m)^', '    ')
    $lista = Esegui 'wsl.exe' '-l -q' 15
    $kaliSi = 'no'
    if ($lista -match '(?im)kali') { $kaliSi = 'si' }
    Aggiungi ('Distro Kali installata? ' + $kaliSi)
}
Aggiungi ''

# --- 4) componente Windows "WSL" abilitato? (richiede admin) ----------------
Aggiungi 'Componenti Windows (dism /get-featureinfo richiede amministratore):'
if ($admin) {
    $f1 = Esegui 'dism.exe' '/online /get-featureinfo /featurename:Microsoft-Windows-Subsystem-Linux' 30
    if ($f1 -match '(?im)Stato\s*:\s*(\w+)|State\s*:\s*(\w+)') { Aggiungi ('  WSL: ' + $matches[0]) } else { Aggiungi ('  WSL: ' + ($f1 -split "`n" | Select-String -Pattern 'Stato|State' | ForEach-Object { $_.ToString().Trim() })) }
    $f2 = Esegui 'dism.exe' '/online /get-featureinfo /featurename:VirtualMachinePlatform' 30
    $vm = $f2 -split "`n" | Select-String -Pattern 'Stato|State' | ForEach-Object { $_.ToString().Trim() }
    Aggiungi ('  VirtualMachinePlatform: ' + ($vm -join ' '))
} else {
    Aggiungi '  (saltato: non sono amministratore)'
}
Aggiungi ''

# --- 5) VERDETTO ------------------------------------------------------------
Aggiungi '----------------- VERDETTO -----------------'
if (-not $admin) {
    if ([string]$enableLUA -eq '0') {
        Aggiungi 'UAC e DISATTIVATO su questo PC: per questo NON appare nessuna finestra'
        Aggiungi 'quando un programma prova a diventare amministratore.'
        Aggiungi '-> Soluzione: apri ZAP (o INSTALLA_KALI.bat) con  tasto destro -> Esegui come amministratore.'
    } elseif ($inAdminGroup -ne 'SI') {
        Aggiungi 'Il tuo account NON e amministratore: per installare WSL/Kali serve'
        Aggiungi 'un account amministratore (o le credenziali di un amministratore).'
        Aggiungi '-> Soluzione: fai l installazione con un account amministratore di Windows.'
    } else {
        Aggiungi 'UAC attivo e account amministratore: la finestra DOVREBBE comparire.'
        Aggiungi 'Se non appare, guarda la BARRA DELLE APPLICAZIONI (a volte lampeggia arancione)'
        Aggiungi 'o l icona di Windows Security. In alternativa:'
        Aggiungi 'tasto destro su INSTALLA_KALI.bat -> Esegui come amministratore.'
    }
} else {
    Aggiungi 'Sei GIA amministratore: la finestra UAC NON deve comparire (e normale).'
    Aggiungi 'Se Kali non si installa comunque, il problema e altrove:'
    Aggiungi 'apri  logs\kali_install.log  e leggi l ultima riga.'
}
Aggiungi '-------------------------------------------'

try { Set-Content -LiteralPath $reportFile -Value ($script:report -join "`r`n") -Encoding UTF8 } catch { }
Write-Host ''
Write-Host ('Report salvato in: ' + $reportFile)
