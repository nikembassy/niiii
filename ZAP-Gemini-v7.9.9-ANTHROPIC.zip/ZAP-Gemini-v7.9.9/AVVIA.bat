@echo off
setlocal
cd /d "%~dp0"
title ZAP
if not exist "%~dp0logs" mkdir "%~dp0logs"
set "ERR=%~dp0logs\errore.log"

rem ---------- controllo prerequisiti ----------
where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo  Serve Windows PowerShell 5.1 (gia' incluso in Windows 10 e 11).
  echo.
  pause
  exit /b 1
)
if not exist "%~dp0AVVIA.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca il file AVVIA.ps1 accanto a questo .bat
  echo  Cartella: %~dp0
  echo  Estrai di nuovo lo ZIP per intero e riprova.
  echo.
  pause
  exit /b 1
)

rem --- dimensione del log errori PRIMA dell'avvio ---
set "PRIMA="
if exist "%ERR%" for %%A in ("%ERR%") do set "PRIMA=%%~zA"

echo.
echo  Avvio ZAP in corso...
echo  (log completo: logs\avvio.log  -  errori: logs\errore.log)
echo.
powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0AVVIA.ps1"
set "RC=%ERRORLEVEL%"

rem --- dimensione del log errori DOPO l'avvio ---
set "DOPO="
if exist "%ERR%" for %%A in ("%ERR%") do set "DOPO=%%~zA"

set "MALE=0"
if not "%RC%"=="0" set "MALE=1"
if not "%DOPO%"=="%PRIMA%" set "MALE=1"

echo.
if "%MALE%"=="1" goto problemi

echo  [ZAP] ZAP e' terminato normalmente (codice %RC%).
echo  Se la finestra non e' comparsa, esegui AVVIA_DEBUG.bat: tiene la finestra
echo  aperta e mostra l'errore; oppure apri logs\errore.log.
echo.
pause
exit /b 0

:problemi
echo  [ZAP] Qualcosa e' andato storto (codice %RC%).
echo.
echo  --- ULTIME RIGHE DI logs\errore.log ---
if exist "%ERR%" (
  powershell -NoProfile -Command "Get-Content -Path '%ERR%' -Tail 30 -ErrorAction SilentlyContinue"
) else (
  echo  (nessun logs\errore.log: l'errore non viene da ZAP)
)
echo.
echo  --- ULTIME RIGHE DI logs\avvio.log (traccia delle fasi) ---
if exist "%~dp0logs\avvio.log" (
  powershell -NoProfile -Command "Get-Content -Path '%~dp0logs\avvio.log' -Tail 15 -ErrorAction SilentlyContinue"
)
echo.
echo  Copia il testo qui sopra e mandalo: dice esattamente cosa non va.
echo.
pause
exit /b 1
