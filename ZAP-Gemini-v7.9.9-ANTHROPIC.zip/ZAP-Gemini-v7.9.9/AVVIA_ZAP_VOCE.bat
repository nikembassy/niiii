@echo off
setlocal
title VOCE per ZAP
cd /d "%~dp0"

if not exist "%~dp0ZAP_VOCE.ps1" (
  echo ERRORE: non trovo ZAP_VOCE.ps1 nella stessa cartella.
  echo Metti AVVIA_ZAP_VOCE.bat e ZAP_VOCE.ps1 nella STESSA cartella.
  pause
  exit /b 1
)

echo Avvio VOCE per ZAP...
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0ZAP_VOCE.ps1"

if errorlevel 1 (
  echo.
  echo Si e' verificato un errore all'avvio.
  echo Suggerimento: tasto destro sul file ZAP_VOCE.ps1 - Proprieta - spunta "Sblocca".
  pause >nul
)
endlocal
