# ============================================================================
#  installa_kali.ps1  --  ZAP : installa WSL2 + la distro UFFICIALE Kali Linux
# ----------------------------------------------------------------------------
#  - Si ELEVA da solo: se non e' amministratore apre la richiesta UAC di Windows
#    e, se conceduta, riparte elevato e completa l'installazione.
#  - Con -Pausa tiene la finestra aperta alla fine (utile da doppio clic).
#
#  Scrive:
#    logs\kali_install.log     log leggibile, passo per passo
#    logs\kali_install.stato   esito per l'app:  OK|msg  REBOOT|msg  ERRORE|msg
#
#  Sequenza:
#    0) amministratore?  (se no: chiede il consenso UAC e riparte elevato)
#    1) abilita i componenti Windows (WSL + Virtual Machine Platform)
#    2) aggiorna il motore WSL e imposta la versione 2 di default
#    3) (se serve) chiede il RIAVVIO del PC e si ferma
#    4) installa la distro kali-linux
#    5) prepara un utente non interattivo (evita il blocco del primo avvio)
#    6) verifica finale
# ============================================================================
param(
    [string]$LogFile   = '',
    [string]$StatoFile = '',
    [switch]$Pausa
)

$ErrorActionPreference = 'Continue'

# --- cartelle e file di log/stato --------------------------------------------
$appRoot = $PSScriptRoot
if (-not $appRoot) { $appRoot = (Get-Location).Path }
$logsDir = Join-Path $appRoot 'logs'
if (-not (Test-Path $logsDir)) { try { New-Item -ItemType Directory -Force -Path $logsDir | Out-Null } catch { } }
if (-not $LogFile)   { $LogFile   = Join-Path $logsDir 'kali_install.log' }
if (-not $StatoFile) { $StatoFile = Join-Path $logsDir 'kali_install.stato' }

function Scrive {
    param([string]$m)
    $riga = ('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $m)
    Write-Host $riga
    try { Add-Content -LiteralPath $LogFile -Value $riga -Encoding UTF8 } catch { }
}

function Imposta-Stato {
    param([string]$codice, [string]$messaggio)
    try { Set-Content -LiteralPath $StatoFile -Value ($codice + '|' + $messaggio) -Encoding UTF8 } catch { }
}

function Chiudi {
    param([int]$cod = 0)
    if ($Pausa) { try { Read-Host 'Premi INVIO per chiudere questa finestra' | Out-Null } catch { } }
    exit $cod
}

function Test-Admin {
    try {
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object System.Security.Principal.WindowsPrincipal($id)
        return [bool]$pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

# Esegue wsl.exe con argomenti grezzi (stringa) e TIMEOUT reale -> @{ ok; code; out }
function Esegui-WslRaw {
    param([string]$Argomenti, [int]$TimeoutSec = 1800)
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'wsl.exe'
        $psi.Arguments = $Argomenti
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow  = $true
        $p = [System.Diagnostics.Process]::Start($psi)
    } catch {
        return @{ ok = $false; code = -1; out = ('wsl.exe non eseguibile: ' + $_.Exception.Message) }
    }
    $ot = $p.StandardOutput.ReadToEndAsync()
    $et = $p.StandardError.ReadToEndAsync()
    if (-not $ot.Wait([int]($TimeoutSec * 1000))) {
        try { $p.Kill() } catch { }
        return @{ ok = $false; code = -1; out = 'timeout wsl' }
    }
    [void]$p.WaitForExit(2000)
    $code = -1
    try { $code = [int]$p.ExitCode } catch { $code = -1 }
    $out = (([string]$ot.Result + [string]$et.Result) -replace "`0", '').Trim()
    return @{ ok = ($code -eq 0); code = $code; out = $out }
}

function Esegui-Wsl {
    param([string[]]$Argomenti, [int]$TimeoutSec = 1800)
    return (Esegui-WslRaw -Argomenti ($Argomenti -join ' ') -TimeoutSec $TimeoutSec)
}

function Abilita-Componente {
    param([string]$Nome)
    Scrive ('Abilito il componente Windows: ' + $Nome)
    try {
        $p = Start-Process -FilePath 'dism.exe' -NoNewWindow -Wait -PassThru `
            -ArgumentList @('/online','/enable-feature',('/featurename:' + $Nome),'/all','/norestart')
        Scrive ('  dism exit=' + $p.ExitCode)
        return [int]$p.ExitCode
    } catch {
        Scrive ('  dism errore: ' + $_.Exception.Message)
        return -1
    }
}

function Kali-Registrato {
    $r = Esegui-Wsl @('-l','-q') 60
    if (-not $r.out) { return $false }
    foreach ($riga in ($r.out -split "`r?`n")) {
        if ($riga.Trim() -match '^kali') { return $true }
    }
    return $false
}

function Kali-Pronto {
    $r = Esegui-Wsl @('-d','kali-linux','--','bash','-lc','"echo ZAPOK"') 120
    return ([bool]$r.ok -and ([string]$r.out -match 'ZAPOK'))
}

# ============================================================================
#  AVVIO
# ============================================================================
Scrive '==== ZAP - installazione WSL2 + Kali Linux ===='

# --- 0) elevazione automatica ------------------------------------------------
if (-not (Test-Admin)) {
    Scrive 'Non sono amministratore: chiedo il consenso di Windows (UAC)...'
    Imposta-Stato 'AVVIO' 'in attesa del consenso amministratore (UAC)'
    $argomenti = @('-NoProfile','-ExecutionPolicy','Bypass','-File', ('"' + $PSCommandPath + '"'))
    if ($Pausa) { $argomenti += '-Pausa' }
    $okElev = $false
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -Wait -ArgumentList $argomenti | Out-Null
        $okElev = $true
    } catch {
        Scrive ('Consenso UAC annullato o non disponibile: ' + $_.Exception.Message)
        Imposta-Stato 'ERRORE' 'consenso di amministratore (UAC) annullato: riprova e clicca SI'
    }
    if ($okElev) { exit }
    Chiudi 1
}

Scrive 'Permessi di amministratore: OK.'
Imposta-Stato 'AVVIO' 'installazione in corso'

try {
    try {
        $os = [System.Environment]::OSVersion.Version
        Scrive ('Windows ' + $os.Major + '.' + $os.Minor + ' build ' + $os.Build)
    } catch { }

    # --- 1) componenti Windows -------------------------------------------------
    $reboot = $false
    $c1 = Abilita-Componente 'Microsoft-Windows-Subsystem-Linux'
    $c2 = Abilita-Componente 'VirtualMachinePlatform'
    if ($c1 -eq 3010 -or $c2 -eq 3010) { $reboot = $true }

    # --- 2) motore WSL ---------------------------------------------------------
    Scrive 'Aggiorno il motore WSL (wsl --update)...'
    $u = Esegui-Wsl @('--update') 1800
    Scrive ('  wsl --update exit=' + $u.code)
    if ($u.out) { Scrive ('  ' + $u.out) }
    $v = Esegui-Wsl @('--set-default-version','2') 120
    Scrive ('  wsl --set-default-version 2 exit=' + $v.code)

    $wslOk = $false
    $st = Esegui-Wsl @('--status') 60
    if ($st.code -eq 0) { $wslOk = $true }

    # --- 3) eventuale riavvio --------------------------------------------------
    if ($reboot -and -not $wslOk) {
        Scrive 'RIAVVIO NECESSARIO: i componenti WSL sono stati abilitati ora.'
        Imposta-Stato 'REBOOT' 'Riavvia il PC, poi premi di nuovo INSTALLA KALI per completare.'
        Scrive 'Fatto: riavvia il PC e ripremi INSTALLA KALI.'
        Chiudi 0
    }

    # --- 4) distro Kali --------------------------------------------------------
    $r = @{ out = '' }
    if (Kali-Registrato) {
        Scrive 'La distro kali-linux risulta gia installata.'
    } else {
        Scrive 'Installo la distro kali-linux... (puo richiedere alcuni minuti)'
        $r = Esegui-Wsl @('--install','-d','kali-linux') 3600
        Scrive ('  wsl --install -d kali-linux exit=' + $r.code)
        if ($r.out) { Scrive ('  ' + $r.out) }

        if (-not (Kali-Registrato)) {
            Scrive 'Riprovo con la sintassi alternativa (wsl --install kali-linux)...'
            $r2 = Esegui-Wsl @('--install','kali-linux') 3600
            Scrive ('  wsl --install kali-linux exit=' + $r2.code)
            if ($r2.out) { Scrive ('  ' + $r2.out) }
        }
    }

    if (-not (Kali-Registrato)) {
        if ([string]$r.out -match '(?i)reboot|riavvi') {
            Scrive 'RIAVVIO NECESSARIO prima di completare la distro.'
            Imposta-Stato 'REBOOT' 'Riavvia il PC, poi premi di nuovo INSTALLA KALI.'
            Chiudi 0
        }
        Scrive 'ERRORE: la distro kali-linux non risulta registrata.'
        Imposta-Stato 'ERRORE' 'distro kali non registrata - apri logs\kali_install.log'
        Chiudi 3
    }
    Scrive 'Distro kali-linux registrata.'

    # --- 5) utente non interattivo (evita il blocco del primo avvio) -----------
    if (-not (Kali-Pronto)) {
        Scrive 'Preparo l utente della distro (utente: kali / password: kali)...'
        $prov = "id -u kali >/dev/null 2>&1 || useradd -m -s /bin/bash kali; echo kali:kali | chpasswd; usermod -aG sudo kali 2>/dev/null; printf '[user]\ndefault=kali\n' > /etc/wsl.conf; echo ZAPPROVOK"
        $argLine = '-d kali-linux -u root -- bash -lc "' + $prov + '"'
        $pc = Esegui-WslRaw $argLine 300
        Scrive ('  preparazione utente exit=' + $pc.code)
        if ($pc.out) { Scrive ('  ' + $pc.out) }
        [void](Esegui-Wsl @('--terminate','kali-linux') 60)
    }

    # --- 6) verifica finale ----------------------------------------------------
    if (Kali-Pronto) {
        Scrive 'Kali e PRONTO: l agente puo eseguire comandi dentro Kali Linux.'
        Imposta-Stato 'OK' 'Kali installato e pronto (utente kali / password kali).'
        Chiudi 0
    }

    Scrive 'Kali installato, ma il primo avvio richiede forse un passaggio manuale.'
    Imposta-Stato 'OK' 'Kali installato. Se serve, apri Kali una volta e crea utente e password.'
    Chiudi 0
} catch {
    Scrive ('ERRORE imprevisto: ' + $_.Exception.Message)
    Imposta-Stato 'ERRORE' ('errore imprevisto: ' + $_.Exception.Message)
    Chiudi 9
}
