@echo off
setlocal
cd /d "%~dp0"
title ZAP (amministratore su richiesta)

if not exist "%~dp0AVVIA.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca AVVIA.ps1 accanto a questo file.
  echo  Cartella: %~dp0
  echo.
  pause
  exit /b 1
)
where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo.
  pause
  exit /b 1
)

echo.
echo  ============================================================
echo   ZAP in modalita' AMMINISTRATORE SU RICHIESTA
echo  ============================================================
echo   - La finestra di ZAP NON e' elevata, quindi il
echo     TRASCINAMENTO dei file (foto, video, PDF, documenti)
echo     FUNZIONA.
echo   - Quando un comando richiede i privilegi, ZAP lo
echo     riesegue come amministratore (apparira' il consenso UAC).
echo.
echo   Nota di Windows: una finestra avviata COME AMMINISTRATORE
echo   NON puo' ricevere file trascinati dal desktop (limite UAC/UIPI).
echo   Per questo ZAP resta non elevato e alza i privilegi al bisogno.
echo  ============================================================
echo.

powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0AVVIA.ps1" -Admin
set "RC=%ERRORLEVEL%"

echo.
echo  [ZAP] ZAP e' terminato (codice %RC%).
echo  Se non e' comparsa alcuna finestra, esegui AVVIA_DEBUG.bat.
echo.
pause
endlocal
